import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import {
  Car, Search, Fuel, Settings2, MapPin, BadgeCheck, Heart,
  ChevronRight, Gauge, Calendar, DollarSign, ShoppingCart,
  Wrench, Shield, Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";

const LISTINGS = [
  { id: "a1", make: "Toyota",  model: "Corolla X",   year: 2022, km: "18,000",  fuel: "CNG/Petrol", price: "৳28,00,000", img: "https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?w=400", verified: true,  condition: "Used",  city: "Dhaka" },
  { id: "a2", make: "Honda",   model: "Civic 2023",  year: 2023, km: "8,500",   fuel: "Hybrid",     price: "৳38,50,000", img: "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=400", verified: true,  condition: "Used",  city: "Dhaka" },
  { id: "a3", make: "Toyota",  model: "RAV4 2024",   year: 2024, km: "0",       fuel: "Hybrid",     price: "৳75,00,000", img: "https://images.unsplash.com/photo-1516476892398-bdcab4c8dab8?w=400", verified: true,  condition: "New",   city: "Chittagong" },
  { id: "a4", make: "BYD",     model: "Atto 3 EV",   year: 2024, km: "0",       fuel: "Electric",   price: "৳58,00,000", img: "https://images.unsplash.com/photo-1593941707882-a5bba14938c7?w=400", verified: false, condition: "New",   city: "Dhaka" },
  { id: "a5", make: "Suzuki",  model: "Swift 2021",  year: 2021, km: "32,000",  fuel: "CNG/Petrol", price: "৳16,50,000", img: "https://images.unsplash.com/photo-1617469767411-5b8a4a25c3e0?w=400", verified: true,  condition: "Used",  city: "Sylhet" },
  { id: "a6", make: "Nissan",  model: "X-Trail 2022",year: 2022, km: "22,000",  fuel: "Petrol",     price: "৳42,00,000", img: "https://images.unsplash.com/photo-1551830820-330a71b99659?w=400", verified: true,  condition: "Used",  city: "Dhaka" },
];

const FUEL_ICONS: Record<string, string> = { "CNG/Petrol": "⛽", "Hybrid": "🔋", "Electric": "⚡", "Petrol": "⛽", "Diesel": "⛽" };

export default function AutoPage() {
  const [activeTab, setActiveTab] = useState<"buy" | "sell" | "parts" | "service">("buy");
  const [filter, setFilter] = useState<"all" | "new" | "used" | "ev">("all");
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState("");

  const filtered = LISTINGS.filter(car => {
    const matchSearch = !search || `${car.make} ${car.model}`.toLowerCase().includes(search.toLowerCase()) || car.city.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === "all" || (filter === "new" && car.condition === "New") || (filter === "used" && car.condition === "Used") || (filter === "ev" && car.fuel === "Electric");
    return matchSearch && matchFilter;
  });

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <div className="relative rounded-3xl overflow-hidden border border-blue-500/20 h-44 md:h-52">
        <img src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=1200" alt="Cars" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
        <div className="absolute bottom-4 left-5 right-5">
          <div className="flex items-center gap-2 mb-1">
            <Car className="h-4 w-4 text-blue-400" />
            <span className="text-xs font-bold text-blue-300 uppercase tracking-widest">PaikarAuto</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Buy, Sell & Service</h1>
          <p className="text-sm text-white/55">Cars, bikes, spare parts, and service centers — all in one place.</p>
        </div>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Listings",    value: "18,400+", icon: Car,      color: "text-blue-400 bg-blue-500/10" },
          { label: "Verified",    value: "12,000+", icon: BadgeCheck,color: "text-green-400 bg-green-500/10" },
          { label: "EV Options",  value: "240+",    icon: Zap,       color: "text-yellow-400 bg-yellow-500/10" },
        ].map(s => { const Icon = s.icon; return (
          <GlassCard key={s.label} className="p-3.5 flex items-center gap-2">
            <div className={cn("h-8 w-8 rounded-xl flex items-center justify-center shrink-0", s.color)}>
              <Icon className="h-4 w-4" />
            </div>
            <div>
              <p className="text-base font-bold text-white leading-tight">{s.value}</p>
              <p className="text-[10px] text-white/35">{s.label}</p>
            </div>
          </GlassCard>
        ); })}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {([["buy","Buy"],["sell","Sell"],["parts","Parts"],["service","Service"]] as const).map(([t,l]) => (
          <button key={t} onClick={() => setActiveTab(t)} className={cn("flex-1 py-2.5 rounded-lg text-sm font-medium transition-all", activeTab===t?"bg-primary text-white":"text-white/50 hover:text-white")}>{l}</button>
        ))}
      </div>

      {activeTab === "buy" && (
        <div className="flex flex-col gap-5">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35 pointer-events-none" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by make, model, city..." className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
          </div>

          {/* Filter pills */}
          <div className="flex gap-2">
            {(["all","new","used","ev"] as const).map(f => (
              <button key={f} onClick={() => setFilter(f)} className={cn("flex-1 py-2 rounded-xl border text-sm font-medium transition-all capitalize",
                filter === f ? "bg-primary/15 border-primary/40 text-primary" : "bg-white/5 border-white/10 text-white/50 hover:text-white")}>
                {f === "ev" ? "EV Only" : f === "all" ? "All" : f === "new" ? "Brand New" : "Used"}
              </button>
            ))}
          </div>

          {/* Listings */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {filtered.map(car => (
              <GlassCard key={car.id} className="overflow-hidden glass-card-hover cursor-pointer p-0">
                <div className="relative h-40">
                  <img src={car.img} alt={`${car.make} ${car.model}`} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <button onClick={e => { e.stopPropagation(); setFavorites(prev => { const n = new Set(prev); n.has(car.id) ? n.delete(car.id) : n.add(car.id); return n; }); }}
                    className="absolute top-2 right-2 h-8 w-8 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center">
                    <Heart className={cn("h-4 w-4", favorites.has(car.id) ? "fill-red-400 text-red-400" : "text-white/70")} />
                  </button>
                  {car.verified && (
                    <div className="absolute top-2 left-2 flex items-center gap-1 bg-green-500/90 text-white text-[9px] font-bold px-2 py-0.5 rounded-full">
                      <BadgeCheck className="h-3 w-3" /> Verified
                    </div>
                  )}
                  <div className="absolute bottom-2 left-2 flex gap-1">
                    <span className={cn("text-[9px] font-bold px-2 py-0.5 rounded-full border",
                      car.condition === "New" ? "bg-primary/80 text-white border-primary/40" : "bg-white/20 text-white border-white/30")}>
                      {car.condition}
                    </span>
                  </div>
                </div>
                <div className="p-3.5">
                  <p className="text-sm font-bold text-white">{car.year} {car.make} {car.model}</p>
                  <div className="grid grid-cols-3 gap-2 mt-2 text-xs text-white/45">
                    <span className="flex items-center gap-1"><Fuel className="h-3 w-3" /> {car.fuel.split("/")[0]}</span>
                    <span className="flex items-center gap-1"><Gauge className="h-3 w-3" /> {car.km} km</span>
                    <span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {car.city}</span>
                  </div>
                  <div className="flex items-center justify-between mt-3">
                    <p className="text-base font-bold text-primary">{car.price}</p>
                    <Button size="sm" className="bg-primary hover:bg-primary/90 text-white rounded-full text-xs px-4">View</Button>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      )}

      {activeTab === "sell" && (
        <div className="flex flex-col gap-4">
          <GlassCard className="p-5 flex flex-col gap-3">
            <p className="text-sm font-semibold text-white">List Your Vehicle</p>
            {["Make (e.g. Toyota)", "Model (e.g. Corolla)", "Year", "Mileage (km)", "Asking Price (৳)"].map(field => (
              <div key={field} className="flex flex-col gap-1.5">
                <label className="text-xs text-white/40">{field}</label>
                <Input placeholder={`Enter ${field.split(" (")[0].toLowerCase()}...`} className="bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
              </div>
            ))}
            <Button className="bg-primary hover:bg-primary/90 text-white h-11 rounded-xl font-semibold mt-1">List Vehicle</Button>
          </GlassCard>
          <GlassCard className="p-4 flex items-center gap-4 border border-primary/20 bg-primary/5">
            <DollarSign className="h-7 w-7 text-primary shrink-0" />
            <div>
              <p className="font-semibold text-white text-sm">Free listings for 30 days</p>
              <p className="text-xs text-white/40 mt-0.5">Premium listings with boost available for ৳299/week.</p>
            </div>
          </GlassCard>
        </div>
      )}

      {activeTab === "parts" && (
        <div className="grid grid-cols-2 gap-3">
          {[
            { name: "Engine Oil (5W-30, 4L)", price: "৳1,200", brand: "Mobil 1",       icon: Fuel },
            { name: "Brake Pads Set",          price: "৳2,800", brand: "Brembo",        icon: Settings2 },
            { name: "Car Battery (60Ah)",       price: "৳5,500", brand: "Hamko/Volta",  icon: Zap },
            { name: "Windshield Wiper Pair",    price: "৳650",   brand: "Bosch",         icon: Car },
            { name: "Air Filter",               price: "৳450",   brand: "Mann Filter",  icon: Settings2 },
            { name: "Car Tyre (185/65 R15)",    price: "৳6,800", brand: "Pirelli",      icon: Car },
          ].map(part => { const Icon = part.icon; return (
            <GlassCard key={part.name} className="p-3.5 glass-card-hover cursor-pointer">
              <div className="h-9 w-9 rounded-xl bg-blue-500/10 flex items-center justify-center mb-2">
                <Icon className="h-4.5 w-[18px] h-[18px] text-blue-400" />
              </div>
              <p className="text-xs font-bold text-white leading-tight">{part.name}</p>
              <p className="text-[10px] text-white/35 mt-0.5">{part.brand}</p>
              <p className="text-sm font-bold text-primary mt-1.5">{part.price}</p>
              <Button size="sm" className="w-full mt-2 bg-primary/15 hover:bg-primary/25 text-primary rounded-full text-xs h-7">
                <ShoppingCart className="h-3 w-3 mr-1" /> Add
              </Button>
            </GlassCard>
          ); })}
        </div>
      )}

      {activeTab === "service" && (
        <div className="flex flex-col gap-3">
          {[
            { name: "Regular Service (A/B)", price: "৳2,500+", duration: "2-4 hrs", includes: "Oil change, filter, inspection",     icon: Settings2 },
            { name: "AC Repair & Recharge",   price: "৳1,500+", duration: "1-3 hrs", includes: "Gas refill, leak check, cleaning",  icon: Wrench },
            { name: "Detailing & Wash",        price: "৳800+",   duration: "3-5 hrs", includes: "Interior, exterior, engine bay",    icon: Car },
            { name: "Insurance Claim Help",    price: "Free",    duration: "Online",  includes: "Filing assistance, estimation",     icon: Shield },
          ].map(s => { const Icon = s.icon; return (
            <GlassCard key={s.name} className="p-4 glass-card-hover cursor-pointer">
              <div className="flex items-start gap-3">
                <div className="h-10 w-10 rounded-xl bg-blue-500/10 flex items-center justify-center shrink-0">
                  <Icon className="h-5 w-5 text-blue-400" />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-sm font-bold text-white">{s.name}</p>
                    <span className="text-sm font-bold text-primary shrink-0">{s.price}</span>
                  </div>
                  <p className="text-xs text-white/40 mt-0.5">{s.includes}</p>
                  <p className="text-xs text-white/30 mt-0.5 flex items-center gap-1"><Calendar className="h-3 w-3" /> {s.duration}</p>
                </div>
              </div>
              <div className="flex justify-end mt-3">
                <Button size="sm" className="bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/30 rounded-full text-xs px-4">Book</Button>
              </div>
            </GlassCard>
          ); })}
        </div>
      )}
    </div>
  );
}
