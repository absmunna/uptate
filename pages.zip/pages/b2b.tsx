import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import { useListVendors, getListVendorsQueryKey, useListProducts, getListProductsQueryKey } from "@workspace/api-client-react";
import { VendorCard } from "@/components/vendor/VendorCard";
import { ProductCard } from "@/components/product/ProductCard";
import {
  Building2, Package2, Handshake, FileText, ArrowRight,
  TrendingDown, Truck, Shield, Globe, ChevronRight,
} from "lucide-react";
import { Link } from "wouter";

const B2B_FEATURES = [
  { icon: TrendingDown, title: "Wholesale Pricing",  desc: "Tiered discounts from 10% to 45% on bulk orders" },
  { icon: FileText,     title: "Trade Documents",    desc: "Auto-generate PI, LC, and invoices" },
  { icon: Truck,        title: "Bulk Logistics",     desc: "Dedicated freight & warehousing solutions" },
  { icon: Shield,       title: "Verified Suppliers", desc: "All B2B vendors are trade-license verified" },
  { icon: Globe,        title: "Export Ready",       desc: "International trade & customs support" },
  { icon: Handshake,    title: "Contract Orders",    desc: "Repeat orders with negotiated rates" },
];

export default function B2BPage() {
  const { data: wholesaleVendors } = useListVendors(
    {} as any,
    { query: { queryKey: getListVendorsQueryKey() } }
  );
  const { data: wholesaleProducts } = useListProducts(
    { type: "wholesale", limit: 8 },
    { query: { queryKey: getListProductsQueryKey({ type: "wholesale", limit: 8 }) } }
  );

  const wVendors = wholesaleVendors?.filter((v) => v.type === "wholesale").slice(0, 6);

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <GlassCard className="p-6 md:p-8 bg-gradient-to-br from-purple-600/20 via-primary/10 to-transparent border border-purple-500/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4" />
        <div className="relative flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-purple-400" />
              <span className="text-xs font-semibold text-purple-300 uppercase tracking-wider">B2B Portal</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-white leading-tight">
              Wholesale &amp; Business Trade
            </h1>
            <p className="text-white/55 max-w-lg text-sm leading-relaxed">
              Connect directly with manufacturers, distributors, and verified wholesalers.
              Bulk pricing, trade finance, and contract management — all in one place.
            </p>
            <div className="flex items-center gap-3 mt-2">
              <Button className="bg-primary hover:bg-primary/90 text-white rounded-full px-6">
                Register as Buyer
              </Button>
              <Button variant="outline" className="border-white/20 bg-white/5 text-white hover:bg-white/10 rounded-full px-6">
                List Products
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 shrink-0">
            {[
              { label: "Verified Suppliers", value: "240+" },
              { label: "Product Categories", value: "60+" },
              { label: "Active Buyers",       value: "1.2k" },
              { label: "Monthly GMV",         value: "৳12M" },
            ].map((s) => (
              <div key={s.label} className="bg-white/5 border border-white/10 rounded-xl p-3 text-center">
                <p className="text-xl font-bold text-white">{s.value}</p>
                <p className="text-[10px] text-white/45 mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </GlassCard>

      {/* Features grid */}
      <div>
        <h2 className="text-lg font-semibold text-white mb-3">Why B2B on PaikarMart?</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {B2B_FEATURES.map((f) => {
            const Icon = f.icon;
            return (
              <GlassCard key={f.title} className="p-4 flex items-start gap-3">
                <div className="h-9 w-9 rounded-xl bg-purple-500/15 border border-purple-500/25 flex items-center justify-center shrink-0">
                  <Icon className="h-4 w-4 text-purple-400" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">{f.title}</p>
                  <p className="text-xs text-white/45 mt-0.5">{f.desc}</p>
                </div>
              </GlassCard>
            );
          })}
        </div>
      </div>

      {/* Wholesale vendors */}
      {wVendors && wVendors.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold text-white">Wholesale Suppliers</h2>
            <Link href="/vendors?type=wholesale" className="text-xs text-primary hover:underline flex items-center gap-1">
              View all <ChevronRight className="h-3 w-3" />
            </Link>
          </div>
          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
            {wVendors.map((v) => <VendorCard key={v.id} vendor={v} />)}
          </div>
        </div>
      )}

      {/* Wholesale products */}
      {wholesaleProducts && wholesaleProducts.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold text-white">Bulk Products</h2>
            <Link href="/marketplace?type=wholesale" className="text-xs text-primary hover:underline flex items-center gap-1">
              View all <ChevronRight className="h-3 w-3" />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {wholesaleProducts.slice(0, 4).map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </div>
      )}

      {/* CTA */}
      <GlassCard className="p-5 flex flex-col sm:flex-row items-center gap-4 border border-primary/20 bg-primary/5">
        <div className="h-12 w-12 rounded-2xl bg-primary/20 flex items-center justify-center shrink-0">
          <Package2 className="h-6 w-6 text-primary" />
        </div>
        <div className="flex-1 text-center sm:text-left">
          <p className="font-semibold text-white">Want to sell wholesale on PaikarMart?</p>
          <p className="text-sm text-white/45 mt-0.5">Reach 1,000+ business buyers across Bangladesh.</p>
        </div>
        <Link href="/seller/verification">
          <Button className="bg-primary hover:bg-primary/90 text-white rounded-full whitespace-nowrap">
            Get Verified <ArrowRight className="h-4 w-4 ml-1" />
          </Button>
        </Link>
      </GlassCard>
    </div>
  );
}
