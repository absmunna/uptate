import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import {
  Truck, Bike, Car, Package, MapPin, Clock,
  ArrowRight, CheckCircle, Navigation, ChevronRight,
  Zap, Shield, Star, Phone, Route,
} from "lucide-react";
import { cn } from "@/lib/utils";

const SERVICE_TYPES = [
  { id: "express",  icon: Zap,   label: "Express",   sub: "30 min delivery", price: "৳80",  color: "text-yellow-400 bg-yellow-500/10 border-yellow-500/25" },
  { id: "standard",icon: Bike,  label: "Standard",  sub: "2-4 hours",       price: "৳50",  color: "text-green-400 bg-green-500/10 border-green-500/25" },
  { id: "cargo",   icon: Truck, label: "Cargo",     sub: "Same day",        price: "৳150", color: "text-blue-400 bg-blue-500/10 border-blue-500/25" },
  { id: "ride",    icon: Car,   label: "Ride",      sub: "Available 24/7",  price: "৳60",  color: "text-purple-400 bg-purple-500/10 border-purple-500/25" },
];

const ACTIVE_DELIVERIES = [
  {
    id: "d1",
    orderId: "#PM8821",
    rider: "Karim Rahman",
    riderAvatar: "https://i.pravatar.cc/48?img=8",
    status: "on_the_way",
    eta: "12 min",
    progress: 65,
    from: "Fresh Block Market, Gulshan",
    to: "House 12, Road 5, Banani",
    rating: 4.9,
    rides: 1240,
  },
];

const STEPS = [
  { label: "Order Confirmed", done: true },
  { label: "Picked Up",       done: true },
  { label: "On the Way",      done: true, active: true },
  { label: "Delivered",       done: false },
];

export default function LogisticsPage() {
  const [activeTab, setActiveTab] = useState<"track" | "book" | "history">("track");
  const [selectedService, setSelectedService] = useState<string | null>("express");
  const [pickup, setPickup] = useState("");
  const [dropoff, setDropoff] = useState("");

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5 max-w-3xl mx-auto w-full">
      <PortalIconBar />

      {/* Hero */}
      <GlassCard className="p-6 bg-gradient-to-br from-blue-600/20 via-primary/10 to-transparent border border-blue-500/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4" />
        <div className="relative flex items-center gap-4">
          <div className="h-14 w-14 rounded-2xl bg-blue-500/20 flex items-center justify-center shrink-0">
            <Truck className="h-7 w-7 text-blue-400" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">PaikarLogistics</h1>
            <p className="text-sm text-white/55 mt-0.5">Fast delivery & ride service across Bangladesh</p>
            <div className="flex items-center gap-4 mt-2 text-xs text-white/45">
              <span className="flex items-center gap-1"><Zap className="h-3 w-3 text-yellow-400" /> Express 30 min</span>
              <span className="flex items-center gap-1"><Shield className="h-3 w-3 text-green-400" /> Insured</span>
              <span className="flex items-center gap-1"><Star className="h-3 w-3 text-yellow-400" /> 4.8 rating</span>
            </div>
          </div>
        </div>
      </GlassCard>

      {/* Tab switcher */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {([["track", "Track"], ["book", "Book"], ["history", "History"]] as const).map(([tab, label]) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={cn(
              "flex-1 py-2.5 rounded-lg text-sm font-medium transition-all",
              activeTab === tab ? "bg-primary text-white" : "text-white/50 hover:text-white"
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Track tab */}
      {activeTab === "track" && (
        <div className="flex flex-col gap-4">
          {ACTIVE_DELIVERIES.map((delivery) => (
            <GlassCard key={delivery.id} className="p-5 flex flex-col gap-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-white/40 uppercase tracking-wider font-medium">Order {delivery.orderId}</p>
                  <p className="text-sm font-semibold text-green-400 mt-0.5 flex items-center gap-1.5">
                    <Navigation className="h-3.5 w-3.5 animate-pulse" />
                    On the way • ETA {delivery.eta}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-white/40">Progress</p>
                  <p className="text-xl font-bold text-primary">{delivery.progress}%</p>
                </div>
              </div>

              {/* Progress bar */}
              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-primary to-blue-400 rounded-full transition-all duration-1000"
                  style={{ width: `${delivery.progress}%` }}
                />
              </div>

              {/* Steps */}
              <div className="flex items-center gap-0">
                {STEPS.map((step, i) => (
                  <div key={step.label} className="flex items-center flex-1">
                    <div className="flex flex-col items-center gap-1 flex-1">
                      <div className={cn(
                        "h-7 w-7 rounded-full flex items-center justify-center border-2 text-xs font-bold",
                        step.done
                          ? "bg-primary border-primary text-white"
                          : "bg-white/5 border-white/20 text-white/30"
                      )}>
                        {step.done ? <CheckCircle className="h-3.5 w-3.5" /> : i + 1}
                      </div>
                      <p className={cn("text-[10px] text-center leading-tight", step.done ? "text-white/70" : "text-white/30")}>
                        {step.label}
                      </p>
                    </div>
                    {i < STEPS.length - 1 && (
                      <div className={cn("h-px flex-1 mx-1 mb-4", step.done ? "bg-primary" : "bg-white/15")} />
                    )}
                  </div>
                ))}
              </div>

              {/* Route */}
              <div className="flex flex-col gap-2 bg-white/5 rounded-xl p-3">
                <div className="flex items-start gap-2 text-xs">
                  <div className="h-4 w-4 rounded-full bg-green-500/30 border border-green-500/50 flex items-center justify-center mt-0.5 shrink-0">
                    <div className="h-1.5 w-1.5 rounded-full bg-green-400" />
                  </div>
                  <span className="text-white/65">{delivery.from}</span>
                </div>
                <div className="ml-2 h-4 w-px bg-white/15" />
                <div className="flex items-start gap-2 text-xs">
                  <MapPin className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span className="text-white/65">{delivery.to}</span>
                </div>
              </div>

              {/* Rider info */}
              <div className="flex items-center gap-3 p-3 bg-white/5 rounded-xl border border-white/10">
                <img src={delivery.riderAvatar} alt={delivery.rider} className="h-10 w-10 rounded-full border border-white/20 object-cover" />
                <div className="flex-1">
                  <p className="text-sm font-semibold text-white">{delivery.rider}</p>
                  <div className="flex items-center gap-2 text-xs text-white/45">
                    <Star className="h-3 w-3 text-yellow-400 fill-yellow-400" />
                    {delivery.rating} · {delivery.rides} deliveries
                  </div>
                </div>
                <button className="h-9 w-9 rounded-xl bg-primary/20 flex items-center justify-center">
                  <Phone className="h-4 w-4 text-primary" />
                </button>
              </div>
            </GlassCard>
          ))}

          <GlassCard className="p-5 flex flex-col items-center gap-3 text-center border border-dashed border-white/15">
            <Package className="h-8 w-8 text-white/20" />
            <p className="text-sm text-white/40">No other active deliveries</p>
          </GlassCard>
        </div>
      )}

      {/* Book tab */}
      {activeTab === "book" && (
        <div className="flex flex-col gap-4">
          {/* Service type */}
          <div>
            <p className="text-xs text-white/50 uppercase tracking-wider font-medium mb-3">Select Service</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {SERVICE_TYPES.map((s) => {
                const Icon = s.icon;
                return (
                  <button
                    key={s.id}
                    onClick={() => setSelectedService(s.id)}
                    className={cn(
                      "p-3 rounded-2xl border flex flex-col items-center gap-2 text-center transition-all",
                      selectedService === s.id ? s.color : "bg-white/5 border-white/10 text-white/50"
                    )}
                  >
                    <Icon className="h-6 w-6" />
                    <div>
                      <p className="text-xs font-semibold">{s.label}</p>
                      <p className="text-[10px] opacity-70">{s.sub}</p>
                      <p className="text-xs font-bold mt-0.5">{s.price}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Address inputs */}
          <GlassCard className="p-4 flex flex-col gap-3">
            <div className="flex flex-col gap-2">
              <label className="text-xs text-white/50 font-medium">Pickup Location</label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 h-2 w-2 rounded-full bg-green-400 shrink-0" />
                <Input
                  value={pickup}
                  onChange={(e) => setPickup(e.target.value)}
                  placeholder="Enter pickup address"
                  className="pl-8 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl"
                />
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <label className="text-xs text-white/50 font-medium">Drop-off Location</label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-primary" />
                <Input
                  value={dropoff}
                  onChange={(e) => setDropoff(e.target.value)}
                  placeholder="Enter drop-off address"
                  className="pl-8 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl"
                />
              </div>
            </div>
          </GlassCard>

          <Button className="bg-primary hover:bg-primary/90 text-white h-12 rounded-xl text-base font-semibold">
            <Route className="h-4 w-4 mr-2" />
            Book Now
          </Button>
        </div>
      )}

      {/* History tab */}
      {activeTab === "history" && (
        <GlassCard className="p-5 flex flex-col items-center gap-3 text-center">
          <Truck className="h-10 w-10 text-white/15" />
          <p className="text-white font-medium">No delivery history yet</p>
          <p className="text-sm text-white/40">Your completed deliveries will appear here.</p>
          <Button variant="outline" className="bg-white/5 border-white/15 text-white hover:bg-white/10 rounded-full px-5 mt-2" onClick={() => setActiveTab("book")}>
            Book a Delivery
          </Button>
        </GlassCard>
      )}
    </div>
  );
}
