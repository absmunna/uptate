import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import {
  Heart, Users, Target, CheckCircle, Clock, ChevronRight,
  HandHeart, Droplets, BookOpen, Home, Leaf, Zap,
  TrendingUp, BadgeCheck, Share2,
} from "lucide-react";
import { cn } from "@/lib/utils";

const CATEGORIES = [
  { icon: BookOpen, label: "Education",  color: "text-blue-400 bg-blue-500/10",   count: 48 },
  { icon: Droplets, label: "Healthcare", color: "text-red-400 bg-red-500/10",     count: 32 },
  { icon: Home,     label: "Shelter",    color: "text-orange-400 bg-orange-500/10",count: 24 },
  { icon: Leaf,     label: "Environment",color: "text-green-400 bg-green-500/10", count: 18 },
  { icon: Users,    label: "Orphanage",  color: "text-purple-400 bg-purple-500/10",count: 40 },
  { icon: Zap,      label: "Disaster",   color: "text-yellow-400 bg-yellow-500/10",count: 12 },
];

const CAMPAIGNS = [
  {
    id: "c1", title: "Build 10 Schools in Haor Region",
    org: "Shikhao Bangladesh", category: "Education",
    raised: 18500000, goal: 25000000, donors: 2840,
    img: "https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=400",
    deadline: "July 30, 2026", verified: true,
  },
  {
    id: "c2", title: "Free Eye Surgery for 500 Patients",
    org: "Drishti Foundation", category: "Healthcare",
    raised: 9800000, goal: 15000000, donors: 1240,
    img: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400",
    deadline: "August 15, 2026", verified: true,
  },
  {
    id: "c3", title: "Cyclone Remal Relief Fund",
    org: "Relief BD", category: "Disaster",
    raised: 32000000, goal: 50000000, donors: 8920,
    img: "https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400",
    deadline: "Ongoing", verified: true,
  },
  {
    id: "c4", title: "Solar Power for 100 Villages",
    org: "GreenLight BD", category: "Environment",
    raised: 6500000, goal: 20000000, donors: 980,
    img: "https://images.unsplash.com/photo-1509391366360-2e959784a276?w=400",
    deadline: "December 31, 2026", verified: false,
  },
];

function formatTaka(amount: number): string {
  if (amount >= 10000000) return `৳${(amount / 10000000).toFixed(1)} Cr`;
  if (amount >= 100000) return `৳${(amount / 100000).toFixed(1)} L`;
  return `৳${amount.toLocaleString()}`;
}

const QUICK_AMOUNTS = ["৳100", "৳500", "৳1,000", "৳5,000", "৳10,000"];
const CAT_COLOR: Record<string, string> = {
  Education:   "bg-blue-500/15 text-blue-300 border-blue-500/25",
  Healthcare:  "bg-red-500/15 text-red-300 border-red-500/25",
  Disaster:    "bg-yellow-500/15 text-yellow-300 border-yellow-500/25",
  Environment: "bg-green-500/15 text-green-300 border-green-500/25",
};

export default function CharityPage() {
  const [activeTab, setActiveTab] = useState<"campaigns" | "donate" | "zakat">("campaigns");
  const [selectedAmount, setSelectedAmount] = useState("৳500");
  const [customAmount, setCustomAmount] = useState("");

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <GlassCard className="p-5 bg-gradient-to-br from-rose-600/25 via-pink-500/15 to-transparent border border-rose-500/25 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(244,63,94,0.12),transparent_60%)]" />
        <div className="relative">
          <div className="flex items-center gap-2 mb-1.5">
            <HandHeart className="h-4 w-4 text-rose-400" />
            <span className="text-xs font-bold text-rose-300 uppercase tracking-widest">PaikarCharity</span>
          </div>
          <h1 className="text-2xl font-bold text-white mb-1">Give. Impact. Transform.</h1>
          <p className="text-sm text-white/50 mb-4">Support verified causes across Bangladesh — Zakat, Sadaqah, and Crowdfunding.</p>
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: "Total Raised",    value: "৳48 Cr+" },
              { label: "Beneficiaries",   value: "2.4 L+" },
              { label: "Active Campaigns",value: "180+" },
            ].map(s => (
              <div key={s.label} className="bg-white/8 border border-rose-500/15 rounded-xl p-2.5 text-center">
                <p className="text-sm font-bold text-rose-300">{s.value}</p>
                <p className="text-[9px] text-white/35 mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </GlassCard>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {([["campaigns","Campaigns"],["donate","Quick Donate"],["zakat","Zakat Calc"]] as const).map(([t,l]) => (
          <button key={t} onClick={() => setActiveTab(t)} className={cn("flex-1 py-2.5 rounded-lg text-sm font-medium transition-all", activeTab===t?"bg-primary text-white":"text-white/50 hover:text-white")}>{l}</button>
        ))}
      </div>

      {activeTab === "campaigns" && (
        <div className="flex flex-col gap-5">
          {/* Category filter */}
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
            {CATEGORIES.map(c => { const Icon = c.icon; return (
              <button key={c.label} className={cn("flex flex-col items-center gap-1.5 p-3 rounded-xl border border-white/8 bg-white/5 hover:bg-white/10 transition-colors")}>
                <div className={cn("h-9 w-9 rounded-xl flex items-center justify-center", c.color)}>
                  <Icon className="h-[18px] w-[18px]" />
                </div>
                <p className="text-[10px] text-white/55 font-medium">{c.label}</p>
              </button>
            ); })}
          </div>

          {/* Campaigns */}
          <div className="flex flex-col gap-4">
            {CAMPAIGNS.map(campaign => {
              const pct = Math.round((campaign.raised / campaign.goal) * 100);
              return (
                <GlassCard key={campaign.id} className="overflow-hidden glass-card-hover cursor-pointer p-0">
                  <div className="relative h-40">
                    <img src={campaign.img} alt={campaign.title} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    {campaign.verified && (
                      <div className="absolute top-2 left-2 flex items-center gap-1 bg-green-500/90 text-white text-[9px] font-bold px-2 py-0.5 rounded-full">
                        <BadgeCheck className="h-3 w-3" /> Verified NGO
                      </div>
                    )}
                    <span className={cn("absolute top-2 right-2 text-[9px] font-bold px-2 py-0.5 rounded-full border", CAT_COLOR[campaign.category] ?? "bg-white/20 text-white border-white/30")}>{campaign.category}</span>
                  </div>
                  <div className="p-4">
                    <p className="text-sm font-bold text-white leading-tight">{campaign.title}</p>
                    <p className="text-xs text-white/40 mt-0.5">{campaign.org}</p>
                    {/* Progress bar */}
                    <div className="mt-3">
                      <div className="flex items-center justify-between mb-1.5 text-xs">
                        <span className="text-white/50">Raised: <span className="text-white font-bold">{formatTaka(campaign.raised)}</span></span>
                        <span className="text-primary font-bold">{pct}%</span>
                      </div>
                      <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-primary to-rose-400 rounded-full" style={{ width: `${Math.min(pct, 100)}%` }} />
                      </div>
                      <div className="flex items-center justify-between mt-1.5 text-xs text-white/35">
                        <span className="flex items-center gap-1"><Users className="h-3 w-3" /> {campaign.donors.toLocaleString()} donors</span>
                        <span className="flex items-center gap-1"><Target className="h-3 w-3" /> Goal: {formatTaka(campaign.goal)}</span>
                        <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {campaign.deadline}</span>
                      </div>
                    </div>
                    <div className="flex gap-2 mt-3">
                      <Button className="flex-1 bg-rose-500 hover:bg-rose-400 text-white rounded-full text-sm font-bold">
                        <Heart className="h-4 w-4 mr-1.5" /> Donate
                      </Button>
                      <Button size="sm" variant="outline" className="border-white/20 bg-white/5 text-white/70 hover:bg-white/10 rounded-full px-3">
                        <Share2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </GlassCard>
              );
            })}
          </div>
        </div>
      )}

      {activeTab === "donate" && (
        <div className="flex flex-col gap-4">
          <GlassCard className="p-5 flex flex-col gap-4">
            <p className="text-sm font-semibold text-white">Quick Donation</p>
            <div className="flex flex-col gap-2">
              <label className="text-xs text-white/40">Select Cause</label>
              <select className="bg-white/5 border border-white/10 text-white rounded-xl px-3 py-2.5 text-sm">
                {CAMPAIGNS.map(c => <option key={c.id} value={c.id} className="bg-[#0c1322]">{c.title}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-white/40 mb-2 block">Choose Amount</label>
              <div className="flex gap-2 flex-wrap">
                {QUICK_AMOUNTS.map(a => (
                  <button key={a} onClick={() => { setSelectedAmount(a); setCustomAmount(""); }}
                    className={cn("px-4 py-2 rounded-full border text-sm font-bold transition-all",
                      selectedAmount === a && !customAmount ? "bg-rose-500/20 border-rose-500/40 text-rose-300" : "bg-white/5 border-white/10 text-white/55")}>
                    {a}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-2 mt-3">
                <span className="text-sm text-white/50">৳</span>
                <Input type="number" value={customAmount} onChange={e => { setCustomAmount(e.target.value); setSelectedAmount(""); }} placeholder="Custom amount..." className="bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
              </div>
            </div>
            <Button className="bg-rose-500 hover:bg-rose-400 text-white h-12 rounded-xl font-bold text-base">
              <Heart className="h-5 w-5 mr-2" /> Donate {customAmount ? `৳${customAmount}` : selectedAmount}
            </Button>
          </GlassCard>
          <GlassCard className="p-4 flex items-center gap-4 border border-rose-500/20 bg-rose-500/5">
            <CheckCircle className="h-7 w-7 text-rose-400 shrink-0" />
            <div>
              <p className="font-semibold text-white text-sm">100% Transparent</p>
              <p className="text-xs text-white/45 mt-0.5">All donations are tracked on-chain. Monthly impact reports sent to donors.</p>
            </div>
          </GlassCard>
        </div>
      )}

      {activeTab === "zakat" && (
        <div className="flex flex-col gap-4">
          <GlassCard className="p-5 flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <HandHeart className="h-5 w-5 text-rose-400" />
              <p className="text-sm font-bold text-white">Zakat Calculator</p>
            </div>
            <p className="text-xs text-white/45">Nisab (2026): Gold 85g ≈ ৳9,25,000 | Silver 595g ≈ ৳1,10,000. Zakat rate: 2.5% of zakatable assets.</p>
            <div className="grid grid-cols-1 gap-3">
              {[
                { label: "Cash & Bank Balance (৳)", placeholder: "e.g. 500000" },
                { label: "Gold Value (৳)",           placeholder: "e.g. 200000" },
                { label: "Business Assets (৳)",      placeholder: "e.g. 300000" },
                { label: "Receivables (৳)",          placeholder: "e.g. 100000" },
              ].map(f => (
                <div key={f.label} className="flex flex-col gap-1.5">
                  <label className="text-xs text-white/45">{f.label}</label>
                  <Input type="number" placeholder={f.placeholder} className="bg-white/5 border-white/10 text-white placeholder:text-white/25 rounded-xl" />
                </div>
              ))}
            </div>
            <Button className="bg-rose-500 hover:bg-rose-400 text-white h-11 rounded-xl font-bold">Calculate Zakat</Button>
            <GlassCard className="p-4 bg-rose-500/8 border border-rose-500/20">
              <p className="text-xs text-white/50 mb-2">Estimated Zakat</p>
              <p className="text-3xl font-black text-rose-300">৳0</p>
              <p className="text-xs text-white/35 mt-1">Enter your assets above to calculate</p>
            </GlassCard>
          </GlassCard>
        </div>
      )}
    </div>
  );
}
