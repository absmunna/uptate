import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import { useListProducts, getListProductsQueryKey, useAddToCart } from "@workspace/api-client-react";
import { ProductCard } from "@/components/product/ProductCard";
import {
  Search, ShoppingBasket, Truck, Clock, Leaf, Fish, Beef, Milk,
  Apple, Carrot, ChevronRight, MapPin, Zap, BadgePercent,
} from "lucide-react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";

const GROCERY_CATS = [
  { icon: Apple,  label: "Fruits",    color: "text-red-400 bg-red-500/10",    href: "/marketplace?type=grocery" },
  { icon: Carrot, label: "Vegetables",color: "text-orange-400 bg-orange-500/10", href: "/marketplace?type=grocery" },
  { icon: Beef,   label: "Meat",      color: "text-rose-400 bg-rose-500/10",  href: "/marketplace?type=grocery" },
  { icon: Fish,   label: "Fish",      color: "text-blue-400 bg-blue-500/10",  href: "/marketplace?type=grocery" },
  { icon: Milk,   label: "Dairy",     color: "text-yellow-400 bg-yellow-500/10", href: "/marketplace?type=grocery" },
  { icon: Leaf,   label: "Organic",   color: "text-green-400 bg-green-500/10",href: "/marketplace?type=grocery" },
  { icon: ShoppingBasket, label: "Dry Goods", color: "text-amber-400 bg-amber-500/10", href: "/marketplace?type=grocery" },
  { icon: Truck,  label: "Bulk Buy",  color: "text-purple-400 bg-purple-500/10", href: "/marketplace?type=grocery" },
];

const DEALS = [
  { label: "Morning Fresh Deal", sub: "Vegetables at farm price", discount: "30% OFF", color: "from-green-600/30 to-teal-600/10 border-green-500/20" },
  { label: "Protein Pack",       sub: "Fish + Meat + Eggs combo", discount: "25% OFF", color: "from-blue-600/30 to-cyan-600/10 border-blue-500/20" },
  { label: "Organic Bundle",     sub: "Certified organic picks",  discount: "20% OFF", color: "from-emerald-600/30 to-green-600/10 border-emerald-500/20" },
];

export default function GroceryPage() {
  const [search, setSearch] = useState("");

  const { data: products, isLoading } = useListProducts(
    { type: "grocery", limit: 12 },
    { query: { queryKey: getListProductsQueryKey({ type: "grocery", limit: 12 }) } }
  );

  const all = products ?? [];
  const groceries = all.filter((p) =>
    !search || p.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <GlassCard className="p-5 md:p-7 bg-gradient-to-br from-green-700/25 via-emerald-500/10 to-transparent border border-green-500/20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(16,185,129,0.12),transparent_60%)]" />
        <div className="relative flex flex-col md:flex-row items-start md:items-center gap-5">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <ShoppingBasket className="h-4 w-4 text-green-400" />
              <span className="text-xs font-bold text-green-300 uppercase tracking-widest">PaikarGrocery</span>
            </div>
            <h1 className="text-2xl font-bold text-white mb-1">Fresh From Farm to Door</h1>
            <p className="text-sm text-white/50 mb-4">Daily fresh vegetables, fruits, and grocery essentials — delivered in 30 minutes.</p>
            <div className="flex flex-wrap gap-3 text-xs text-white/45">
              <span className="flex items-center gap-1"><Zap className="h-3.5 w-3.5 text-yellow-400" /> 30-min delivery</span>
              <span className="flex items-center gap-1"><Leaf className="h-3.5 w-3.5 text-green-400" /> Farm fresh</span>
              <span className="flex items-center gap-1"><BadgePercent className="h-3.5 w-3.5 text-primary" /> Daily deals</span>
              <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5 text-red-400" /> Dhaka wide</span>
            </div>
          </div>
          <Link href="/cart">
            <Button className="bg-green-500 hover:bg-green-400 text-black font-bold rounded-full px-6 shrink-0">
              View Cart <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </Link>
        </div>
      </GlassCard>

      {/* Flash deals */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {DEALS.map((d) => (
          <div key={d.label} className={cn("rounded-2xl p-4 bg-gradient-to-br border flex items-center gap-3 cursor-pointer glass-card-hover", d.color)}>
            <div className="flex-1">
              <p className="text-sm font-bold text-white">{d.label}</p>
              <p className="text-xs text-white/50 mt-0.5">{d.sub}</p>
            </div>
            <span className="shrink-0 text-xs font-black text-green-300 bg-green-500/20 px-2 py-1 rounded-lg border border-green-500/30">
              {d.discount}
            </span>
          </div>
        ))}
      </div>

      {/* Categories */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-base font-semibold text-white">Shop by Category</h2>
        </div>
        <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
          {GROCERY_CATS.map((c) => {
            const Icon = c.icon;
            return (
              <Link key={c.label} href={c.href}
                className="flex flex-col items-center gap-2 p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/8 transition-colors">
                <div className={cn("h-9 w-9 rounded-xl flex items-center justify-center", c.color)}>
                  <Icon className="h-[18px] w-[18px]" />
                </div>
                <span className="text-[10px] text-white/60 text-center leading-tight">{c.label}</span>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35 pointer-events-none" />
        <Input value={search} onChange={(e) => setSearch(e.target.value)}
          placeholder="Search groceries..."
          className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
      </div>

      {/* Products */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-base font-semibold text-white">
            {search ? `Results for "${search}"` : "Fresh Picks Today"}
          </h2>
          <Link href="/marketplace?type=grocery" className="text-xs text-primary hover:underline flex items-center gap-0.5">
            See all <ChevronRight className="h-3 w-3" />
          </Link>
        </div>
        {isLoading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="aspect-[3/4] rounded-2xl bg-white/5 animate-pulse" />
            ))}
          </div>
        ) : groceries.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {groceries.slice(0, 8).map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        ) : (
          <GlassCard className="p-8 flex flex-col items-center gap-2 text-center">
            <ShoppingBasket className="h-10 w-10 text-white/15" />
            <p className="text-sm text-white/40">
              {search ? `No items found for "${search}"` : "No grocery items available right now."}
            </p>
          </GlassCard>
        )}
      </div>

      {/* Delivery info */}
      <GlassCard className="p-4 flex items-center gap-4 border border-green-500/20 bg-green-500/5">
        <div className="h-11 w-11 rounded-xl bg-green-500/15 flex items-center justify-center shrink-0">
          <Truck className="h-5 w-5 text-green-400" />
        </div>
        <div className="flex-1">
          <p className="text-sm font-semibold text-white">Free delivery above ৳500</p>
          <p className="text-xs text-white/45 mt-0.5">Express 30-min delivery available across Dhaka</p>
        </div>
        <Clock className="h-5 w-5 text-white/30 shrink-0" />
      </GlassCard>
    </div>
  );
}
