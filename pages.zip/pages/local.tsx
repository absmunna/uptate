import { useState } from "react";
import { useListProducts, getListProductsQueryKey, useListVendors, getListVendorsQueryKey } from "@workspace/api-client-react";
import { StoryBar } from "@/components/feed/StoryBar";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import { ProductCard } from "@/components/product/ProductCard";
import { VendorCard } from "@/components/vendor/VendorCard";
import { GlassCard } from "@/components/ui/GlassCard";
import { MapPin, Navigation, Search, Store, ShoppingBag, Coffee, UtensilsCrossed, Pill, Scissors } from "lucide-react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

const CATEGORY_PILLS = [
  { icon: Store,          label: "All Shops",  filter: undefined },
  { icon: UtensilsCrossed,label: "Food",        filter: "grocery" },
  { icon: Coffee,         label: "Cafe",        filter: "service" },
  { icon: Pill,           label: "Pharmacy",    filter: "service" },
  { icon: Scissors,       label: "Salon",       filter: "service" },
  { icon: ShoppingBag,    label: "Retail",      filter: "retail" },
];

export default function Local() {
  const [activeTab, setActiveTab] = useState<"shops" | "products">("shops");
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState<string | undefined>(undefined);

  const { data: products } = useListProducts(
    { nearMe: true, type: filterType as any, q: search || undefined },
    { query: { queryKey: getListProductsQueryKey({ nearMe: true, type: filterType as any, q: search || undefined }) } }
  );

  const { data: vendors } = useListVendors(
    { nearMe: true, q: search || undefined } as any,
    { query: { queryKey: getListVendorsQueryKey() } }
  );

  return (
    <div className="flex flex-col gap-4 p-4 md:p-5">
      <StoryBar />
      <PortalIconBar />

      {/* Location banner */}
      <GlassCard className="p-4 flex items-center gap-3 border border-primary/15 bg-primary/5">
        <div className="h-10 w-10 rounded-xl bg-primary/20 flex items-center justify-center shrink-0">
          <Navigation className="h-5 w-5 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-white">Dhaka, Bangladesh</p>
          <p className="text-xs text-white/50">Showing results within 5 km</p>
        </div>
        <button className="text-xs text-primary font-medium shrink-0">Change</button>
      </GlassCard>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40 pointer-events-none" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search nearby shops and products..."
          className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl"
        />
      </div>

      {/* Category pills */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        {CATEGORY_PILLS.map((c) => {
          const Icon = c.icon;
          const active = filterType === c.filter && (c.filter !== undefined || filterType === undefined);
          const isAllActive = c.filter === undefined && filterType === undefined;
          return (
            <button
              key={c.label}
              onClick={() => setFilterType(c.filter)}
              className={cn(
                "shrink-0 flex items-center gap-2 px-3 py-2 rounded-xl border text-sm transition-all",
                (active || isAllActive)
                  ? "bg-primary border-primary text-white"
                  : "bg-white/5 border-white/10 text-white/60 hover:text-white hover:bg-white/10"
              )}
            >
              <Icon className="w-4 h-4" />
              {c.label}
            </button>
          );
        })}
      </div>

      {/* Tab switcher */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {(["shops", "products"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={cn(
              "flex-1 py-2.5 rounded-lg text-sm font-medium capitalize transition-all",
              activeTab === tab
                ? "bg-primary text-white shadow"
                : "text-white/60 hover:text-white"
            )}
          >
            {tab === "shops" ? "Nearby Shops" : "Local Products"}
          </button>
        ))}
      </div>

      {/* Content */}
      {activeTab === "shops" ? (
        <div>
          {!vendors || vendors.length === 0 ? (
            <EmptyState icon={Store} title="No shops found" msg="Try expanding your search area." />
          ) : (
            <div className="flex flex-col gap-3">
              {vendors.map((vendor) => (
                <NearbyShopRow key={vendor.id} vendor={vendor} />
              ))}
            </div>
          )}
        </div>
      ) : (
        <div>
          {!products || products.length === 0 ? (
            <EmptyState icon={ShoppingBag} title="No products found" msg="Try changing the category filter." />
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {products.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function NearbyShopRow({ vendor }: { vendor: any }) {
  const dist = vendor.distanceKm !== undefined ? `${vendor.distanceKm.toFixed(1)} km` : null;
  return (
    <GlassCard className="p-4 flex items-center gap-4 glass-card-hover cursor-pointer">
      <div className="h-12 w-12 rounded-xl overflow-hidden bg-white/5 shrink-0 border border-white/10">
        {vendor.avatarUrl ? (
          <img src={vendor.avatarUrl} alt={vendor.name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-lg font-bold text-primary">
            {vendor.name[0]}
          </div>
        )}
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-white text-sm truncate">{vendor.name}</p>
        <p className="text-xs text-white/45 truncate">{vendor.tagline}</p>
        <div className="flex items-center gap-1 mt-1 text-[10px] text-white/40">
          <MapPin className="w-3 h-3 text-primary" />
          <span>{vendor.location}</span>
          {dist && <><span className="mx-1">•</span><span className="text-primary">{dist}</span></>}
        </div>
      </div>
      <div className="shrink-0 text-right flex flex-col items-end gap-1">
        <span className="text-xs text-green-400 font-medium">Open</span>
        <span className="text-[10px] text-white/40">{vendor.products?.length ?? 0} items</span>
      </div>
    </GlassCard>
  );
}

function EmptyState({ icon: Icon, title, msg }: { icon: React.ElementType; title: string; msg: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-3 text-center">
      <div className="h-16 w-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center">
        <Icon className="h-8 w-8 text-white/20" />
      </div>
      <p className="text-white font-medium">{title}</p>
      <p className="text-sm text-white/45">{msg}</p>
    </div>
  );
}
