import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import { useListProducts, getListProductsQueryKey } from "@workspace/api-client-react";
import {
  Smartphone, Laptop, Tv, Headphones, Camera, Cpu,
  Search, Star, ShoppingCart, Zap, BadgeCheck, ChevronRight, Heart,
} from "lucide-react";
import { cn } from "@/lib/utils";

const CATEGORIES = [
  { icon: Smartphone, label: "Phones",    color: "text-blue-400 bg-blue-500/10",    count: 840 },
  { icon: Laptop,     label: "Laptops",   color: "text-purple-400 bg-purple-500/10",count: 320 },
  { icon: Tv,         label: "TVs",       color: "text-cyan-400 bg-cyan-500/10",    count: 180 },
  { icon: Headphones, label: "Audio",     color: "text-pink-400 bg-pink-500/10",    count: 450 },
  { icon: Camera,     label: "Cameras",   color: "text-orange-400 bg-orange-500/10",count: 120 },
  { icon: Cpu,        label: "PC Parts",  color: "text-green-400 bg-green-500/10",  count: 290 },
];

const BRANDS = ["Samsung", "Apple", "Xiaomi", "Realme", "ASUS", "Dell", "Sony", "JBL", "Anker", "TP-Link"];

const FEATURED = [
  { id: "t1", name: "Samsung Galaxy S24", price: "৳99,999",  old: "৳1,10,000", rating: 4.8, reviews: 2340, img: "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=300", badge: "Official" },
  { id: "t2", name: "iPhone 15 Pro",      price: "৳1,69,999",old: "৳1,80,000", rating: 4.9, reviews: 1850, img: "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=300", badge: "Hot" },
  { id: "t3", name: "Xiaomi 14",          price: "৳74,999",  old: "৳82,000",   rating: 4.7, reviews: 980,  img: "https://images.unsplash.com/photo-1589492477829-5e65395b66cc?w=300", badge: "Deal" },
  { id: "t4", name: "ASUS ROG G16 Laptop",price: "৳1,49,999",old: "৳1,65,000", rating: 4.8, reviews: 650,  img: "https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=300", badge: "Gaming" },
];

const BADGE_STYLE: Record<string, string> = {
  "Official": "bg-blue-500/90 text-white",
  "Hot":      "bg-red-500/90 text-white",
  "Deal":     "bg-green-500/90 text-white",
  "Gaming":   "bg-purple-500/90 text-white",
};

export default function ElectronicsPage() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  const [favorites, setFavorites] = useState<Set<string>>(new Set());

  const { data: apiProducts } = useListProducts(
    { limit: 4 },
    { query: { queryKey: getListProductsQueryKey({ limit: 4 }) } }
  );

  const filtered = FEATURED.filter(p => !search || p.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero banner */}
      <div className="relative rounded-3xl overflow-hidden border border-blue-500/20 h-44">
        <img src="https://images.unsplash.com/photo-1550009158-9ebf69173e03?w=1200" alt="Electronics" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
        <div className="absolute top-2 right-2">
          <span className="text-xs font-bold bg-yellow-400 text-black px-2.5 py-1 rounded-full flex items-center gap-1">
            <Zap className="h-3 w-3" /> Flash Sale
          </span>
        </div>
        <div className="absolute bottom-4 left-5">
          <div className="flex items-center gap-2 mb-1">
            <Cpu className="h-4 w-4 text-cyan-400" />
            <span className="text-xs font-bold text-cyan-300 uppercase tracking-widest">PaikarTech</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Electronics Hub</h1>
          <p className="text-sm text-white/55">Official brands · Best prices · Warranty guaranteed</p>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35 pointer-events-none" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search phones, laptops, accessories..." className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
      </div>

      {/* Categories */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
        {CATEGORIES.map(c => { const Icon = c.icon; return (
          <button key={c.label} onClick={() => setActiveCategory(c.label === activeCategory ? "All" : c.label)}
            className={cn("flex flex-col items-center gap-2 p-3 rounded-xl border transition-colors",
              activeCategory === c.label ? "border-primary/40 bg-primary/10" : "bg-white/5 hover:bg-white/10 border-white/8")}>
            <div className={cn("h-9 w-9 rounded-xl flex items-center justify-center", c.color)}>
              <Icon className="h-[18px] w-[18px]" />
            </div>
            <div className="text-center">
              <p className="text-[10px] text-white/65 font-medium">{c.label}</p>
              <p className="text-[9px] text-white/30">{c.count}+</p>
            </div>
          </button>
        ); })}
      </div>

      {/* Brands */}
      <div>
        <h2 className="text-sm font-semibold text-white/60 uppercase tracking-wide mb-2.5">Top Brands</h2>
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          {BRANDS.map(b => (
            <button key={b} className="shrink-0 text-xs bg-white/5 hover:bg-white/10 border border-white/10 text-white/60 hover:text-white px-3 py-1.5 rounded-full transition-all">{b}</button>
          ))}
        </div>
      </div>

      {/* Trust badges */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: "Official Warranty", icon: BadgeCheck, color: "text-green-400 bg-green-500/10" },
          { label: "7-Day Return",       icon: Zap,        color: "text-blue-400 bg-blue-500/10" },
          { label: "EMI Available",      icon: Cpu,        color: "text-purple-400 bg-purple-500/10" },
        ].map(b => { const Icon = b.icon; return (
          <GlassCard key={b.label} className="p-3 flex flex-col items-center gap-1.5 text-center">
            <div className={cn("h-8 w-8 rounded-xl flex items-center justify-center", b.color)}>
              <Icon className="h-4 w-4" />
            </div>
            <p className="text-[10px] text-white/60 font-medium leading-tight">{b.label}</p>
          </GlassCard>
        ); })}
      </div>

      {/* Featured products */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-base font-semibold text-white">Featured Devices</h2>
          <span className="text-xs text-primary hover:underline cursor-pointer flex items-center gap-0.5">See all <ChevronRight className="h-3 w-3" /></span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {filtered.map(p => (
            <GlassCard key={p.id} className="overflow-hidden glass-card-hover cursor-pointer p-0">
              <div className="relative h-36 bg-white/5">
                <img src={p.img} alt={p.name} className="w-full h-full object-cover" />
                <span className={cn("absolute top-2 left-2 text-[9px] font-bold px-1.5 py-0.5 rounded-full", BADGE_STYLE[p.badge] ?? "bg-white/20 text-white")}>{p.badge}</span>
                <button onClick={e => { e.stopPropagation(); setFavorites(prev => { const n = new Set(prev); n.has(p.id) ? n.delete(p.id) : n.add(p.id); return n; }); }}
                  className="absolute top-2 right-2 h-7 w-7 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center">
                  <Heart className={cn("h-3.5 w-3.5", favorites.has(p.id) ? "fill-red-400 text-red-400" : "text-white/70")} />
                </button>
              </div>
              <div className="p-3">
                <p className="text-xs font-bold text-white leading-tight">{p.name}</p>
                <div className="flex items-center gap-1 mt-1 text-[10px] text-white/40">
                  <Star className="h-3 w-3 text-yellow-400 fill-yellow-400" /> {p.rating} ({p.reviews})
                </div>
                <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                  <span className="text-sm font-bold text-primary">{p.price}</span>
                  <span className="text-[10px] text-white/30 line-through">{p.old}</span>
                </div>
                <Button size="sm" className="w-full mt-2 bg-primary/15 hover:bg-primary/25 text-primary rounded-full text-[10px] h-7">
                  <ShoppingCart className="h-3 w-3 mr-1" /> Buy
                </Button>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>

      {/* From real API */}
      {apiProducts && apiProducts.length > 0 && (
        <div>
          <h2 className="text-base font-semibold text-white mb-3">Also Available</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {apiProducts.map(p => (
              <GlassCard key={p.id} className="overflow-hidden glass-card-hover cursor-pointer p-0">
                {p.images?.[0] && <img src={p.images[0]} alt={p.title} className="w-full h-28 object-cover" />}
                <div className="p-3">
                  <p className="text-xs font-bold text-white leading-tight truncate">{p.title}</p>
                  <p className="text-sm font-bold text-primary mt-1">৳{p.price}</p>
                  <Button size="sm" className="w-full mt-2 bg-primary/15 hover:bg-primary/25 text-primary rounded-full text-[10px] h-7">
                    <ShoppingCart className="h-3 w-3 mr-1" /> Add
                  </Button>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
