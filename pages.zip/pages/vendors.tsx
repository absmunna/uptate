import { useState } from "react";
import { useListVendors, getListVendorsQueryKey } from "@workspace/api-client-react";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import { VendorCard } from "@/components/vendor/VendorCard";
import { GlassCard } from "@/components/ui/GlassCard";
import { Search, SlidersHorizontal } from "lucide-react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

const TYPE_PILLS = [
  { value: undefined,     label: "All" },
  { value: "retail",      label: "Retail" },
  { value: "wholesale",   label: "Wholesale" },
  { value: "grocery",     label: "Grocery" },
  { value: "service",     label: "Services" },
  { value: "hotel",       label: "Travel" },
  { value: "dropship",    label: "Dropship" },
];

function SkeletonCard() {
  return (
    <div className="glass-card rounded-2xl overflow-hidden flex flex-col">
      <div className="h-[88px] skeleton-shimmer" />
      <div className="p-4 flex flex-col gap-3">
        <div className="h-4 w-2/3 rounded skeleton-shimmer" />
        <div className="h-3 w-1/2 rounded skeleton-shimmer" />
        <div className="grid grid-cols-3 gap-2">
          <div className="h-8 rounded-lg skeleton-shimmer" />
          <div className="h-8 rounded-lg skeleton-shimmer" />
          <div className="h-8 rounded-lg skeleton-shimmer" />
        </div>
      </div>
    </div>
  );
}

export default function Vendors() {
  const [search, setSearch] = useState("");
  const [activeType, setActiveType] = useState<string | undefined>(undefined);

  const { data: vendors } = useListVendors(
    {} as any,
    { query: { queryKey: getListVendorsQueryKey() } }
  );

  const filtered = vendors?.filter((v) => {
    const matchType = !activeType || v.type === activeType;
    const matchSearch = !search ||
      v.name.toLowerCase().includes(search.toLowerCase()) ||
      v.tagline?.toLowerCase().includes(search.toLowerCase()) ||
      v.location.toLowerCase().includes(search.toLowerCase());
    return matchType && matchSearch;
  });

  return (
    <div className="flex flex-col gap-4 p-4 md:p-5">
      <PortalIconBar />

      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-white">Vendors</h1>
          <p className="text-sm text-white/45 mt-0.5">
            {filtered ? `${filtered.length} shops available` : "Browse all shops"}
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40 pointer-events-none" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search vendors by name or location..."
          className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl"
        />
      </div>

      {/* Type pills */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        {TYPE_PILLS.map(({ value, label }) => {
          const active = activeType === value;
          return (
            <button
              key={label}
              onClick={() => setActiveType(value)}
              className={cn(
                "shrink-0 px-3.5 py-1.5 rounded-full text-sm font-medium border transition-all whitespace-nowrap",
                active
                  ? "bg-primary border-primary text-white shadow-md shadow-primary/25"
                  : "bg-white/5 border-white/10 text-white/60 hover:text-white hover:bg-white/10"
              )}
            >
              {label}
            </button>
          );
        })}
      </div>

      {/* Vendor grid */}
      {!vendors ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      ) : filtered?.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 gap-3 text-center">
          <div className="h-16 w-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center">
            <SlidersHorizontal className="h-8 w-8 text-white/20" />
          </div>
          <p className="text-white font-medium">No vendors found</p>
          <p className="text-sm text-white/40">Try adjusting your search or filter.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered?.map((vendor) => (
            <VendorCard key={vendor.id} vendor={vendor} />
          ))}
        </div>
      )}
    </div>
  );
}
