import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Edit3, Store, ShoppingBag, Heart, Star,
  MapPin, CheckCircle, Bell, Shield, ChevronRight,
  BadgeCheck, Package, LogOut, Settings,
} from "lucide-react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";

function QuickLinkRow({ icon: Icon, label, sub, href, color = "text-primary bg-primary/10" }: {
  icon: React.ElementType; label: string; sub?: string; href: string; color?: string;
}) {
  return (
    <Link href={href}>
      <div className="flex items-center gap-3 p-3.5 rounded-xl hover:bg-white/5 transition-colors cursor-pointer">
        <div className={cn("h-9 w-9 rounded-xl flex items-center justify-center shrink-0", color)}>
          <Icon className="h-4 w-4" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-white">{label}</p>
          {sub && <p className="text-xs text-white/40">{sub}</p>}
        </div>
        <ChevronRight className="h-4 w-4 text-white/25 shrink-0" />
      </div>
    </Link>
  );
}

export default function Profile() {
  const { data: user } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });

  if (!user) {
    return (
      <div className="p-4 max-w-2xl mx-auto flex flex-col gap-4">
        <div className="glass-card rounded-2xl p-6 flex flex-col items-center gap-4">
          <div className="h-24 w-24 rounded-full skeleton-shimmer" />
          <div className="h-5 w-32 rounded skeleton-shimmer" />
          <div className="h-3 w-48 rounded skeleton-shimmer" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4 p-4 max-w-2xl mx-auto w-full">
      {/* Profile card */}
      <GlassCard className="p-6">
        <div className="h-24 -mx-6 -mt-6 mb-0 rounded-t-2xl bg-gradient-to-br from-primary/30 via-purple-500/20 to-transparent" />

        <div className="flex flex-col items-center -mt-12 gap-3 text-center">
          <div className="relative">
            <Avatar className="h-20 w-20 border-4 border-[#0c1322] shadow-xl">
              <AvatarImage src={user.avatarUrl} />
              <AvatarFallback className="text-2xl font-bold text-primary bg-primary/10">
                {user.name?.[0] ?? "U"}
              </AvatarFallback>
            </Avatar>
            {user.verified && (
              <BadgeCheck className="absolute -bottom-1 -right-1 h-6 w-6 text-primary fill-primary/20 bg-[#0c1322] rounded-full" />
            )}
          </div>

          <div className="flex flex-col gap-1">
            <h2 className="text-xl font-bold text-white">{user.name}</h2>
            <p className="text-sm text-white/50">@{user.handle}</p>
            {user.bio && <p className="text-xs text-white/55 max-w-xs">{user.bio}</p>}
          </div>

          {/* Role badge */}
          <div className="flex flex-wrap justify-center gap-1.5">
            {user.isSeller && (
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                Seller
              </span>
            )}
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
              Buyer
            </span>
            {user.verified && (
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-green-500/20 text-green-300 border border-green-500/30">
                Verified
              </span>
            )}
          </div>

          {user.location && (
            <div className="flex items-center gap-1 text-xs text-white/40">
              <MapPin className="h-3 w-3" />
              {user.location}
            </div>
          )}

          {user.trustScore !== undefined && (
            <div className="flex items-center gap-2 text-xs bg-white/5 border border-white/10 rounded-full px-3 py-1">
              <Star className="h-3 w-3 text-yellow-400 fill-yellow-400" />
              <span className="text-white/70">Trust Score: <span className="text-white font-semibold">{user.trustScore}</span></span>
            </div>
          )}

          <Button variant="outline" size="sm" className="mt-1 bg-white/5 border-white/15 text-white hover:bg-white/10 rounded-full px-5">
            <Edit3 className="h-3.5 w-3.5 mr-1.5" />
            Edit Profile
          </Button>
        </div>
      </GlassCard>

      {/* Quick links */}
      <Tabs defaultValue="account" className="w-full">
        <TabsList className="w-full bg-white/5 border border-white/10 p-1 rounded-xl">
          <TabsTrigger value="account" className="flex-1 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white text-white/50">
            Account
          </TabsTrigger>
          <TabsTrigger value="activity" className="flex-1 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white text-white/50">
            Activity
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex-1 rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white text-white/50">
            Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="account" className="mt-4 outline-none">
          <GlassCard className="divide-y divide-white/8">
            <QuickLinkRow icon={ShoppingBag} label="My Orders"       sub="Track and manage orders"    href="/orders"      color="text-blue-400 bg-blue-500/10" />
            <QuickLinkRow icon={Heart}       label="Wishlist"        sub="Saved products"             href="/marketplace" color="text-red-400 bg-red-500/10" />
            <QuickLinkRow icon={Star}        label="My Reviews"      sub="Reviews I've written"       href="/orders"      color="text-yellow-400 bg-yellow-500/10" />
            <QuickLinkRow icon={MapPin}      label="Saved Addresses" sub="Shipping addresses"         href="/profile"     color="text-green-400 bg-green-500/10" />
            <QuickLinkRow icon={Package}     label="Returns & Refunds" sub="Track return requests"   href="/orders"      color="text-orange-400 bg-orange-500/10" />
          </GlassCard>
        </TabsContent>

        <TabsContent value="activity" className="mt-4 outline-none">
          <GlassCard className="divide-y divide-white/8">
            {user.isSeller && (
              <QuickLinkRow icon={Store} label="Seller Dashboard" sub="Manage your shop"   href="/seller"        color="text-purple-400 bg-purple-500/10" />
            )}
            <QuickLinkRow icon={Heart}  label="Following"        sub="Vendors you follow"  href="/vendors"       color="text-pink-400 bg-pink-500/10" />
            <QuickLinkRow icon={Bell}   label="Notifications"    sub="Alerts & updates"    href="/notifications" color="text-primary bg-primary/10" />
          </GlassCard>
        </TabsContent>

        <TabsContent value="settings" className="mt-4 outline-none">
          <GlassCard className="divide-y divide-white/8">
            <QuickLinkRow icon={Settings}    label="Account Settings" sub="Privacy, password, 2FA"   href="/profile"             color="text-white/60 bg-white/5" />
            <QuickLinkRow icon={Shield}      label="Security"         sub="Login activity & sessions" href="/profile"             color="text-green-400 bg-green-500/10" />
            <QuickLinkRow icon={CheckCircle} label="Verification"     sub="Verify your identity"      href="/seller/verification" color="text-blue-400 bg-blue-500/10" />
            <QuickLinkRow icon={LogOut}      label="Sign Out"         sub=""                          href="/"                    color="text-red-400 bg-red-500/10" />
          </GlassCard>
        </TabsContent>
      </Tabs>
    </div>
  );
}
