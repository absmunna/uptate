import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import {
  Leaf, Search, ShoppingCart, Star, MapPin, ChevronRight,
  CloudRain, Sun, Wind, Droplets, Tractor, Package,
  TrendingUp, AlertTriangle, BadgeCheck, Scale,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useListProducts, getListProductsQueryKey } from "@workspace/api-client-react";

const WEATHER = { temp: "28°C", condition: "Partly Cloudy", humidity: "82%", wind: "12 km/h", rain: "60% chance", location: "Dhaka" };

const CROP_CATS = [
  { label: "Rice",        color: "text-yellow-400 bg-yellow-500/10", count: 48 },
  { label: "Vegetables",  color: "text-green-400 bg-green-500/10",  count: 120 },
  { label: "Fish",        color: "text-blue-400 bg-blue-500/10",    count: 65 },
  { label: "Fruits",      color: "text-orange-400 bg-orange-500/10",count: 80 },
  { label: "Livestock",   color: "text-red-400 bg-red-500/10",      count: 35 },
  { label: "Seeds",       color: "text-lime-400 bg-lime-500/10",    count: 90 },
];

const MARKET_PRICES = [
  { item: "Fine Rice (50kg)",      price: "৳2,800", change: "+2.1%",   up: true },
  { item: "Tomato (per kg)",       price: "৳65",    change: "-5.3%",   up: false },
  { item: "Hilsa Fish (per kg)",   price: "৳850",   change: "+8.2%",   up: true },
  { item: "Onion (per kg)",        price: "৳45",    change: "-12.0%",  up: false },
  { item: "Potato (50kg)",         price: "৳1,200", change: "+0.5%",   up: true },
  { item: "Brinjal (per kg)",      price: "৳40",    change: "-2.8%",   up: false },
];

export default function AgriculturePage() {
  const [activeTab, setActiveTab] = useState<"market" | "inputs" | "advisory">("market");
  const [search, setSearch] = useState("");

  const { data: products } = useListProducts(
    { type: "grocery", limit: 6 },
    { query: { queryKey: getListProductsQueryKey({ type: "grocery", limit: 6 }) } }
  );

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <GlassCard className="p-5 bg-gradient-to-br from-green-700/25 via-emerald-600/15 to-transparent border border-green-500/25 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(34,197,94,0.12),transparent_60%)]" />
        <div className="relative flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <Leaf className="h-4 w-4 text-green-400" />
              <span className="text-xs font-bold text-green-300 uppercase tracking-widest">PaikarKrishi</span>
            </div>
            <h1 className="text-xl font-bold text-white mb-1">Bangladesh Agriculture Hub</h1>
            <p className="text-xs text-white/50">Fair prices, inputs, weather, and advisory — for our farmers.</p>
          </div>
          <div className="shrink-0 text-right">
            <div className="flex items-center gap-2 justify-end">
              <Sun className="h-5 w-5 text-yellow-400" />
              <span className="text-2xl font-bold text-white">{WEATHER.temp}</span>
            </div>
            <p className="text-xs text-white/50">{WEATHER.condition}</p>
            <p className="text-xs text-white/35">{WEATHER.location}</p>
          </div>
        </div>
        {/* Weather strip */}
        <div className="grid grid-cols-3 gap-2 mt-4">
          {[
            { icon: Droplets, label: "Humidity",  value: WEATHER.humidity, color: "text-blue-400" },
            { icon: Wind,     label: "Wind",       value: WEATHER.wind,     color: "text-cyan-400" },
            { icon: CloudRain,label: "Rain",       value: WEATHER.rain,     color: "text-indigo-400" },
          ].map(w => { const Icon = w.icon; return (
            <div key={w.label} className="bg-white/5 border border-green-500/15 rounded-xl p-2.5 flex items-center gap-2">
              <Icon className={cn("h-4 w-4 shrink-0", w.color)} />
              <div>
                <p className="text-xs font-semibold text-white">{w.value}</p>
                <p className="text-[9px] text-white/35">{w.label}</p>
              </div>
            </div>
          ); })}
        </div>
      </GlassCard>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {([["market","Market Prices"],["inputs","Farm Inputs"],["advisory","Advisory"]] as const).map(([t,l]) => (
          <button key={t} onClick={() => setActiveTab(t)} className={cn("flex-1 py-2.5 rounded-lg text-sm font-medium transition-all", activeTab===t?"bg-primary text-white":"text-white/50 hover:text-white")}>{l}</button>
        ))}
      </div>

      {activeTab === "market" && (
        <div className="flex flex-col gap-5">
          {/* Live prices */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-base font-semibold text-white">Live Market Prices</h2>
              <span className="text-xs text-white/35 flex items-center gap-1"><TrendingUp className="h-3 w-3" /> Live</span>
            </div>
            <div className="flex flex-col gap-2">
              {MARKET_PRICES.map(p => (
                <GlassCard key={p.item} className="p-3.5 flex items-center gap-3">
                  <div className="flex-1">
                    <p className="text-sm text-white font-medium">{p.item}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-white">{p.price}</p>
                    <p className={cn("text-[11px] font-bold", p.up ? "text-green-400" : "text-red-400")}>{p.change}</p>
                  </div>
                </GlassCard>
              ))}
            </div>
          </div>

          {/* Categories */}
          <div>
            <h2 className="text-base font-semibold text-white mb-3">Sell by Category</h2>
            <div className="grid grid-cols-3 gap-2">
              {CROP_CATS.map(c => (
                <button key={c.label} className={cn("p-3 rounded-xl border border-white/10 bg-white/5 hover:bg-white/8 transition-colors flex flex-col items-center gap-1.5", c.color.includes("green") ? "hover:border-green-500/20" : "")}>
                  <p className={cn("text-sm font-bold", c.color.split(" ")[0])}>{c.count}+</p>
                  <p className="text-xs text-white/60">{c.label}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Products from API */}
          {products && products.length > 0 && (
            <div>
              <h2 className="text-base font-semibold text-white mb-3">Fresh Listings</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {products.map(p => (
                  <GlassCard key={p.id} className="overflow-hidden glass-card-hover cursor-pointer p-0">
                    {p.images?.[0] && <img src={p.images[0]} alt={p.title} className="w-full h-24 object-cover" />}
                    <div className="p-3">
                      <p className="text-xs font-bold text-white leading-tight truncate">{p.title}</p>
                      <p className="text-sm font-bold text-primary mt-1">৳{p.price}</p>
                      <Button size="sm" className="w-full mt-2 bg-green-500/20 hover:bg-green-500/30 text-green-400 border border-green-500/30 rounded-full text-xs h-7">
                        <ShoppingCart className="h-3 w-3 mr-1" /> Buy
                      </Button>
                    </div>
                  </GlassCard>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === "inputs" && (
        <div className="flex flex-col gap-5">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35 pointer-events-none" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search seeds, fertilizers, tools..." className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            {[
              { name: "BRRI Dhan 28 (5kg)", price: "৳240", category: "Seeds", icon: Leaf, color: "text-lime-400 bg-lime-500/10" },
              { name: "Urea Fertilizer (50kg)", price: "৳1,100", category: "Fertilizer", icon: Package, color: "text-blue-400 bg-blue-500/10" },
              { name: "Power Tiller (rent/day)", price: "৳1,800", category: "Equipment", icon: Tractor, color: "text-orange-400 bg-orange-500/10" },
              { name: "Pesticide Set (3pcs)", price: "৳350", category: "Protection", icon: AlertTriangle, color: "text-yellow-400 bg-yellow-500/10" },
              { name: "Irrigation Pipe (100m)", price: "৳2,200", category: "Irrigation", icon: Droplets, color: "text-cyan-400 bg-cyan-500/10" },
              { name: "Weighing Scale (50kg)", price: "৳1,600", category: "Tool", icon: Scale, color: "text-purple-400 bg-purple-500/10" },
            ].map(item => { const Icon = item.icon; return (
              <GlassCard key={item.name} className="p-3.5 glass-card-hover cursor-pointer">
                <div className={cn("h-9 w-9 rounded-xl flex items-center justify-center mb-2", item.color)}>
                  <Icon className="h-4.5 w-[18px] h-[18px]" />
                </div>
                <p className="text-xs font-semibold text-white leading-tight">{item.name}</p>
                <p className="text-[10px] text-white/35 mt-0.5">{item.category}</p>
                <p className="text-sm font-bold text-primary mt-1.5">{item.price}</p>
                <Button size="sm" className="w-full mt-2 bg-primary/15 hover:bg-primary/25 text-primary rounded-full text-xs h-7">Add to Cart</Button>
              </GlassCard>
            ); })}
          </div>
        </div>
      )}

      {activeTab === "advisory" && (
        <div className="flex flex-col gap-3">
          {[
            { title: "Boro Season Planting Guide",   desc: "Best varieties for this season's Boro rice. Soil preparation tips from BRRI experts.", tag: "Rice", urgency: false },
            { title: "Flood Alert — Sylhet Region",  desc: "Heavy rains expected. Farmers in low-lying areas should harvest early.", tag: "Alert", urgency: true },
            { title: "Potato Blight Prevention",     desc: "Early monsoon increases blight risk. Use resistant varieties and pre-emptive fungicide.", tag: "Vegetables", urgency: false },
            { title: "Govt Subsidy: Fertilizer",     desc: "New subsidy available for small farmers under 2 acres. Apply via Union Parishad.", tag: "Subsidy", urgency: false },
          ].map(a => (
            <GlassCard key={a.title} className={cn("p-4 glass-card-hover cursor-pointer", a.urgency && "border-red-500/30 bg-red-500/5")}>
              <div className="flex items-start gap-3">
                <div className={cn("h-9 w-9 rounded-xl flex items-center justify-center shrink-0", a.urgency ? "bg-red-500/15" : "bg-green-500/10")}>
                  {a.urgency ? <AlertTriangle className="h-5 w-5 text-red-400" /> : <Leaf className="h-5 w-5 text-green-400" />}
                </div>
                <div className="flex-1">
                  <div className="flex items-start gap-2 justify-between flex-wrap">
                    <p className="text-sm font-bold text-white">{a.title}</p>
                    <span className={cn("text-[9px] font-bold px-2 py-0.5 rounded-full border shrink-0", a.urgency ? "bg-red-500/15 text-red-400 border-red-500/25" : "bg-green-500/15 text-green-400 border-green-500/25")}>{a.tag}</span>
                  </div>
                  <p className="text-xs text-white/45 mt-1">{a.desc}</p>
                </div>
              </div>
            </GlassCard>
          ))}
          <GlassCard className="p-4 flex items-center gap-4 border border-green-500/20 bg-green-500/5">
            <BadgeCheck className="h-8 w-8 text-green-400 shrink-0" />
            <div>
              <p className="font-semibold text-white text-sm">Ask an Expert</p>
              <p className="text-xs text-white/45 mt-0.5">Get free advice from certified agronomists via chat or call.</p>
            </div>
            <Button className="bg-green-500/20 hover:bg-green-500/30 text-green-300 border border-green-500/30 rounded-full text-xs shrink-0">Ask Now</Button>
          </GlassCard>
        </div>
      )}
    </div>
  );
}
