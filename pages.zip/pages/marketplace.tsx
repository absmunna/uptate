import { useLocation } from "wouter";
import {
  useListProducts, getListProductsQueryKey,
  ListProductsType, ListProductsSort
} from "@workspace/api-client-react";
import { ProductGrid } from "@/components/product/ProductGrid";
import { CategoryChips } from "@/components/product/CategoryChips";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import { GlassCard } from "@/components/ui/GlassCard";
import { SlidersHorizontal, ArrowUpDown, Navigation } from "lucide-react";
import { cn } from "@/lib/utils";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useState } from "react";

const TYPE_PILLS: { value: ListProductsType | "all"; label: string }[] = [
  { value: "all",       label: "All" },
  { value: "retail",    label: "Retail" },
  { value: "wholesale", label: "Wholesale" },
  { value: "dropship",  label: "Dropship" },
  { value: "grocery",   label: "Grocery" },
  { value: "service",   label: "Services" },
  { value: "hotel",     label: "Travel" },
];

const SORT_OPTS: { value: ListProductsSort; label: string }[] = [
  { value: "newest",     label: "Newest" },
  { value: "trending",   label: "Trending" },
  { value: "price_asc",  label: "Price ↑" },
  { value: "price_desc", label: "Price ↓" },
  { value: "rating",     label: "Top Rated" },
];

export default function Marketplace() {
  const [, setLocation] = useLocation();
  const [showSort, setShowSort] = useState(false);

  const searchParams = new URLSearchParams(window.location.search);
  const q          = searchParams.get("q") || undefined;
  const categoryId = searchParams.get("categoryId") || undefined;
  const type       = (searchParams.get("type") as ListProductsType) || undefined;
  const sort       = (searchParams.get("sort") as ListProductsSort) || undefined;
  const nearMe     = searchParams.get("nearMe") === "true";

  const { data: products, isLoading } = useListProducts(
    { q, categoryId, type, sort, nearMe },
    { query: { queryKey: getListProductsQueryKey({ q, categoryId, type, sort, nearMe }) } }
  );

  const setParam = (key: string, value: string | null) => {
    const p = new URLSearchParams(window.location.search);
    if (value === null) p.delete(key); else p.set(key, value);
    setLocation(`/marketplace?${p.toString()}`);
  };

  const activeSort = sort ?? "newest";

  return (
    <div className="flex flex-col gap-4 p-4 md:p-5">
      <PortalIconBar />
      <CategoryChips activeId={categoryId} />

      {/* Type pills row */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        {TYPE_PILLS.map(({ value, label }) => {
          const active = (value === "all" && !type) || value === type;
          return (
            <button
              key={value}
              onClick={() => setParam("type", value === "all" ? null : value)}
              className={cn(
                "shrink-0 px-3.5 py-1.5 rounded-full text-sm font-medium border transition-all whitespace-nowrap",
                active
                  ? "bg-primary border-primary text-white shadow-md shadow-primary/30"
                  : "bg-white/5 border-white/10 text-white/60 hover:text-white hover:bg-white/10"
              )}
            >
              {label}
            </button>
          );
        })}
      </div>

      {/* Filter bar */}
      <GlassCard className="px-4 py-3 flex items-center gap-4 flex-wrap">
        <div className="flex items-center gap-2">
          <Switch
            id="near-me"
            checked={nearMe}
            onCheckedChange={(v) => setParam("nearMe", v ? "true" : null)}
          />
          <Label htmlFor="near-me" className="text-sm text-white cursor-pointer flex items-center gap-1">
            <Navigation className="w-3.5 h-3.5 text-primary" /> Near Me
          </Label>
        </div>

        <div className="h-4 w-px bg-white/10 hidden sm:block" />

        {/* Sort pills */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
          <ArrowUpDown className="w-3.5 h-3.5 text-white/40 shrink-0" />
          {SORT_OPTS.map(({ value, label }) => (
            <button
              key={value}
              onClick={() => setParam("sort", value)}
              className={cn(
                "shrink-0 text-xs px-2.5 py-1 rounded-lg border transition-all",
                activeSort === value
                  ? "bg-primary/20 border-primary/40 text-primary"
                  : "bg-white/5 border-white/10 text-white/50 hover:text-white"
              )}
            >
              {label}
            </button>
          ))}
        </div>

        {(type || nearMe || sort) && (
          <button
            onClick={() => setLocation("/marketplace")}
            className="ml-auto text-xs text-white/40 hover:text-white transition-colors"
          >
            Clear filters
          </button>
        )}
      </GlassCard>

      {q && (
        <h2 className="text-lg font-semibold text-white">
          Search results for "<span className="text-primary">{q}</span>"
          {products && <span className="text-white/40 text-sm font-normal ml-2">({products.length} items)</span>}
        </h2>
      )}

      <ProductGrid products={products} isLoading={isLoading} emptyMessage="No products match your filters." />
    </div>
  );
}
