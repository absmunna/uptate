import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import {
  Building, MapPin, Star, Search, Home, BedDouble, Bath, Maximize2,
  ChevronRight, Heart, BadgeCheck, TrendingUp, DollarSign, Eye, Phone,
} from "lucide-react";
import { cn } from "@/lib/utils";

const PROPERTY_TYPES = [
  { label: "Apartment",    icon: Building,   active: true },
  { label: "House",        icon: Home,       active: false },
  { label: "Office",       icon: Building,   active: false },
  { label: "Land",         icon: Maximize2,  active: false },
];

const LISTINGS = [
  { id: "p1", title: "3BHK Apartment in Gulshan 2", type: "apartment", price: "৳2.5 Cr", rent: "৳65,000/mo", area: "1,850 sqft", beds: 3, baths: 3, img: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=400", location: "Gulshan 2, Dhaka", verified: true, views: 340, forSale: true },
  { id: "p2", title: "2BHK Fully Furnished Flat",   type: "apartment", price: "৳85 L",   rent: "৳38,000/mo", area: "1,200 sqft", beds: 2, baths: 2, img: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=400", location: "Banani, Dhaka",   verified: true, views: 210, forSale: true },
  { id: "p3", title: "Commercial Office Space",     type: "office",    price: "৳1.8 Cr", rent: "৳80,000/mo", area: "2,400 sqft", beds: 0, baths: 4, img: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=400", location: "Motijheel, Dhaka",verified: true, views: 156, forSale: true },
  { id: "p4", title: "Duplex House with Garden",   type: "house",     price: "৳4.2 Cr", rent: "৳1,20,000/mo",area: "3,600 sqft", beds: 5, baths: 4, img: "https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=400", location: "Uttara, Dhaka",   verified: false,views: 89,  forSale: true },
];

const AREAS = ["Gulshan", "Banani", "Dhanmondi", "Uttara", "Mirpur", "Mohammadpur", "Baridhara", "Bashundhara"];

export default function RealEstatePage() {
  const [activeTab, setActiveTab] = useState<"buy" | "rent" | "new">("buy");
  const [search, setSearch] = useState("");
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [activeType, setActiveType] = useState("Apartment");

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <div className="relative rounded-3xl overflow-hidden border border-blue-500/20 h-44 md:h-52">
        <img src="https://images.unsplash.com/photo-1486325212027-8081e485255e?w=1200" alt="Real Estate" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent" />
        <div className="absolute bottom-4 left-5 right-5">
          <div className="flex items-center gap-2 mb-1">
            <Building className="h-4 w-4 text-blue-400" />
            <span className="text-xs font-bold text-blue-300 uppercase tracking-widest">PaikarProperties</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Find Your Dream Home</h1>
          <p className="text-sm text-white/60">Buy, rent, or invest in properties across Bangladesh</p>
        </div>
      </div>

      {/* Buy/Rent/New tabs */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {([["buy", "Buy"], ["rent", "Rent"], ["new", "New Projects"]] as const).map(([tab, label]) => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={cn("flex-1 py-2.5 rounded-lg text-sm font-medium transition-all",
              activeTab === tab ? "bg-primary text-white" : "text-white/50 hover:text-white")}>
            {label}
          </button>
        ))}
      </div>

      {/* Search */}
      <GlassCard className="p-4 flex flex-col gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35 pointer-events-none" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by location, property type..."
            className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
        </div>
        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {AREAS.map((area) => (
            <button key={area} className="shrink-0 text-xs bg-white/5 hover:bg-white/10 border border-white/10 text-white/60 hover:text-white px-3 py-1.5 rounded-full transition-all">
              {area}
            </button>
          ))}
        </div>
      </GlassCard>

      {/* Property type */}
      <div className="flex gap-2">
        {PROPERTY_TYPES.map((t) => (
          <button key={t.label} onClick={() => setActiveType(t.label)}
            className={cn(
              "flex-1 py-2.5 rounded-xl border text-sm font-medium transition-all flex items-center justify-center gap-1.5",
              activeType === t.label ? "bg-primary/15 border-primary/40 text-primary" : "bg-white/5 border-white/10 text-white/50 hover:text-white"
            )}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Listings",     value: "12,400+", icon: Building,   color: "text-blue-400 bg-blue-500/10" },
          { label: "Verified",     value: "8,200+",  icon: BadgeCheck, color: "text-green-400 bg-green-500/10" },
          { label: "Sold This Month",value: "340",   icon: TrendingUp, color: "text-primary bg-primary/10" },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <GlassCard key={s.label} className="p-3.5 flex items-center gap-3">
              <div className={cn("h-9 w-9 rounded-xl flex items-center justify-center shrink-0", s.color)}>
                <Icon className="h-4 w-4" />
              </div>
              <div>
                <p className="text-base font-bold text-white">{s.value}</p>
                <p className="text-[10px] text-white/40">{s.label}</p>
              </div>
            </GlassCard>
          );
        })}
      </div>

      {/* Listings */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-base font-semibold text-white">
            {activeTab === "buy" ? "Properties for Sale" : activeTab === "rent" ? "Properties for Rent" : "New Projects"}
          </h2>
          <span className="text-xs text-primary cursor-pointer hover:underline flex items-center gap-0.5">
            See all <ChevronRight className="h-3 w-3" />
          </span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {LISTINGS.map((p) => (
            <GlassCard key={p.id} className="overflow-hidden glass-card-hover cursor-pointer p-0">
              <div className="relative h-44">
                <img src={p.img} alt={p.title} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <button
                  onClick={(e) => { e.stopPropagation(); setFavorites((prev) => { const n = new Set(prev); n.has(p.id) ? n.delete(p.id) : n.add(p.id); return n; }); }}
                  className="absolute top-2 right-2 h-8 w-8 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center"
                >
                  <Heart className={cn("h-4 w-4", favorites.has(p.id) ? "fill-red-400 text-red-400" : "text-white/70")} />
                </button>
                {p.verified && (
                  <div className="absolute top-2 left-2 flex items-center gap-1 bg-green-500/90 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                    <BadgeCheck className="h-3 w-3" /> Verified
                  </div>
                )}
                <div className="absolute bottom-2 left-3 flex items-center gap-1.5 text-xs text-white/70">
                  <Eye className="h-3 w-3" /> {p.views} views
                </div>
              </div>
              <div className="p-3.5">
                <p className="text-sm font-bold text-white leading-tight">{p.title}</p>
                <div className="flex items-center gap-1 text-xs text-white/40 mt-1 mb-2">
                  <MapPin className="h-3 w-3 shrink-0" /> {p.location}
                </div>
                <div className="flex items-center gap-3 text-xs text-white/55 mb-3">
                  {p.beds > 0 && <span className="flex items-center gap-1"><BedDouble className="h-3.5 w-3.5" /> {p.beds} Beds</span>}
                  <span className="flex items-center gap-1"><Bath className="h-3.5 w-3.5" /> {p.baths} Bath</span>
                  <span className="flex items-center gap-1"><Maximize2 className="h-3.5 w-3.5" /> {p.area}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-base font-bold text-primary">{activeTab === "rent" ? p.rent : p.price}</p>
                    {activeTab !== "rent" && <p className="text-[10px] text-white/35">or {p.rent}</p>}
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="h-8 border-white/20 bg-white/5 text-white hover:bg-white/10 rounded-full w-8 p-0">
                      <Phone className="h-3.5 w-3.5" />
                    </Button>
                    <Button size="sm" className="h-8 bg-primary hover:bg-primary/90 text-white rounded-full text-xs px-3">View</Button>
                  </div>
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>

      {/* CTA for agents */}
      <GlassCard className="p-5 flex items-center gap-4 border border-primary/20 bg-primary/5">
        <div className="h-12 w-12 rounded-2xl bg-primary/15 flex items-center justify-center shrink-0">
          <DollarSign className="h-6 w-6 text-primary" />
        </div>
        <div className="flex-1">
          <p className="font-semibold text-white">Are you a property agent?</p>
          <p className="text-xs text-white/45 mt-0.5">List your properties and reach thousands of verified buyers.</p>
        </div>
        <Button className="bg-primary hover:bg-primary/90 text-white rounded-full text-sm shrink-0">List Now</Button>
      </GlassCard>
    </div>
  );
}
