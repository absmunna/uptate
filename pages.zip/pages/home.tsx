import { useListPosts, getListPostsQueryKey, useGetPlatformStats, getGetPlatformStatsQueryKey } from "@workspace/api-client-react";
import { StoryBar } from "@/components/feed/StoryBar";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import { PostCard } from "@/components/feed/PostCard";
import { SuggestedVendors } from "@/components/feed/SuggestedVendors";
import { TrendingRail } from "@/components/feed/TrendingRail";
import { GlassCard } from "@/components/ui/GlassCard";
import { Users, Store, ShoppingBag, TrendingUp, Zap, ArrowRight } from "lucide-react";
import { Link } from "wouter";

function StatCard({ icon: Icon, value, label, color }: { icon: React.ElementType; value: string; label: string; color: string }) {
  return (
    <GlassCard className="p-4 flex flex-col items-center justify-center text-center gap-1.5">
      <div className={`h-10 w-10 rounded-xl flex items-center justify-center bg-white/5 ${color}`}>
        <Icon className="h-5 w-5" />
      </div>
      <p className="text-xl font-bold text-white">{value}</p>
      <p className="text-[11px] text-white/45">{label}</p>
    </GlassCard>
  );
}

function PostSkeleton() {
  return (
    <div className="glass-card rounded-2xl p-4 flex flex-col gap-4">
      <div className="flex items-center gap-3">
        <div className="h-10 w-10 rounded-full skeleton-shimmer shrink-0" />
        <div className="flex-1 flex flex-col gap-2">
          <div className="h-3 w-1/3 rounded skeleton-shimmer" />
          <div className="h-3 w-1/4 rounded skeleton-shimmer" />
        </div>
      </div>
      <div className="aspect-video rounded-xl skeleton-shimmer" />
    </div>
  );
}

export default function Home() {
  const { data: posts } = useListPosts({}, { query: { queryKey: getListPostsQueryKey() } });
  const { data: stats } = useGetPlatformStats({ query: { queryKey: getGetPlatformStatsQueryKey() } });

  return (
    <div className="flex flex-col lg:flex-row gap-5 p-4 md:p-5">
      {/* Feed column */}
      <div className="flex-1 min-w-0 max-w-2xl mx-auto lg:mx-0 w-full flex flex-col gap-4">
        <StoryBar />
        <PortalIconBar />

        {/* Flash promo banner */}
        <Link href="/marketplace?sort=trending">
          <div className="glass-card rounded-2xl p-4 flex items-center gap-3 border border-primary/20 bg-primary/5 cursor-pointer hover:bg-primary/10 transition-colors">
            <div className="h-10 w-10 rounded-xl bg-primary/20 flex items-center justify-center shrink-0">
              <Zap className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white">Flash Deals Live Now</p>
              <p className="text-xs text-white/50 truncate">Up to 60% off on trending products</p>
            </div>
            <ArrowRight className="h-4 w-4 text-primary shrink-0" />
          </div>
        </Link>

        {/* Posts feed */}
        <div className="flex flex-col gap-4">
          {posts === undefined
            ? Array.from({ length: 3 }).map((_, i) => <PostSkeleton key={i} />)
            : posts.map((post) => <PostCard key={post.id} post={post} />)
          }
        </div>

        {/* Platform stats */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
            <StatCard icon={ShoppingBag} value={stats.totalProducts.toLocaleString()} label="Products" color="text-primary" />
            <StatCard icon={Store}       value={stats.totalVendors.toLocaleString()}  label="Vendors"  color="text-purple-400" />
            <StatCard icon={Users}       value={stats.totalUsers.toLocaleString()}    label="Members"  color="text-blue-400" />
            <StatCard icon={TrendingUp}  value={`৳${stats.dailyGmv.toLocaleString()}`} label="Daily GMV" color="text-green-400" />
          </div>
        )}
      </div>

      {/* Right rail — desktop only */}
      <aside className="hidden lg:flex w-72 xl:w-80 flex-col gap-5 shrink-0">
        <TrendingRail />
        <SuggestedVendors />
      </aside>
    </div>
  );
}
