import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Search, Send, Phone, Video, MoreHorizontal,
  ArrowLeft, CheckCheck, Circle, MessageSquare,
  Image as ImageIcon, Paperclip, Smile,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";

const THREADS = [
  {
    id: "t1",
    name: "Fresh Block Market",
    avatar: "https://images.unsplash.com/photo-1542838132-92c53300491e?w=80",
    lastMsg: "Your order has been confirmed!",
    time: new Date(Date.now() - 5 * 60 * 1000),
    unread: 2,
    online: true,
    type: "vendor",
  },
  {
    id: "t2",
    name: "Lumen Studio",
    avatar: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=80",
    lastMsg: "We have a new offer for you",
    time: new Date(Date.now() - 1 * 60 * 60 * 1000),
    unread: 0,
    online: true,
    type: "vendor",
  },
  {
    id: "t3",
    name: "FixIt Pros",
    avatar: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=80",
    lastMsg: "Technician will arrive at 3PM",
    time: new Date(Date.now() - 3 * 60 * 60 * 1000),
    unread: 1,
    online: false,
    type: "vendor",
  },
  {
    id: "t4",
    name: "Hearth & Co",
    avatar: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=80",
    lastMsg: "Thank you for your purchase!",
    time: new Date(Date.now() - 24 * 60 * 60 * 1000),
    unread: 0,
    online: false,
    type: "vendor",
  },
  {
    id: "t5",
    name: "PaikarMart Support",
    avatar: "",
    lastMsg: "Your issue has been resolved.",
    time: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    unread: 0,
    online: true,
    type: "support",
  },
];

const SAMPLE_MSGS = [
  { id: "m1", text: "Hi! I'm interested in bulk ordering the Aurora headphones.", mine: true, time: new Date(Date.now() - 30 * 60 * 1000) },
  { id: "m2", text: "Great choice! We offer 15% discount on orders above 50 units.", mine: false, time: new Date(Date.now() - 28 * 60 * 1000) },
  { id: "m3", text: "Can you do 20% for 100 units?", mine: true, time: new Date(Date.now() - 25 * 60 * 1000) },
  { id: "m4", text: "Let me check with my manager and get back to you shortly.", mine: false, time: new Date(Date.now() - 24 * 60 * 1000) },
  { id: "m5", text: "Sure, take your time!", mine: true, time: new Date(Date.now() - 20 * 60 * 1000) },
  { id: "m6", text: "Good news! We can do 18% for 100 units with free shipping included.", mine: false, time: new Date(Date.now() - 10 * 60 * 1000) },
  { id: "m7", text: "Your order has been confirmed!", mine: false, time: new Date(Date.now() - 5 * 60 * 1000) },
];

export default function MessagesPage() {
  const [activeThread, setActiveThread] = useState<string | null>("t1");
  const [message, setMessage] = useState("");
  const [mobileView, setMobileView] = useState<"list" | "chat">("list");

  const thread = THREADS.find((t) => t.id === activeThread);

  const handleSend = () => {
    if (!message.trim()) return;
    setMessage("");
  };

  return (
    <div className="flex h-[calc(100dvh-60px-env(safe-area-inset-bottom))] md:h-[calc(100dvh-112px)] overflow-hidden">
      {/* Thread list */}
      <div
        className={cn(
          "flex flex-col border-r border-white/8 bg-[#0c1322] w-full md:w-[320px] lg:w-[360px] shrink-0",
          mobileView === "chat" ? "hidden md:flex" : "flex"
        )}
      >
        {/* Header */}
        <div className="p-4 border-b border-white/8 flex items-center gap-3">
          <div className="flex-1">
            <h2 className="text-lg font-bold text-white">Messages</h2>
            <p className="text-xs text-white/45">
              {THREADS.filter((t) => t.unread > 0).length} unread
            </p>
          </div>
          <button className="h-9 w-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white/50 hover:text-white transition-colors">
            <MessageSquare className="h-4 w-4" />
          </button>
        </div>

        {/* Search */}
        <div className="px-4 py-3 border-b border-white/8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-white/35 pointer-events-none" />
            <Input
              placeholder="Search messages..."
              className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl h-9 text-sm"
            />
          </div>
        </div>

        {/* Threads */}
        <div className="flex-1 overflow-y-auto">
          {THREADS.map((t) => {
            const isActive = activeThread === t.id;
            return (
              <button
                key={t.id}
                onClick={() => { setActiveThread(t.id); setMobileView("chat"); }}
                className={cn(
                  "w-full flex items-center gap-3 p-4 border-b border-white/5 transition-colors text-left",
                  isActive ? "bg-primary/10 border-l-2 border-l-primary" : "hover:bg-white/5"
                )}
              >
                <div className="relative shrink-0">
                  <Avatar className="h-11 w-11 border border-white/15">
                    <AvatarImage src={t.avatar} />
                    <AvatarFallback className="bg-primary/20 text-primary text-sm font-semibold">
                      {t.name[0]}
                    </AvatarFallback>
                  </Avatar>
                  {t.online && (
                    <div className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full bg-green-400 border-2 border-[#0c1322]" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-0.5">
                    <span className="text-sm font-semibold text-white truncate">{t.name}</span>
                    <span className="text-[10px] text-white/35 shrink-0">
                      {formatDistanceToNow(t.time, { addSuffix: false })}
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-xs text-white/50 truncate">{t.lastMsg}</p>
                    {t.unread > 0 && (
                      <span className="shrink-0 min-w-[18px] h-[18px] rounded-full bg-primary flex items-center justify-center text-[9px] text-white font-bold px-1">
                        {t.unread}
                      </span>
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Chat area */}
      <div
        className={cn(
          "flex-1 flex flex-col",
          mobileView === "list" ? "hidden md:flex" : "flex"
        )}
      >
        {thread ? (
          <>
            {/* Chat header */}
            <div className="h-[60px] border-b border-white/8 flex items-center gap-3 px-4 bg-[#0c1322]">
              <button
                className="md:hidden h-8 w-8 flex items-center justify-center text-white/60 hover:text-white"
                onClick={() => setMobileView("list")}
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
              <div className="relative shrink-0">
                <Avatar className="h-9 w-9 border border-white/15">
                  <AvatarImage src={thread.avatar} />
                  <AvatarFallback className="bg-primary/20 text-primary text-sm font-bold">{thread.name[0]}</AvatarFallback>
                </Avatar>
                {thread.online && (
                  <div className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-green-400 border-2 border-[#0c1322]" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white">{thread.name}</p>
                <p className="text-xs text-white/40">{thread.online ? "Online" : "Offline"}</p>
              </div>
              <div className="flex items-center gap-1">
                <button className="h-8 w-8 rounded-lg bg-white/5 flex items-center justify-center text-white/50 hover:text-white transition-colors">
                  <Phone className="h-4 w-4" />
                </button>
                <button className="h-8 w-8 rounded-lg bg-white/5 flex items-center justify-center text-white/50 hover:text-white transition-colors">
                  <Video className="h-4 w-4" />
                </button>
                <button className="h-8 w-8 rounded-lg bg-white/5 flex items-center justify-center text-white/50 hover:text-white transition-colors">
                  <MoreHorizontal className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-3 bg-[#0a1120]">
              {SAMPLE_MSGS.map((msg) => (
                <div key={msg.id} className={cn("flex", msg.mine ? "justify-end" : "justify-start")}>
                  <div
                    className={cn(
                      "max-w-[75%] rounded-2xl px-4 py-2.5 text-sm",
                      msg.mine
                        ? "bg-primary text-white rounded-br-sm"
                        : "bg-white/8 text-white/90 rounded-bl-sm border border-white/8"
                    )}
                  >
                    <p className="leading-relaxed">{msg.text}</p>
                    <div className={cn("flex items-center gap-1 mt-1", msg.mine ? "justify-end" : "justify-start")}>
                      <span className="text-[10px] opacity-60">
                        {formatDistanceToNow(msg.time, { addSuffix: true })}
                      </span>
                      {msg.mine && <CheckCheck className="h-3 w-3 text-white/60" />}
                    </div>
                  </div>
                </div>
              ))}
              {/* Typing indicator */}
              <div className="flex justify-start">
                <div className="bg-white/8 border border-white/8 rounded-2xl rounded-bl-sm px-4 py-3 flex items-center gap-1">
                  {[0, 1, 2].map((i) => (
                    <div
                      key={i}
                      className="h-1.5 w-1.5 rounded-full bg-white/40 animate-bounce"
                      style={{ animationDelay: `${i * 150}ms` }}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Input */}
            <div className="p-3 border-t border-white/8 bg-[#0c1322]">
              <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-2xl px-3 py-2">
                <button className="text-white/40 hover:text-white/70 transition-colors shrink-0">
                  <Smile className="h-5 w-5" />
                </button>
                <Input
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSend()}
                  placeholder="Type a message..."
                  className="border-0 bg-transparent text-white placeholder:text-white/30 focus-visible:ring-0 px-1 text-sm h-auto"
                />
                <button className="text-white/40 hover:text-white/70 transition-colors shrink-0">
                  <Paperclip className="h-4 w-4" />
                </button>
                <button className="text-white/40 hover:text-white/70 transition-colors shrink-0">
                  <ImageIcon className="h-4 w-4" />
                </button>
                <Button
                  onClick={handleSend}
                  size="icon"
                  disabled={!message.trim()}
                  className="h-8 w-8 rounded-xl bg-primary hover:bg-primary/90 disabled:opacity-40 shrink-0"
                >
                  <Send className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center gap-3 text-center p-8">
            <div className="h-16 w-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center">
              <MessageSquare className="h-8 w-8 text-white/20" />
            </div>
            <p className="text-white font-medium">Select a conversation</p>
            <p className="text-sm text-white/40">Choose a thread from the list to start chatting.</p>
          </div>
        )}
      </div>
    </div>
  );
}
