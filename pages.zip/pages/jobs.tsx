import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import {
  Briefcase, Search, MapPin, Clock, ChevronRight, Star,
  Code2, Pen, BarChart3, Truck, Headphones, Wrench,
  BadgeCheck, BookOpen, DollarSign, Users, Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";

const JOB_CATS = [
  { icon: Code2,       label: "Tech",        color: "text-blue-400 bg-blue-500/10",    count: 240 },
  { icon: Pen,         label: "Design",      color: "text-pink-400 bg-pink-500/10",    count: 130 },
  { icon: BarChart3,   label: "Marketing",   color: "text-green-400 bg-green-500/10",  count: 180 },
  { icon: Truck,       label: "Logistics",   color: "text-orange-400 bg-orange-500/10",count: 90 },
  { icon: Headphones,  label: "Support",     color: "text-purple-400 bg-purple-500/10",count: 210 },
  { icon: Wrench,      label: "Skilled",     color: "text-yellow-400 bg-yellow-500/10",count: 160 },
];

const JOBS = [
  { id: "j1", title: "React Developer", company: "Tech Dhaka Ltd", location: "Remote", type: "Full-time", salary: "৳60k-80k/mo", posted: new Date(Date.now() - 2 * 60 * 60 * 1000), tags: ["React", "TypeScript", "Node.js"], verified: true },
  { id: "j2", title: "UI/UX Designer",  company: "StartBD",        location: "Dhaka",  type: "Full-time", salary: "৳45k-60k/mo", posted: new Date(Date.now() - 5 * 60 * 60 * 1000), tags: ["Figma", "Sketch", "Prototyping"], verified: true },
  { id: "j3", title: "Digital Marketing Manager", company: "GrowthHive BD", location: "Hybrid", type: "Full-time", salary: "৳50k-70k/mo", posted: new Date(Date.now() - 24 * 60 * 60 * 1000), tags: ["SEO", "Facebook Ads", "Analytics"], verified: false },
  { id: "j4", title: "Customer Support Lead", company: "ShopNow BD", location: "Dhaka",  type: "Part-time", salary: "৳25k-35k/mo", posted: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), tags: ["Bengali", "English", "CRM"], verified: true },
];

const FREELANCE = [
  { id: "f1", title: "WordPress Website",    budget: "৳15,000",  skills: "WordPress, PHP",    proposals: 8,  deadline: "7 days" },
  { id: "f2", title: "Logo Design",          budget: "৳5,000",   skills: "Illustrator, AI",   proposals: 14, deadline: "3 days" },
  { id: "f3", title: "Data Entry 500 Rows",  budget: "৳3,000",   skills: "Excel, Typing",     proposals: 22, deadline: "2 days" },
  { id: "f4", title: "Video Editing Reel",   budget: "৳8,000",   skills: "Premiere, After FX",proposals: 6,  deadline: "5 days" },
];

export default function JobsPage() {
  const [activeTab, setActiveTab] = useState<"jobs" | "freelance" | "post">("jobs");
  const [search, setSearch] = useState("");

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <GlassCard className="p-6 bg-gradient-to-br from-violet-600/20 via-purple-500/10 to-transparent border border-violet-500/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-40 h-40 bg-violet-400/10 rounded-full blur-3xl" />
        <div className="relative">
          <div className="flex items-center gap-2 mb-2">
            <Briefcase className="h-4 w-4 text-violet-400" />
            <span className="text-xs font-bold text-violet-300 uppercase tracking-widest">PaikarJobs</span>
          </div>
          <h1 className="text-2xl font-bold text-white mb-1">Jobs & Freelance</h1>
          <p className="text-sm text-white/50 mb-4">Full-time jobs, part-time gigs, and freelance projects — all in one place.</p>
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: "Active Jobs",     value: "4,200+", icon: Briefcase },
              { label: "Companies",       value: "820+",   icon: BadgeCheck },
              { label: "Freelancers",     value: "12k+",   icon: Users },
            ].map((s) => {
              const Icon = s.icon;
              return (
                <div key={s.label} className="bg-white/5 rounded-xl p-3 text-center border border-white/8">
                  <p className="text-lg font-bold text-violet-300">{s.value}</p>
                  <p className="text-[10px] text-white/40 mt-0.5">{s.label}</p>
                </div>
              );
            })}
          </div>
        </div>
      </GlassCard>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {([["jobs", "Find Jobs"], ["freelance", "Freelance"], ["post", "Post a Job"]] as const).map(([tab, label]) => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={cn("flex-1 py-2.5 rounded-lg text-sm font-medium transition-all",
              activeTab === tab ? "bg-primary text-white" : "text-white/50 hover:text-white")}>
            {label}
          </button>
        ))}
      </div>

      {activeTab === "jobs" && (
        <div className="flex flex-col gap-5">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35 pointer-events-none" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search jobs, skills, companies..."
              className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
          </div>

          {/* Categories */}
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
            {JOB_CATS.map((c) => {
              const Icon = c.icon;
              return (
                <button key={c.label} className="flex flex-col items-center gap-2 p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/8 transition-colors">
                  <div className={cn("h-9 w-9 rounded-xl flex items-center justify-center", c.color)}>
                    <Icon className="h-4.5 w-[18px] h-[18px]" />
                  </div>
                  <div className="text-center">
                    <p className="text-[10px] text-white/65 font-medium">{c.label}</p>
                    <p className="text-[9px] text-white/30">{c.count} jobs</p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Job listings */}
          <div className="flex flex-col gap-3">
            {JOBS.map((job) => (
              <GlassCard key={job.id} className="p-4 glass-card-hover cursor-pointer">
                <div className="flex items-start gap-3">
                  <div className="h-10 w-10 rounded-xl bg-violet-500/10 flex items-center justify-center shrink-0">
                    <Briefcase className="h-5 w-5 text-violet-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 flex-wrap">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <p className="text-sm font-bold text-white">{job.title}</p>
                          {job.verified && <BadgeCheck className="h-3.5 w-3.5 text-green-400 shrink-0" />}
                        </div>
                        <p className="text-xs text-white/50 mt-0.5">{job.company}</p>
                      </div>
                      <span className="text-sm font-bold text-primary shrink-0">{job.salary}</span>
                    </div>
                    <div className="flex items-center gap-3 mt-2 text-xs text-white/40 flex-wrap">
                      <span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {job.location}</span>
                      <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {formatDistanceToNow(job.posted, { addSuffix: true })}</span>
                      <span className={cn("px-2 py-0.5 rounded-full border text-[10px] font-semibold",
                        job.type === "Full-time" ? "bg-green-500/15 border-green-500/25 text-green-400" : "bg-yellow-500/15 border-yellow-500/25 text-yellow-400")}>
                        {job.type}
                      </span>
                    </div>
                    <div className="flex gap-1.5 flex-wrap mt-2">
                      {job.tags.map((tag) => (
                        <span key={tag} className="text-[10px] bg-white/8 border border-white/12 text-white/60 px-2 py-0.5 rounded-md">{tag}</span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex justify-end mt-3">
                  <Button size="sm" className="bg-violet-500/20 hover:bg-violet-500/30 text-violet-300 border border-violet-500/30 rounded-full text-xs px-4">Apply Now</Button>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      )}

      {activeTab === "freelance" && (
        <div className="flex flex-col gap-3">
          <p className="text-sm text-white/50">Browse projects and bid on your skills.</p>
          {FREELANCE.map((job) => (
            <GlassCard key={job.id} className="p-4 glass-card-hover cursor-pointer">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-white">{job.title}</p>
                  <p className="text-xs text-white/45 mt-0.5">{job.skills}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-base font-bold text-primary">{job.budget}</p>
                  <p className="text-[10px] text-white/35">fixed price</p>
                </div>
              </div>
              <div className="flex items-center gap-4 mt-2 text-xs text-white/40">
                <span className="flex items-center gap-1"><Users className="h-3 w-3" /> {job.proposals} proposals</span>
                <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> Deadline: {job.deadline}</span>
              </div>
              <div className="flex justify-end mt-3">
                <Button size="sm" className="bg-primary/20 hover:bg-primary/30 text-primary border border-primary/30 rounded-full text-xs px-4">
                  <Zap className="h-3 w-3 mr-1" /> Place Bid
                </Button>
              </div>
            </GlassCard>
          ))}
        </div>
      )}

      {activeTab === "post" && (
        <div className="flex flex-col gap-4">
          <GlassCard className="p-5 flex flex-col gap-4">
            <p className="text-sm font-semibold text-white">Post a Job or Project</p>
            <div className="flex flex-col gap-3">
              {["Job Title", "Company Name", "Location", "Salary / Budget"].map((field) => (
                <div key={field} className="flex flex-col gap-1.5">
                  <label className="text-xs text-white/45">{field}</label>
                  <Input placeholder={`Enter ${field.toLowerCase()}...`} className="bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
                </div>
              ))}
              <Button className="bg-primary hover:bg-primary/90 text-white h-11 rounded-xl font-semibold mt-1">
                Post Now
              </Button>
            </div>
          </GlassCard>
          <GlassCard className="p-4 flex items-center gap-4 border border-violet-500/20 bg-violet-500/5">
            <BookOpen className="h-6 w-6 text-violet-400 shrink-0" />
            <div>
              <p className="text-sm font-semibold text-white">Free job posting for startups</p>
              <p className="text-xs text-white/45">Get 3 free posts per month. Premium plans available.</p>
            </div>
          </GlassCard>
        </div>
      )}
    </div>
  );
}
