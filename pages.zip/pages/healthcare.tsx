import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import {
  Heart, Search, Star, Clock, MapPin, ChevronRight, Phone,
  BadgeCheck, Stethoscope, Pill, Brain, Eye, Baby, Bone,
  Calendar, Video, Building2, AlertCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";

const SPECIALTIES = [
  { icon: Heart,       label: "Cardiology",    color: "text-red-400 bg-red-500/10" },
  { icon: Brain,       label: "Neurology",     color: "text-purple-400 bg-purple-500/10" },
  { icon: Bone,        label: "Orthopedics",   color: "text-yellow-400 bg-yellow-500/10" },
  { icon: Eye,         label: "Eye Care",      color: "text-cyan-400 bg-cyan-500/10" },
  { icon: Baby,        label: "Pediatrics",    color: "text-pink-400 bg-pink-500/10" },
  { icon: Stethoscope, label: "General",       color: "text-green-400 bg-green-500/10" },
];

const DOCTORS = [
  { id: "d1", name: "Dr. Kamrul Islam",     specialty: "Cardiologist",   hospital: "Square Hospital, Dhaka",   fee: "৳1,200", rating: 4.9, reviews: 340, img: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200", available: true,  nextSlot: "Today 3:00 PM" },
  { id: "d2", name: "Dr. Nasrin Akter",     specialty: "Gynecologist",   hospital: "Popular Medical Center",   fee: "৳800",   rating: 4.8, reviews: 210, img: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200", available: true,  nextSlot: "Today 5:30 PM" },
  { id: "d3", name: "Dr. Rafiqul Hasan",    specialty: "Neurologist",    hospital: "BIRDEM General Hospital",  fee: "৳1,500", rating: 4.7, reviews: 180, img: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=200", available: false, nextSlot: "Tomorrow 10:00 AM" },
  { id: "d4", name: "Dr. Fatema Begum",     specialty: "Pediatrician",   hospital: "Dhaka Shishu Hospital",    fee: "৳600",   rating: 4.9, reviews: 520, img: "https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=200", available: true,  nextSlot: "Today 7:00 PM" },
];

const HOSPITALS = [
  { name: "Square Hospital",        location: "Panthapath, Dhaka",  beds: 500, rating: 4.7 },
  { name: "United Hospital",        location: "Gulshan, Dhaka",     beds: 450, rating: 4.8 },
  { name: "BIRDEM General",         location: "Shahbag, Dhaka",     beds: 800, rating: 4.6 },
  { name: "Popular Medical Centre", location: "Shyamoli, Dhaka",    beds: 350, rating: 4.7 },
];

export default function HealthcarePage() {
  const [activeTab, setActiveTab] = useState<"doctors" | "hospitals" | "emergency">("doctors");
  const [search, setSearch] = useState("");

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <GlassCard className="p-6 bg-gradient-to-br from-red-600/20 via-rose-500/10 to-transparent border border-red-500/20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(239,68,68,0.12),transparent_60%)]" />
        <div className="relative flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Heart className="h-4 w-4 text-red-400" />
              <span className="text-xs font-bold text-red-300 uppercase tracking-widest">PaikarHealth</span>
            </div>
            <h1 className="text-2xl font-bold text-white mb-1">Your Health, Our Priority</h1>
            <p className="text-sm text-white/50 mb-4">Book doctors, hospitals, and ambulance — 24/7.</p>
            <div className="flex gap-2 flex-wrap">
              <Button className="bg-red-500 hover:bg-red-400 text-white rounded-full font-bold">
                <Video className="h-4 w-4 mr-1.5" /> Video Consult
              </Button>
              <Button variant="outline" className="border-red-500/40 text-red-300 hover:bg-red-500/10 rounded-full">
                <AlertCircle className="h-4 w-4 mr-1.5" /> Emergency
              </Button>
            </div>
          </div>
          <div className="flex flex-col gap-2 shrink-0">
            <div className="bg-white/5 border border-red-500/20 rounded-xl p-3 text-center">
              <p className="text-xl font-bold text-red-400">2,400+</p>
              <p className="text-[10px] text-white/40">Doctors</p>
            </div>
            <div className="bg-white/5 border border-red-500/20 rounded-xl p-3 text-center">
              <p className="text-xl font-bold text-red-400">50+</p>
              <p className="text-[10px] text-white/40">Hospitals</p>
            </div>
          </div>
        </div>
      </GlassCard>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {([["doctors","Doctors"],["hospitals","Hospitals"],["emergency","Emergency"]] as const).map(([t,l]) => (
          <button key={t} onClick={() => setActiveTab(t)} className={cn("flex-1 py-2.5 rounded-lg text-sm font-medium transition-all", activeTab===t?"bg-primary text-white":"text-white/50 hover:text-white")}>{l}</button>
        ))}
      </div>

      {activeTab === "doctors" && (
        <div className="flex flex-col gap-5">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35 pointer-events-none" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search doctors, specialties..." className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
          </div>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
            {SPECIALTIES.map(s => { const Icon = s.icon; return (
              <button key={s.label} className="flex flex-col items-center gap-2 p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/8 transition-colors">
                <div className={cn("h-9 w-9 rounded-xl flex items-center justify-center", s.color)}><Icon className="h-[18px] w-[18px]" /></div>
                <p className="text-[10px] text-white/65 font-medium leading-tight text-center">{s.label}</p>
              </button>
            ); })}
          </div>
          <div className="flex flex-col gap-3">
            {DOCTORS.filter(d => !search || d.name.toLowerCase().includes(search.toLowerCase()) || d.specialty.toLowerCase().includes(search.toLowerCase())).map(d => (
              <GlassCard key={d.id} className="p-4 glass-card-hover cursor-pointer">
                <div className="flex items-start gap-3">
                  <div className="h-14 w-14 rounded-2xl overflow-hidden shrink-0 border border-white/10">
                    <img src={d.img} alt={d.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <p className="text-sm font-bold text-white">{d.name}</p>
                      <BadgeCheck className="h-3.5 w-3.5 text-blue-400 shrink-0" />
                    </div>
                    <p className="text-xs text-red-300/80 mt-0.5 font-medium">{d.specialty}</p>
                    <p className="text-xs text-white/40 mt-0.5 flex items-center gap-1"><Building2 className="h-3 w-3" />{d.hospital}</p>
                    <div className="flex items-center gap-3 mt-1.5 text-xs text-white/50 flex-wrap">
                      <span className="flex items-center gap-1"><Star className="h-3 w-3 text-yellow-400 fill-yellow-400" /> {d.rating} ({d.reviews})</span>
                      <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {d.nextSlot}</span>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2 shrink-0">
                    <span className="text-sm font-bold text-primary">{d.fee}</span>
                    <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded-full", d.available ? "bg-green-500/15 text-green-400" : "bg-white/10 text-white/40")}>{d.available ? "Available" : "Busy"}</span>
                  </div>
                </div>
                <div className="flex gap-2 mt-3">
                  <Button size="sm" variant="outline" className="flex-1 border-white/15 bg-white/5 text-white/70 hover:bg-white/10 rounded-full text-xs h-8">
                    <Phone className="h-3.5 w-3.5 mr-1" /> Call
                  </Button>
                  <Button size="sm" className="flex-1 bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/30 rounded-full text-xs h-8">
                    <Video className="h-3.5 w-3.5 mr-1" /> Video
                  </Button>
                  <Button size="sm" className="flex-1 bg-primary hover:bg-primary/90 text-white rounded-full text-xs h-8">Book</Button>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      )}

      {activeTab === "hospitals" && (
        <div className="flex flex-col gap-3">
          {HOSPITALS.map(h => (
            <GlassCard key={h.name} className="p-4 flex items-center gap-4 glass-card-hover cursor-pointer">
              <div className="h-11 w-11 rounded-xl bg-red-500/10 flex items-center justify-center shrink-0">
                <Building2 className="h-5 w-5 text-red-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-white">{h.name}</p>
                <p className="text-xs text-white/40 mt-0.5 flex items-center gap-1"><MapPin className="h-3 w-3" /> {h.location}</p>
                <p className="text-xs text-white/35 mt-0.5">{h.beds} beds capacity</p>
              </div>
              <div className="flex flex-col items-end gap-1 shrink-0">
                <span className="flex items-center gap-1 text-sm font-semibold text-white"><Star className="h-3.5 w-3.5 text-yellow-400 fill-yellow-400" /> {h.rating}</span>
                <Button size="sm" className="bg-primary hover:bg-primary/90 text-white rounded-full text-xs px-3 h-7">View</Button>
              </div>
            </GlassCard>
          ))}
        </div>
      )}

      {activeTab === "emergency" && (
        <div className="flex flex-col gap-3">
          <GlassCard className="p-5 border border-red-500/30 bg-red-500/8 flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-red-400 animate-pulse" />
              <p className="font-bold text-white">Emergency Services 24/7</p>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: "Ambulance",     number: "16999", color: "bg-red-500" },
                { label: "Fire Service",  number: "199",   color: "bg-orange-500" },
                { label: "Police",        number: "999",   color: "bg-blue-500" },
                { label: "Hospital Helpline", number: "16", color: "bg-green-500" },
              ].map(e => (
                <button key={e.label} className={cn("p-4 rounded-xl text-white font-bold flex flex-col gap-1", e.color)}>
                  <span className="text-2xl font-black">{e.number}</span>
                  <span className="text-xs opacity-80">{e.label}</span>
                </button>
              ))}
            </div>
          </GlassCard>
          <GlassCard className="p-4">
            <p className="text-sm font-semibold text-white mb-3">Book Ambulance</p>
            <div className="flex flex-col gap-3">
              <Input placeholder="Pickup location..." className="bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
              <Input placeholder="Drop location..." className="bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
              <Button className="bg-red-500 hover:bg-red-400 text-white h-11 rounded-xl font-bold">Book Ambulance Now</Button>
            </div>
          </GlassCard>
        </div>
      )}
    </div>
  );
}
