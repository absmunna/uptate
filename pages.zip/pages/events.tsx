import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import {
  Calendar, MapPin, Clock, Users, Ticket, Star, ChevronRight,
  Music, Mic, Laptop, Trophy, Utensils, Palette, Search, Plus,
  Heart, Share2, BadgeCheck,
} from "lucide-react";
import { cn } from "@/lib/utils";

const CATEGORIES = [
  { icon: Music,    label: "Concert",     color: "text-pink-400 bg-pink-500/10" },
  { icon: Laptop,   label: "Tech",        color: "text-blue-400 bg-blue-500/10" },
  { icon: Mic,      label: "Talk",        color: "text-purple-400 bg-purple-500/10" },
  { icon: Trophy,   label: "Sports",      color: "text-yellow-400 bg-yellow-500/10" },
  { icon: Utensils, label: "Food Fest",   color: "text-orange-400 bg-orange-500/10" },
  { icon: Palette,  label: "Art",         color: "text-cyan-400 bg-cyan-500/10" },
];

const EVENTS = [
  { id: "e1", title: "Bangladesh Tech Summit 2026",  date: "June 15, 2026",   time: "9:00 AM",  location: "Bashundhara Int'l Convention", price: "৳800",   free: false, img: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400", attendees: 2400, tags: ["Tech", "Startup"], liked: false },
  { id: "e2", title: "Dhaka Food Festival",          date: "June 20, 2026",   time: "12:00 PM", location: "Hatirjheel Amphitheatre",       price: "৳300",   free: false, img: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=400", attendees: 8000, tags: ["Food", "Family"], liked: true },
  { id: "e3", title: "Startup Pitch Night",          date: "June 22, 2026",   time: "6:00 PM",  location: "Grameenphone HQ, Motijheel",   price: "Free",   free: true,  img: "https://images.unsplash.com/photo-1475721027785-f74eccf877e2?w=400", attendees: 350,  tags: ["Startup", "Networking"], liked: false },
  { id: "e4", title: "Classical Music Evening",      date: "June 28, 2026",   time: "7:30 PM",  location: "Shilpakala Academy, Segunbagicha",price: "৳500",free: false, img: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400", attendees: 600,  tags: ["Music", "Culture"], liked: false },
  { id: "e5", title: "E-Sports Championship BD",    date: "July 4, 2026",    time: "11:00 AM", location: "BSCC Arena, Mirpur",            price: "৳400",   free: false, img: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400", attendees: 3200, tags: ["Gaming", "Sports"], liked: true },
];

export default function EventsPage() {
  const [search, setSearch] = useState("");
  const [favorites, setFavorites] = useState<Set<string>>(new Set(EVENTS.filter(e => e.liked).map(e => e.id)));
  const [activeFilter, setActiveFilter] = useState("All");

  const filters = ["All", "This Week", "Free", "Tech", "Music", "Food"];
  const filtered = EVENTS.filter(e =>
    (!search || e.title.toLowerCase().includes(search.toLowerCase())) &&
    (activeFilter === "All" || activeFilter === "Free" ? e.free : e.tags.some(t => t.toLowerCase().includes(activeFilter.toLowerCase())))
  );

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <GlassCard className="p-5 bg-gradient-to-br from-fuchsia-600/20 via-purple-600/15 to-transparent border border-fuchsia-500/25 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-fuchsia-400/10 rounded-full blur-3xl" />
        <div className="relative">
          <div className="flex items-center gap-2 mb-1.5">
            <Calendar className="h-4 w-4 text-fuchsia-400" />
            <span className="text-xs font-bold text-fuchsia-300 uppercase tracking-widest">PaikarEvents</span>
          </div>
          <h1 className="text-2xl font-bold text-white mb-1">Events Near You</h1>
          <p className="text-sm text-white/50 mb-4">Concerts, tech talks, food fests, sports — all in one place.</p>
          <Button className="bg-fuchsia-500 hover:bg-fuchsia-400 text-white rounded-full font-bold flex items-center gap-2">
            <Plus className="h-4 w-4" /> Create Event
          </Button>
        </div>
      </GlassCard>

      {/* Category icons */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        {CATEGORIES.map(c => { const Icon = c.icon; return (
          <button key={c.label} className="shrink-0 flex flex-col items-center gap-2 px-4 py-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/8 transition-colors">
            <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center", c.color)}>
              <Icon className="h-5 w-5" />
            </div>
            <p className="text-[10px] text-white/60 font-medium">{c.label}</p>
          </button>
        ); })}
      </div>

      {/* Search + filters */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35 pointer-events-none" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search events..." className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
      </div>
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        {filters.map(f => (
          <button key={f} onClick={() => setActiveFilter(f)}
            className={cn("shrink-0 text-xs px-3 py-1.5 rounded-full border transition-all font-medium",
              activeFilter === f ? "bg-primary border-primary text-white" : "bg-white/5 border-white/10 text-white/55 hover:text-white")}>
            {f}
          </button>
        ))}
      </div>

      {/* Featured event */}
      {!search && activeFilter === "All" && (
        <div className="relative rounded-2xl overflow-hidden h-52 cursor-pointer">
          <img src={EVENTS[0].img} alt={EVENTS[0].title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
          <div className="absolute top-2 left-2">
            <span className="text-[10px] bg-primary text-white font-bold px-2 py-0.5 rounded-full">FEATURED</span>
          </div>
          <div className="absolute bottom-3 left-4 right-4">
            <p className="text-lg font-bold text-white leading-tight">{EVENTS[0].title}</p>
            <div className="flex items-center gap-3 mt-1 text-xs text-white/60 flex-wrap">
              <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {EVENTS[0].date}</span>
              <span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {EVENTS[0].location}</span>
              <span className="flex items-center gap-1"><Users className="h-3 w-3" /> {EVENTS[0].attendees.toLocaleString()}</span>
            </div>
            <div className="flex items-center justify-between mt-2">
              <span className="text-lg font-bold text-primary">{EVENTS[0].price}</span>
              <Button size="sm" className="bg-primary hover:bg-primary/90 text-white rounded-full">
                <Ticket className="h-3.5 w-3.5 mr-1" /> Get Tickets
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Event list */}
      <div>
        {!search && activeFilter === "All" && (
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-base font-semibold text-white">Upcoming Events</h2>
            <span className="text-xs text-primary hover:underline cursor-pointer flex items-center gap-0.5">See all <ChevronRight className="h-3 w-3" /></span>
          </div>
        )}
        <div className="flex flex-col gap-3">
          {filtered.slice(1).map(event => (
            <GlassCard key={event.id} className="overflow-hidden glass-card-hover cursor-pointer p-0">
              <div className="flex gap-0">
                <img src={event.img} alt={event.title} className="w-28 h-28 object-cover shrink-0" />
                <div className="flex-1 p-3.5 min-w-0">
                  <p className="text-sm font-bold text-white leading-tight">{event.title}</p>
                  <div className="flex items-center gap-1 text-xs text-white/40 mt-1">
                    <Calendar className="h-3 w-3 shrink-0" />
                    <span>{event.date} · {event.time}</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-white/40 mt-0.5">
                    <MapPin className="h-3 w-3 shrink-0" />
                    <span className="truncate">{event.location}</span>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className={cn("text-sm font-bold", event.free ? "text-green-400" : "text-primary")}>{event.price}</span>
                    <div className="flex items-center gap-1.5">
                      <button onClick={e => { e.stopPropagation(); setFavorites(prev => { const n = new Set(prev); n.has(event.id) ? n.delete(event.id) : n.add(event.id); return n; }); }}>
                        <Heart className={cn("h-4 w-4", favorites.has(event.id) ? "fill-red-400 text-red-400" : "text-white/35")} />
                      </button>
                      <Button size="sm" className="bg-fuchsia-500/20 hover:bg-fuchsia-500/30 text-fuchsia-300 border border-fuchsia-500/30 rounded-full text-xs px-3 h-7">Book</Button>
                    </div>
                  </div>
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>

      {/* Create event CTA */}
      <GlassCard className="p-5 border border-fuchsia-500/20 bg-fuchsia-500/5 flex items-center gap-4">
        <Calendar className="h-8 w-8 text-fuchsia-400 shrink-0" />
        <div className="flex-1">
          <p className="font-semibold text-white text-sm">Host Your Own Event</p>
          <p className="text-xs text-white/45 mt-0.5">Sell tickets, manage RSVPs, and promote your event to thousands.</p>
        </div>
        <Button className="bg-fuchsia-500/20 hover:bg-fuchsia-500/30 text-fuchsia-300 border border-fuchsia-500/30 rounded-full text-xs shrink-0">Start</Button>
      </GlassCard>
    </div>
  );
}
