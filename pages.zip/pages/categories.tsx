import { useListCategories, getListCategoriesQueryKey } from "@workspace/api-client-react";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import { GlassCard } from "@/components/ui/GlassCard";
import { Link } from "wouter";
import * as Icons from "lucide-react";
import { cn } from "@/lib/utils";

const CAT_COLORS = [
  "from-blue-500/30 to-primary/20",
  "from-purple-500/30 to-pink-500/20",
  "from-green-500/30 to-emerald-500/20",
  "from-orange-500/30 to-red-500/20",
  "from-cyan-500/30 to-blue-500/20",
  "from-yellow-500/30 to-orange-500/20",
  "from-rose-500/30 to-purple-500/20",
  "from-teal-500/30 to-green-500/20",
  "from-indigo-500/30 to-cyan-500/20",
];

function SkeletonCard() {
  return <div className="aspect-square rounded-2xl skeleton-shimmer" />;
}

export default function Categories() {
  const { data: categories } = useListCategories({ query: { queryKey: getListCategoriesQueryKey() } });

  return (
    <div className="flex flex-col gap-4 p-4 md:p-5">
      <PortalIconBar />

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Browse Categories</h1>
          <p className="text-sm text-white/45 mt-0.5">Explore everything PaikarMart offers</p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
        {!categories
          ? Array.from({ length: 9 }).map((_, i) => <SkeletonCard key={i} />)
          : categories.map((cat, idx) => {
              const IconComponent = (Icons as any)[cat.icon] || Icons.Tag;
              const gradient = CAT_COLORS[idx % CAT_COLORS.length];
              return (
                <Link key={cat.id} href={`/marketplace?categoryId=${cat.id}`}>
                  <GlassCard className="aspect-square flex flex-col items-center justify-center gap-3 p-4 text-center cursor-pointer group glass-card-hover overflow-hidden relative">
                    {/* Gradient bg blob */}
                    <div className={cn(
                      "absolute inset-0 bg-gradient-to-br opacity-30 group-hover:opacity-50 transition-opacity",
                      gradient
                    )} />

                    <div className={cn(
                      "relative h-14 w-14 rounded-2xl bg-gradient-to-br flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300",
                      gradient
                    )}>
                      <IconComponent className="h-7 w-7 text-white drop-shadow" />
                    </div>

                    <div className="relative flex flex-col gap-0.5">
                      <h3 className="font-semibold text-sm text-white group-hover:text-primary transition-colors leading-tight">
                        {cat.name}
                      </h3>
                      {cat.productCount !== undefined && (
                        <p className="text-[10px] text-white/40">
                          {cat.productCount} items
                        </p>
                      )}
                    </div>
                  </GlassCard>
                </Link>
              );
            })
        }
      </div>

      {/* Quick access rows */}
      <div className="mt-4">
        <h2 className="text-lg font-semibold text-white mb-3">Quick Access</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {[
            { href: "/marketplace?type=wholesale", label: "Wholesale Deals", sub: "Bulk pricing for businesses", icon: Icons.Package2, color: "text-purple-400 bg-purple-500/10 border-purple-500/20" },
            { href: "/marketplace?type=grocery",   label: "Fresh Grocery",   sub: "Daily essentials nearby",   icon: Icons.Leaf,     color: "text-green-400 bg-green-500/10 border-green-500/20" },
            { href: "/marketplace?type=service",   label: "Services",        sub: "Local service providers",   icon: Icons.Wrench,   color: "text-blue-400 bg-blue-500/10 border-blue-500/20" },
            { href: "/marketplace?type=hotel",     label: "Travel & Hotels",  sub: "Plan your next trip",       icon: Icons.Plane,    color: "text-orange-400 bg-orange-500/10 border-orange-500/20" },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href}>
                <GlassCard className={cn("p-4 flex items-center gap-4 cursor-pointer glass-card-hover border", item.color.split(" ").slice(1).join(" "))}>
                  <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center shrink-0", item.color.split(" ")[1])}>
                    <Icon className={cn("h-5 w-5", item.color.split(" ")[0])} />
                  </div>
                  <div>
                    <p className="font-semibold text-sm text-white">{item.label}</p>
                    <p className="text-xs text-white/45">{item.sub}</p>
                  </div>
                  <Icons.ChevronRight className="h-4 w-4 text-white/30 ml-auto" />
                </GlassCard>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
