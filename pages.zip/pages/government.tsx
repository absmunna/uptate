import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import {
  Shield, Search, FileText, CheckCircle, Clock, ChevronRight,
  Building, CreditCard, Globe, Phone, Printer, AlertCircle,
  BadgeCheck, ArrowRight, BookOpen,
} from "lucide-react";
import { cn } from "@/lib/utils";

const SERVICES = [
  { id: "s1", name: "NID Application",           dept: "Election Commission",   icon: CreditCard,  color: "text-blue-400 bg-blue-500/10",    time: "7-15 days",  online: true },
  { id: "s2", name: "Passport Application",      dept: "Dept of Immigration",   icon: Globe,       color: "text-green-400 bg-green-500/10",  time: "15-30 days", online: true },
  { id: "s3", name: "Birth Certificate",         dept: "Local Govt Division",   icon: FileText,    color: "text-purple-400 bg-purple-500/10",time: "3-7 days",   online: true },
  { id: "s4", name: "Trade License",             dept: "City Corporation",      icon: Building,    color: "text-orange-400 bg-orange-500/10",time: "7-14 days",  online: false },
  { id: "s5", name: "TIN Certificate",           dept: "National Board of Revenue",icon: BookOpen, color: "text-yellow-400 bg-yellow-500/10",time: "Instant",    online: true },
  { id: "s6", name: "Police Clearance",          dept: "Bangladesh Police",     icon: Shield,      color: "text-red-400 bg-red-500/10",      time: "7-10 days",  online: true },
  { id: "s7", name: "Land Records",             dept: "Dept of Land Records",  icon: FileText,    color: "text-cyan-400 bg-cyan-500/10",    time: "Varies",     online: false },
  { id: "s8", name: "Company Registration",      dept: "RJSC",                  icon: Building,    color: "text-indigo-400 bg-indigo-500/10",time: "7-21 days",  online: true },
];

const HELPLINES = [
  { name: "National Emergency",  number: "999",   type: "emergency" },
  { name: "Healthcare Hotline",  number: "16000", type: "health" },
  { name: "Women Helpline",      number: "10921", type: "support" },
  { name: "NBR Tax Helpline",    number: "16555", type: "finance" },
  { name: "Anti-Corruption",     number: "106",   type: "legal" },
  { name: "Electricity Fault",   number: "16990", type: "utility" },
];

const PAYMENTS = [
  { name: "Electricity Bill (DESCO)",  status: "Due",  amount: "৳1,840",  dueDate: "June 30" },
  { name: "Water Bill (WASA)",          status: "Paid", amount: "৳620",   dueDate: "June 15" },
  { name: "Income Tax Return",          status: "Due",  amount: "৳4,200", dueDate: "November 30" },
];

export default function GovernmentPage() {
  const [activeTab, setActiveTab] = useState<"services" | "payments" | "helplines">("services");
  const [search, setSearch] = useState("");

  const filtered = SERVICES.filter(s => !search || s.name.toLowerCase().includes(search.toLowerCase()) || s.dept.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <GlassCard className="p-5 bg-gradient-to-br from-emerald-700/25 via-green-600/15 to-transparent border border-emerald-500/25 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-40 h-40 bg-emerald-400/8 rounded-full blur-3xl" />
        <div className="relative flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <Shield className="h-4 w-4 text-emerald-400" />
              <span className="text-xs font-bold text-emerald-300 uppercase tracking-widest">PaikarGov</span>
            </div>
            <h1 className="text-xl font-bold text-white mb-1">Government Services</h1>
            <p className="text-xs text-white/50 mb-3">NID, Passport, TIN, Trade License — apply online from home.</p>
            <div className="flex items-center gap-2 text-xs text-white/40">
              <BadgeCheck className="h-4 w-4 text-emerald-400" />
              <span>Official Bangladesh Government Portal</span>
            </div>
          </div>
          <div className="flex flex-col gap-2 shrink-0">
            <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-3 text-center">
              <p className="text-xl font-bold text-emerald-400">40+</p>
              <p className="text-[10px] text-white/40">Services</p>
            </div>
            <div className="bg-white/5 border border-emerald-500/20 rounded-xl p-3 text-center">
              <p className="text-xl font-bold text-emerald-400">24/7</p>
              <p className="text-[10px] text-white/40">Online</p>
            </div>
          </div>
        </div>
      </GlassCard>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {([["services","Services"],["payments","Bill Pay"],["helplines","Helplines"]] as const).map(([t,l]) => (
          <button key={t} onClick={() => setActiveTab(t)} className={cn("flex-1 py-2.5 rounded-lg text-sm font-medium transition-all", activeTab===t?"bg-primary text-white":"text-white/50 hover:text-white")}>{l}</button>
        ))}
      </div>

      {activeTab === "services" && (
        <div className="flex flex-col gap-5">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35 pointer-events-none" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search services..." className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {filtered.map(s => { const Icon = s.icon; return (
              <GlassCard key={s.id} className="p-4 flex items-start gap-3 glass-card-hover cursor-pointer">
                <div className={cn("h-11 w-11 rounded-xl flex items-center justify-center shrink-0", s.color)}>
                  <Icon className="h-5 w-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-white">{s.name}</p>
                  <p className="text-xs text-white/40 mt-0.5">{s.dept}</p>
                  <div className="flex items-center gap-3 mt-1.5 flex-wrap">
                    <span className="text-xs text-white/35 flex items-center gap-1"><Clock className="h-3 w-3" /> {s.time}</span>
                    {s.online && (
                      <span className="text-[10px] bg-green-500/15 text-green-400 border border-green-500/25 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                        <Globe className="h-3 w-3" /> Online
                      </span>
                    )}
                  </div>
                </div>
                <ArrowRight className="h-4 w-4 text-white/25 shrink-0 mt-1" />
              </GlassCard>
            ); })}
          </div>
          <GlassCard className="p-4 flex items-center gap-4 border border-emerald-500/20 bg-emerald-500/5">
            <AlertCircle className="h-7 w-7 text-emerald-400 shrink-0" />
            <div>
              <p className="font-semibold text-white text-sm">Need Help?</p>
              <p className="text-xs text-white/45 mt-0.5">Our certified agents can assist you with any government application.</p>
            </div>
            <Button className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 rounded-full text-xs shrink-0">Contact</Button>
          </GlassCard>
        </div>
      )}

      {activeTab === "payments" && (
        <div className="flex flex-col gap-3">
          <p className="text-sm text-white/50 mb-1">Pay government bills directly — connected to official portals.</p>
          {PAYMENTS.map(p => (
            <GlassCard key={p.name} className={cn("p-4 flex items-center gap-3", p.status === "Due" ? "border-red-500/20 bg-red-500/5" : "border-green-500/15 bg-green-500/5")}>
              <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center shrink-0", p.status === "Due" ? "bg-red-500/15" : "bg-green-500/15")}>
                {p.status === "Due" ? <AlertCircle className="h-5 w-5 text-red-400" /> : <CheckCircle className="h-5 w-5 text-green-400" />}
              </div>
              <div className="flex-1">
                <p className="text-sm font-bold text-white">{p.name}</p>
                <p className="text-xs text-white/40 mt-0.5">Due: {p.dueDate}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-sm font-bold text-white">{p.amount}</span>
                {p.status === "Due" && (
                  <Button size="sm" className="bg-primary hover:bg-primary/90 text-white rounded-full text-xs px-3 h-7">Pay</Button>
                )}
                {p.status === "Paid" && (
                  <span className="text-xs text-green-400 font-bold flex items-center gap-1"><CheckCircle className="h-3 w-3" /> Paid</span>
                )}
              </div>
            </GlassCard>
          ))}
          <GlassCard className="p-4 mt-1">
            <p className="text-sm font-semibold text-white mb-3">Add New Bill</p>
            <div className="flex gap-3">
              <Input placeholder="Account/Bill number..." className="flex-1 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
              <Button className="bg-primary hover:bg-primary/90 text-white rounded-xl px-4">Search</Button>
            </div>
          </GlassCard>
        </div>
      )}

      {activeTab === "helplines" && (
        <div className="grid grid-cols-2 gap-3">
          {HELPLINES.map(h => (
            <GlassCard key={h.name} className="p-4 flex flex-col items-center text-center gap-2 glass-card-hover cursor-pointer">
              <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
                <Phone className="h-5 w-5 text-primary" />
              </div>
              <p className="text-2xl font-black text-white">{h.number}</p>
              <p className="text-xs text-white/50 leading-tight">{h.name}</p>
              <Button size="sm" className="bg-primary/15 hover:bg-primary/25 text-primary rounded-full text-xs px-4 h-7 w-full">Call</Button>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
}
