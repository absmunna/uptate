import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import {
  Wallet, ArrowUpRight, ArrowDownLeft, Plus,
  CreditCard, Smartphone, Building2, RefreshCw,
  TrendingUp, Clock, CheckCircle, XCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";

const METHODS = [
  { id: "bkash",  label: "bKash",   color: "from-pink-600/30 to-rose-500/20",  border: "border-pink-500/20",  icon: Smartphone, iconColor: "text-pink-400" },
  { id: "nagad",  label: "Nagad",   color: "from-orange-600/30 to-amber-500/20",border: "border-orange-500/20",icon: Smartphone, iconColor: "text-orange-400" },
  { id: "rocket", label: "Rocket",  color: "from-purple-600/30 to-violet-500/20",border: "border-purple-500/20",icon: Smartphone, iconColor: "text-purple-400" },
  { id: "card",   label: "Card",    color: "from-blue-600/30 to-cyan-500/20",   border: "border-blue-500/20",  icon: CreditCard, iconColor: "text-blue-400" },
  { id: "bank",   label: "Bank",    color: "from-green-600/30 to-emerald-500/20",border: "border-green-500/20",icon: Building2,  iconColor: "text-green-400" },
];

const TRANSACTIONS = [
  { id: "t1", label: "Order #PM8821",   type: "debit",  amount: 1250, time: "2 hours ago",  status: "completed" },
  { id: "t2", label: "bKash Top-up",    type: "credit", amount: 5000, time: "Yesterday",    status: "completed" },
  { id: "t3", label: "Order #PM8792",   type: "debit",  amount: 340,  time: "2 days ago",   status: "completed" },
  { id: "t4", label: "Cashback reward", type: "credit", amount: 120,  time: "3 days ago",   status: "completed" },
  { id: "t5", label: "Order #PM8764",   type: "debit",  amount: 890,  time: "5 days ago",   status: "refunded" },
];

export default function WalletPage() {
  const balance = 12_480;
  const pkCoins = 340;

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5 max-w-2xl mx-auto w-full">
      {/* Balance card */}
      <GlassCard className="p-6 bg-gradient-to-br from-primary/20 via-purple-500/10 to-transparent border border-primary/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-primary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4" />
        <div className="relative flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Wallet className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium text-white/70">PaikarWallet</span>
            </div>
            <button className="h-8 w-8 rounded-xl bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
              <RefreshCw className="h-3.5 w-3.5 text-white/60" />
            </button>
          </div>

          <div>
            <p className="text-xs text-white/50 mb-1">Available Balance</p>
            <p className="text-4xl font-bold text-white">৳{balance.toLocaleString()}</p>
          </div>

          {/* PK Coins */}
          <div className="flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/20 rounded-xl px-3 py-2 w-fit">
            <TrendingUp className="h-4 w-4 text-yellow-400" />
            <span className="text-sm font-semibold text-yellow-300">{pkCoins} PK Coins</span>
            <span className="text-xs text-white/40">≈ ৳{pkCoins * 0.5}</span>
          </div>

          {/* Action buttons */}
          <div className="grid grid-cols-3 gap-3">
            {[
              { icon: Plus,          label: "Top Up",    color: "bg-primary" },
              { icon: ArrowUpRight,  label: "Send",      color: "bg-white/10" },
              { icon: ArrowDownLeft, label: "Withdraw",  color: "bg-white/10" },
            ].map((a) => (
              <button
                key={a.label}
                className={cn("flex flex-col items-center gap-1.5 py-3 rounded-xl transition-all hover:scale-105", a.color)}
              >
                <a.icon className="h-5 w-5 text-white" />
                <span className="text-xs text-white font-medium">{a.label}</span>
              </button>
            ))}
          </div>
        </div>
      </GlassCard>

      {/* Payment methods */}
      <div>
        <h2 className="text-sm font-semibold text-white/60 uppercase tracking-wider mb-3">Payment Methods</h2>
        <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
          {METHODS.map((m) => {
            const Icon = m.icon;
            return (
              <button
                key={m.id}
                className={cn(
                  "shrink-0 flex flex-col items-center gap-2 p-4 rounded-2xl border bg-gradient-to-br min-w-[88px] hover:scale-105 transition-all",
                  m.color, m.border
                )}
              >
                <Icon className={cn("h-6 w-6", m.iconColor)} />
                <span className="text-xs font-medium text-white/80">{m.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Recent transactions */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-white/60 uppercase tracking-wider">Recent Transactions</h2>
          <button className="text-xs text-primary hover:underline">View All</button>
        </div>
        <GlassCard className="divide-y divide-white/8">
          {TRANSACTIONS.map((tx) => (
            <div key={tx.id} className="flex items-center gap-3 p-4">
              <div className={cn(
                "h-9 w-9 rounded-xl flex items-center justify-center shrink-0",
                tx.type === "credit" ? "bg-green-500/10" : tx.status === "refunded" ? "bg-orange-500/10" : "bg-red-500/10"
              )}>
                {tx.type === "credit" ? (
                  <ArrowDownLeft className="h-4 w-4 text-green-400" />
                ) : tx.status === "refunded" ? (
                  <RefreshCw className="h-4 w-4 text-orange-400" />
                ) : (
                  <ArrowUpRight className="h-4 w-4 text-red-400" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-white truncate">{tx.label}</p>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <Clock className="h-3 w-3 text-white/30" />
                  <span className="text-xs text-white/40">{tx.time}</span>
                  {tx.status === "refunded" && (
                    <span className="text-[10px] text-orange-400 font-medium">Refunded</span>
                  )}
                </div>
              </div>
              <span className={cn(
                "text-sm font-bold shrink-0",
                tx.type === "credit" ? "text-green-400" : tx.status === "refunded" ? "text-orange-400" : "text-red-400"
              )}>
                {tx.type === "credit" ? "+" : "-"}৳{tx.amount.toLocaleString()}
              </span>
            </div>
          ))}
        </GlassCard>
      </div>

      {/* Coming soon notice */}
      <GlassCard className="p-4 flex items-center gap-3 border border-yellow-500/20 bg-yellow-500/5">
        <div className="h-8 w-8 rounded-xl bg-yellow-500/15 flex items-center justify-center shrink-0">
          <Clock className="h-4 w-4 text-yellow-400" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-white">Full wallet integration coming soon</p>
          <p className="text-xs text-white/45">bKash, Nagad & SSLCommerz gateway integration in progress.</p>
        </div>
      </GlassCard>
    </div>
  );
}
