import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import {
  Search, Utensils, Star, Clock, ChevronRight, MapPin,
  Zap, Flame, Beef, Leaf, Coffee, Pizza, Fish, Heart,
} from "lucide-react";
import { cn } from "@/lib/utils";

const CUISINES = [
  { icon: Utensils, label: "Bangladeshi", color: "text-green-400 bg-green-500/10" },
  { icon: Pizza,    label: "Fast Food",   color: "text-yellow-400 bg-yellow-500/10" },
  { icon: Fish,     label: "Seafood",     color: "text-blue-400 bg-blue-500/10" },
  { icon: Beef,     label: "Grills",      color: "text-red-400 bg-red-500/10" },
  { icon: Leaf,     label: "Vegetarian",  color: "text-emerald-400 bg-emerald-500/10" },
  { icon: Coffee,   label: "Cafe",        color: "text-amber-400 bg-amber-500/10" },
];

const RESTAURANTS = [
  { id: "r1", name: "Star Kabab & Restaurant", cuisine: "Bangladeshi · Grills", rating: 4.8, reviews: 1240, time: "25 min", fee: "৳30", minOrder: "৳200", open: true, promo: "20% OFF", img: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=400" },
  { id: "r2", name: "Dhanmondi Kitchen",        cuisine: "Bangladeshi · Biriyani", rating: 4.6, reviews: 890, time: "30 min", fee: "Free", minOrder: "৳300", open: true, promo: null, img: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=400" },
  { id: "r3", name: "Burger Nation",             cuisine: "Fast Food · Burgers",  rating: 4.5, reviews: 670, time: "20 min", fee: "৳20", minOrder: "৳150", open: true, promo: "Buy 2 get 1", img: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400" },
  { id: "r4", name: "Sushi & More",              cuisine: "Japanese · Sushi",     rating: 4.7, reviews: 430, time: "40 min", fee: "৳50", minOrder: "৳500", open: false,promo: null, img: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=400" },
  { id: "r5", name: "Green Bowl Cafe",           cuisine: "Healthy · Vegan",      rating: 4.9, reviews: 320, time: "35 min", fee: "Free", minOrder: "৳250", open: true, promo: null, img: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400" },
];

const FILTER_TABS = ["All", "Trending", "Fast Delivery", "Free Delivery", "New"];

export default function FoodPage() {
  const [search, setSearch] = useState("");
  const [activeFilter, setActiveFilter] = useState("All");
  const [favorites, setFavorites] = useState<Set<string>>(new Set());

  const filtered = RESTAURANTS.filter((r) =>
    !search || r.name.toLowerCase().includes(search.toLowerCase()) || r.cuisine.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <GlassCard className="p-5 md:p-7 bg-gradient-to-br from-orange-600/25 via-red-500/10 to-transparent border border-orange-500/20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(249,115,22,0.12),transparent_60%)]" />
        <div className="relative">
          <div className="flex items-center gap-2 mb-2">
            <Utensils className="h-4 w-4 text-orange-400" />
            <span className="text-xs font-bold text-orange-300 uppercase tracking-widest">PaikarFood</span>
          </div>
          <h1 className="text-2xl font-bold text-white mb-1">Food at Your Doorstep</h1>
          <p className="text-sm text-white/50 mb-4">Order from hundreds of restaurants. Fast delivery, great deals.</p>
          <div className="flex items-center gap-2 bg-white/8 border border-white/10 rounded-xl px-3 py-2.5">
            <MapPin className="h-4 w-4 text-primary shrink-0" />
            <span className="text-sm text-white/70 flex-1">Banani, Dhaka</span>
            <button className="text-xs text-primary font-semibold shrink-0">Change</button>
          </div>
        </div>
      </GlassCard>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35 pointer-events-none" />
        <Input value={search} onChange={(e) => setSearch(e.target.value)}
          placeholder="Search restaurants or dishes..."
          className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
      </div>

      {/* Cuisines */}
      {!search && (
        <div>
          <h2 className="text-sm font-semibold text-white/70 mb-3 uppercase tracking-wide">Cuisines</h2>
          <div className="flex gap-3 overflow-x-auto no-scrollbar">
            {CUISINES.map((c) => {
              const Icon = c.icon;
              return (
                <button key={c.label} className="flex flex-col items-center gap-2 shrink-0 p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/8 transition-colors min-w-[70px]">
                  <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center", c.color)}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <span className="text-[10px] text-white/60 whitespace-nowrap">{c.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Filter pills */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar">
        {FILTER_TABS.map((tab) => (
          <button key={tab} onClick={() => setActiveFilter(tab)}
            className={cn(
              "shrink-0 text-sm px-4 py-1.5 rounded-full border transition-all font-medium",
              activeFilter === tab
                ? "bg-primary border-primary text-white"
                : "bg-white/5 border-white/15 text-white/55 hover:text-white"
            )}>
            {tab === "Trending" && <Flame className="h-3 w-3 inline mr-1 text-orange-400" />}
            {tab === "Fast Delivery" && <Zap className="h-3 w-3 inline mr-1 text-yellow-400" />}
            {tab}
          </button>
        ))}
      </div>

      {/* Restaurant cards */}
      <div className="flex flex-col gap-3">
        {filtered.map((r) => (
          <GlassCard key={r.id} className="overflow-hidden glass-card-hover cursor-pointer p-0">
            <div className="relative">
              <img src={r.img} alt={r.name} className="w-full h-36 object-cover" />
              {!r.open && (
                <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                  <span className="text-white/70 font-semibold text-sm bg-black/50 px-3 py-1 rounded-full">Closed</span>
                </div>
              )}
              {r.promo && (
                <div className="absolute top-2 left-2 bg-primary text-white text-[10px] font-bold px-2 py-1 rounded-lg">
                  {r.promo}
                </div>
              )}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setFavorites((prev) => {
                    const next = new Set(prev);
                    next.has(r.id) ? next.delete(r.id) : next.add(r.id);
                    return next;
                  });
                }}
                className="absolute top-2 right-2 h-8 w-8 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center"
              >
                <Heart className={cn("h-4 w-4", favorites.has(r.id) ? "fill-red-400 text-red-400" : "text-white/70")} />
              </button>
            </div>
            <div className="p-3.5">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-sm font-bold text-white">{r.name}</p>
                  <p className="text-xs text-white/45 mt-0.5">{r.cuisine}</p>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <Star className="h-3.5 w-3.5 text-yellow-400 fill-yellow-400" />
                  <span className="text-sm font-semibold text-white">{r.rating}</span>
                  <span className="text-xs text-white/40">({r.reviews})</span>
                </div>
              </div>
              <div className="flex items-center gap-3 mt-2 text-xs text-white/50">
                <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {r.time}</span>
                <span>·</span>
                <span>Delivery: {r.fee}</span>
                <span>·</span>
                <span>Min: {r.minOrder}</span>
              </div>
              {r.open && (
                <Button className="mt-3 w-full bg-primary/20 hover:bg-primary/30 text-primary border border-primary/30 rounded-xl h-9 text-sm font-semibold">
                  Order Now
                </Button>
              )}
            </div>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}
