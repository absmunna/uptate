import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import { useListProducts, getListProductsQueryKey, useListVendors, getListVendorsQueryKey } from "@workspace/api-client-react";
import { ProductCard } from "@/components/product/ProductCard";
import {
  Zap, Star, Crown, TrendingUp, Gift, ShieldCheck,
  Clock, ChevronRight, BadgePercent, Coins,
} from "lucide-react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";

const PERKS = [
  { icon: BadgePercent, label: "Up to 40% off",    sub: "Exclusive member pricing",    color: "text-primary bg-primary/10" },
  { icon: Coins,        label: "PK Coin Cashback",  sub: "5% back on every order",      color: "text-yellow-400 bg-yellow-500/10" },
  { icon: Zap,          label: "Flash Access",      sub: "Early access to flash deals",  color: "text-orange-400 bg-orange-500/10" },
  { icon: ShieldCheck,  label: "Buyer Protection",  sub: "100% secure transactions",     color: "text-green-400 bg-green-500/10" },
  { icon: Gift,         label: "Free Gifts",        sub: "Surprise gifts on orders 5+",  color: "text-pink-400 bg-pink-500/10" },
  { icon: Clock,        label: "Priority Support",  sub: "24/7 dedicated support",       color: "text-purple-400 bg-purple-500/10" },
];

const PLANS = [
  {
    id: "basic",
    name: "Basic",
    price: 0,
    period: "Free forever",
    badge: null,
    perks: ["5% PK Coin cashback", "Standard support", "Basic deals access"],
    cta: "Current Plan",
    ctaStyle: "bg-white/10 border border-white/20 text-white/60",
    disabled: true,
  },
  {
    id: "pro",
    name: "PK Pro",
    price: 299,
    period: "per month",
    badge: "Most Popular",
    perks: ["10% PK Coin cashback", "Early flash access", "Priority support", "Free gifts on milestone orders"],
    cta: "Upgrade Now",
    ctaStyle: "bg-primary hover:bg-primary/90 text-white",
    disabled: false,
  },
  {
    id: "elite",
    name: "PK Elite",
    price: 799,
    period: "per month",
    badge: "Best Value",
    perks: ["20% PK Coin cashback", "Exclusive brand drops", "Personal shopper", "VIP event access", "White-glove delivery"],
    cta: "Go Elite",
    ctaStyle: "bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-400 text-black font-bold",
    disabled: false,
  },
];

export default function PKStorePage() {
  const { data: featuredProducts } = useListProducts(
    { sort: "trending", limit: 8 },
    { query: { queryKey: getListProductsQueryKey({ sort: "trending", limit: 8 }) } }
  );

  return (
    <div className="flex flex-col gap-6 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <div className="relative rounded-3xl overflow-hidden border border-yellow-500/20 p-8 md:p-10 bg-gradient-to-br from-yellow-600/20 via-orange-500/10 to-primary/10">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(234,179,8,0.15),transparent_60%)]" />
        <div className="relative flex flex-col md:flex-row items-start md:items-center gap-6">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-3">
              <Crown className="h-5 w-5 text-yellow-400" />
              <span className="text-xs font-bold text-yellow-300 uppercase tracking-widest">PK Store</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-extrabold text-white leading-tight mb-3">
              Premium Shopping.<br />
              <span className="text-gradient-gold">Rewarded Every Time.</span>
            </h1>
            <p className="text-white/55 max-w-md text-sm leading-relaxed mb-5">
              Unlock exclusive brand deals, earn PK Coins on every purchase, and enjoy VIP perks as a PK Store member.
            </p>
            <div className="flex items-center gap-3">
              <Button className="bg-yellow-400 hover:bg-yellow-300 text-black font-bold rounded-full px-6">
                Join PK Store
              </Button>
              <div className="flex items-center gap-1.5 text-sm text-white/60">
                <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                <span>340 PK Coins available</span>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 shrink-0">
            {[
              { label: "Active Members",  value: "24k+" },
              { label: "PK Coins Issued", value: "2.1M" },
              { label: "Avg Savings",     value: "৳1,200" },
              { label: "Brand Partners",  value: "180+" },
            ].map((s) => (
              <div key={s.label} className="bg-black/20 border border-yellow-500/20 rounded-2xl p-3 text-center">
                <p className="text-xl font-bold text-yellow-300">{s.value}</p>
                <p className="text-[10px] text-white/40 mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* PK Coin balance */}
      <GlassCard className="p-4 flex items-center gap-4 border border-yellow-500/20 bg-yellow-500/5">
        <div className="h-12 w-12 rounded-2xl bg-yellow-400/20 flex items-center justify-center shrink-0">
          <Coins className="h-6 w-6 text-yellow-400" />
        </div>
        <div className="flex-1">
          <p className="text-sm text-white/50">Your PK Coins Balance</p>
          <p className="text-2xl font-bold text-yellow-300">340 <span className="text-sm font-normal text-white/40">≈ ৳170 value</span></p>
        </div>
        <Link href="/wallet">
          <Button variant="outline" size="sm" className="border-yellow-500/30 bg-yellow-500/10 text-yellow-300 hover:bg-yellow-500/20 rounded-full">
            Redeem <ChevronRight className="h-3.5 w-3.5 ml-1" />
          </Button>
        </Link>
      </GlassCard>

      {/* Perks */}
      <div>
        <h2 className="text-lg font-semibold text-white mb-3">Member Perks</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {PERKS.map((p) => {
            const Icon = p.icon;
            return (
              <GlassCard key={p.label} className="p-4 flex items-start gap-3">
                <div className={cn("h-9 w-9 rounded-xl flex items-center justify-center shrink-0", p.color)}>
                  <Icon className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">{p.label}</p>
                  <p className="text-xs text-white/40 mt-0.5">{p.sub}</p>
                </div>
              </GlassCard>
            );
          })}
        </div>
      </div>

      {/* Membership plans */}
      <div>
        <h2 className="text-lg font-semibold text-white mb-3">Choose Your Plan</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {PLANS.map((plan) => (
            <div
              key={plan.id}
              className={cn(
                "glass-card rounded-2xl p-5 flex flex-col gap-4 border",
                plan.id === "pro" ? "border-primary/40 bg-primary/5" :
                plan.id === "elite" ? "border-yellow-500/40 bg-yellow-500/5" :
                "border-white/10"
              )}
            >
              {plan.badge && (
                <span className={cn(
                  "text-[10px] font-bold px-2 py-0.5 rounded-full w-fit",
                  plan.id === "elite" ? "bg-yellow-500/20 text-yellow-300" : "bg-primary/20 text-primary"
                )}>
                  {plan.badge}
                </span>
              )}
              <div>
                <p className="font-bold text-white text-lg">{plan.name}</p>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="text-2xl font-extrabold text-white">
                    {plan.price === 0 ? "Free" : `৳${plan.price}`}
                  </span>
                  {plan.price > 0 && <span className="text-xs text-white/40">{plan.period}</span>}
                </div>
              </div>
              <ul className="flex flex-col gap-1.5 flex-1">
                {plan.perks.map((perk) => (
                  <li key={perk} className="flex items-start gap-2 text-xs text-white/65">
                    <TrendingUp className="h-3.5 w-3.5 text-primary mt-0.5 shrink-0" />
                    {perk}
                  </li>
                ))}
              </ul>
              <Button disabled={plan.disabled} className={cn("w-full rounded-xl", plan.ctaStyle)}>
                {plan.cta}
              </Button>
            </div>
          ))}
        </div>
      </div>

      {/* Trending products */}
      {featuredProducts && featuredProducts.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold text-white">Trending in PK Store</h2>
            <Link href="/marketplace?sort=trending" className="text-xs text-primary hover:underline flex items-center gap-1">
              View all <ChevronRight className="h-3 w-3" />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {featuredProducts.slice(0, 4).map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </div>
      )}
    </div>
  );
}
