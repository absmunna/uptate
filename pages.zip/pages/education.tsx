import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import {
  BookOpen, Search, Star, Clock, Users, Play, ChevronRight,
  Award, Code2, Pen, BarChart3, Globe, Mic, Zap, CheckCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";

const CATEGORIES = [
  { icon: Code2,    label: "Programming", count: 180, color: "text-blue-400 bg-blue-500/10" },
  { icon: Pen,      label: "Design",      count: 95,  color: "text-pink-400 bg-pink-500/10" },
  { icon: BarChart3,label: "Business",    count: 120, color: "text-green-400 bg-green-500/10" },
  { icon: Globe,    label: "Language",    count: 60,  color: "text-cyan-400 bg-cyan-500/10" },
  { icon: Mic,      label: "Soft Skills", count: 45,  color: "text-purple-400 bg-purple-500/10" },
  { icon: Award,    label: "Certification",count: 80, color: "text-yellow-400 bg-yellow-500/10" },
];

const COURSES = [
  { id: "c1", title: "Full Stack Web Dev with React", instructor: "Mahbub Hasan", rating: 4.9, students: 12400, hours: 48, price: "৳2,999", originalPrice: "৳8,000", img: "https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?w=400", tags: ["React", "Node", "MongoDB"], level: "Beginner" },
  { id: "c2", title: "UI/UX Design Masterclass",     instructor: "Farida Islam",  rating: 4.8, students: 8900,  hours: 32, price: "৳1,999", originalPrice: "৳5,000", img: "https://images.unsplash.com/photo-1561070791-2526d30994b5?w=400", tags: ["Figma", "UX", "Design System"], level: "Intermediate" },
  { id: "c3", title: "Digital Marketing & SEO",       instructor: "Rafi Ahmed",    rating: 4.7, students: 15600, hours: 24, price: "৳1,499", originalPrice: "৳4,000", img: "https://images.unsplash.com/photo-1432888622747-4eb9a8efeb07?w=400", tags: ["SEO", "Facebook", "Analytics"], level: "Beginner" },
  { id: "c4", title: "IELTS Preparation Course",      instructor: "Nafisa Rahman", rating: 4.9, students: 22000, hours: 36, price: "৳3,499", originalPrice: "৳9,000", img: "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=400", tags: ["IELTS", "English", "Speaking"], level: "All Levels" },
];

const LEVEL_COLOR: Record<string, string> = {
  "Beginner":     "bg-green-500/15 text-green-400 border-green-500/25",
  "Intermediate": "bg-yellow-500/15 text-yellow-400 border-yellow-500/25",
  "Advanced":     "bg-red-500/15 text-red-400 border-red-500/25",
  "All Levels":   "bg-blue-500/15 text-blue-400 border-blue-500/25",
};

export default function EducationPage() {
  const [activeTab, setActiveTab] = useState<"courses" | "live" | "certificates">("courses");
  const [search, setSearch] = useState("");

  const filtered = COURSES.filter((c) =>
    !search || c.title.toLowerCase().includes(search.toLowerCase()) || c.instructor.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <GlassCard className="p-6 bg-gradient-to-br from-indigo-600/20 via-blue-500/10 to-transparent border border-indigo-500/20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,rgba(99,102,241,0.12),transparent_60%)]" />
        <div className="relative flex flex-col md:flex-row items-start md:items-center gap-5">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <BookOpen className="h-4 w-4 text-indigo-400" />
              <span className="text-xs font-bold text-indigo-300 uppercase tracking-widest">PaikarLearn</span>
            </div>
            <h1 className="text-2xl font-bold text-white mb-1">Learn. Grow. Earn.</h1>
            <p className="text-sm text-white/50 mb-4">1,200+ courses in Bangla and English. Learn from Bangladesh's top instructors.</p>
            <Button className="bg-indigo-500 hover:bg-indigo-400 text-white font-bold rounded-full px-6">
              Browse Courses
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-3 shrink-0">
            {[
              { label: "Courses",     value: "1,200+" },
              { label: "Instructors", value: "350+" },
              { label: "Students",    value: "180k+" },
              { label: "Certificates",value: "40k+" },
            ].map((s) => (
              <div key={s.label} className="bg-white/5 border border-indigo-500/20 rounded-xl p-3 text-center">
                <p className="text-lg font-bold text-indigo-300">{s.value}</p>
                <p className="text-[10px] text-white/40 mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </GlassCard>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {([["courses", "Courses"], ["live", "Live Classes"], ["certificates", "Certificates"]] as const).map(([tab, label]) => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={cn("flex-1 py-2.5 rounded-lg text-sm font-medium transition-all",
              activeTab === tab ? "bg-primary text-white" : "text-white/50 hover:text-white")}>
            {label}
          </button>
        ))}
      </div>

      {activeTab === "courses" && (
        <div className="flex flex-col gap-5">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35 pointer-events-none" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search courses, instructors..."
              className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
          </div>

          {/* Categories */}
          {!search && (
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {CATEGORIES.map((c) => {
                const Icon = c.icon;
                return (
                  <button key={c.label} className="flex flex-col items-center gap-2 p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/8 transition-colors">
                    <div className={cn("h-9 w-9 rounded-xl flex items-center justify-center", c.color)}>
                      <Icon className="h-[18px] w-[18px]" />
                    </div>
                    <div className="text-center">
                      <p className="text-[10px] text-white/65 font-medium leading-tight">{c.label}</p>
                      <p className="text-[9px] text-white/30">{c.count} courses</p>
                    </div>
                  </button>
                );
              })}
            </div>
          )}

          {/* Courses */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-base font-semibold text-white">
                {search ? `Results for "${search}"` : "Top Courses"}
              </h2>
              {!search && <span className="text-xs text-primary hover:underline cursor-pointer flex items-center gap-0.5">See all <ChevronRight className="h-3 w-3" /></span>}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {filtered.map((course) => (
                <GlassCard key={course.id} className="overflow-hidden glass-card-hover cursor-pointer p-0">
                  <div className="relative h-36">
                    <img src={course.img} alt={course.title} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                      <div className="h-12 w-12 rounded-full bg-primary/90 flex items-center justify-center">
                        <Play className="h-5 w-5 text-white ml-0.5" />
                      </div>
                    </div>
                    <div className="absolute top-2 left-2 flex gap-1 flex-wrap">
                      <span className={cn("text-[9px] font-bold px-2 py-0.5 rounded-full border", LEVEL_COLOR[course.level] ?? "bg-white/15 text-white border-white/20")}>
                        {course.level}
                      </span>
                    </div>
                  </div>
                  <div className="p-3.5">
                    <p className="text-sm font-bold text-white leading-tight">{course.title}</p>
                    <p className="text-xs text-white/45 mt-0.5">by {course.instructor}</p>
                    <div className="flex items-center gap-2 mt-1.5 text-xs text-white/50">
                      <span className="flex items-center gap-1"><Star className="h-3 w-3 text-yellow-400 fill-yellow-400" /> {course.rating}</span>
                      <span>({course.students.toLocaleString()} students)</span>
                      <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {course.hours}h</span>
                    </div>
                    <div className="flex gap-1 flex-wrap mt-2">
                      {course.tags.map((tag) => (
                        <span key={tag} className="text-[9px] bg-white/8 border border-white/12 text-white/55 px-1.5 py-0.5 rounded">{tag}</span>
                      ))}
                    </div>
                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center gap-2">
                        <span className="text-base font-bold text-primary">{course.price}</span>
                        <span className="text-xs text-white/30 line-through">{course.originalPrice}</span>
                      </div>
                      <Button size="sm" className="bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/30 rounded-full text-xs px-4">Enroll</Button>
                    </div>
                  </div>
                </GlassCard>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === "live" && (
        <div className="flex flex-col gap-3">
          <p className="text-sm text-white/50">Join live sessions with expert instructors.</p>
          {[
            { time: "Today, 8:00 PM", title: "React Hooks Deep Dive",    instructor: "Mahbub Hasan",  seats: 12, enrolled: true },
            { time: "Tomorrow, 7:00 PM", title: "Figma to Code Workflow",  instructor: "Farida Islam",  seats: 20, enrolled: false },
            { time: "Sat, 10:00 AM", title: "IELTS Speaking Practice",    instructor: "Nafisa Rahman", seats: 8,  enrolled: false },
          ].map((live) => (
            <GlassCard key={live.title} className="p-4 flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-red-500/15 flex items-center justify-center shrink-0">
                <Play className="h-5 w-5 text-red-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white truncate">{live.title}</p>
                <p className="text-xs text-white/40 mt-0.5">{live.instructor} · {live.time}</p>
                <p className="text-xs text-white/30 mt-0.5">{live.seats} seats left</p>
              </div>
              <Button size="sm" disabled={live.enrolled}
                className={cn("rounded-full text-xs shrink-0", live.enrolled
                  ? "bg-green-500/20 text-green-400 border border-green-500/30 cursor-default"
                  : "bg-primary hover:bg-primary/90 text-white")}>
                {live.enrolled ? <><CheckCircle className="h-3 w-3 mr-1" /> Enrolled</> : "Join"}
              </Button>
            </GlassCard>
          ))}
        </div>
      )}

      {activeTab === "certificates" && (
        <div className="flex flex-col gap-3">
          <p className="text-sm text-white/50">Earn recognized certificates from top companies.</p>
          {[
            { name: "React Developer",         issuer: "PaikarLearn × Tech BD",  progress: 100 },
            { name: "Digital Marketing Pro",    issuer: "PaikarLearn × GrowthHive",progress: 65 },
            { name: "IELTS Band 7+",            issuer: "PaikarLearn × Cambridge",  progress: 30 },
          ].map((cert) => (
            <GlassCard key={cert.name} className="p-4">
              <div className="flex items-start gap-3">
                <div className="h-10 w-10 rounded-xl bg-yellow-500/15 flex items-center justify-center shrink-0">
                  <Award className="h-5 w-5 text-yellow-400" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-white">{cert.name}</p>
                  <p className="text-xs text-white/40 mt-0.5">{cert.issuer}</p>
                  <div className="mt-2">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-white/40">Progress</span>
                      <span className="text-xs text-primary font-semibold">{cert.progress}%</span>
                    </div>
                    <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-primary to-indigo-400 rounded-full" style={{ width: `${cert.progress}%` }} />
                    </div>
                  </div>
                </div>
                {cert.progress === 100 && (
                  <Button size="sm" className="bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 rounded-full text-xs px-3 shrink-0">Download</Button>
                )}
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
}
