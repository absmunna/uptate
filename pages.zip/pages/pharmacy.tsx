import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import { useListProducts, getListProductsQueryKey, useListCategories } from "@workspace/api-client-react";
import { ProductCard } from "@/components/product/ProductCard";
import {
  Search, Pill, ShieldCheck, Truck, Clock, ChevronRight,
  Thermometer, Heart, Baby, Stethoscope, Eye, Syringe,
  AlertCircle, Upload, BadgeCheck,
} from "lucide-react";
import { cn } from "@/lib/utils";

const MED_CATS = [
  { icon: Pill,        label: "Medicines",      color: "text-blue-400 bg-blue-500/10" },
  { icon: Heart,       label: "Heart & BP",     color: "text-red-400 bg-red-500/10" },
  { icon: Thermometer, label: "Cold & Fever",   color: "text-orange-400 bg-orange-500/10" },
  { icon: Baby,        label: "Baby Care",      color: "text-pink-400 bg-pink-500/10" },
  { icon: Eye,         label: "Eye & ENT",      color: "text-cyan-400 bg-cyan-500/10" },
  { icon: Syringe,     label: "Vaccines",       color: "text-purple-400 bg-purple-500/10" },
  { icon: Stethoscope, label: "Devices",        color: "text-green-400 bg-green-500/10" },
  { icon: ShieldCheck, label: "Supplements",    color: "text-yellow-400 bg-yellow-500/10" },
];

const FEATURED_MEDICINES = [
  { name: "Napa 500mg", brand: "Beximco", price: "৳5", pack: "10 tablets", rx: false },
  { name: "Seclo 20mg", brand: "Square",  price: "৳35", pack: "10 capsules", rx: true },
  { name: "Amoxil 500",  brand: "GSK",    price: "৳120", pack: "6 capsules", rx: true },
  { name: "Vitamin C",   brand: "ACI",    price: "৳60", pack: "30 tablets", rx: false },
  { name: "ORS Saline",  brand: "ACME",   price: "৳15", pack: "per sachet", rx: false },
  { name: "Clotrimazole",brand: "Opsonin",price: "৳45", pack: "20g cream", rx: false },
];

export default function PharmacyPage() {
  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState<"medicines" | "upload" | "nearby">("medicines");

  const { data: products } = useListProducts(
    { sort: "trending", limit: 6 },
    { query: { queryKey: getListProductsQueryKey({ sort: "trending", limit: 6 }) } }
  );

  const filtered = FEATURED_MEDICINES.filter((m) =>
    !search || m.name.toLowerCase().includes(search.toLowerCase()) || m.brand.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <GlassCard className="p-5 md:p-7 bg-gradient-to-br from-green-600/20 via-teal-500/10 to-transparent border border-green-500/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-40 h-40 bg-green-400/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4" />
        <div className="relative flex flex-col md:flex-row items-start md:items-center gap-5">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Pill className="h-4 w-4 text-green-400" />
              <span className="text-xs font-bold text-green-300 uppercase tracking-widest">PaikarPharmacy</span>
            </div>
            <h1 className="text-2xl font-bold text-white mb-1">Medicine Delivered Fast</h1>
            <p className="text-sm text-white/50 mb-4">Genuine medicines, verified prescriptions, 30-min delivery across Dhaka.</p>
            <div className="flex items-center gap-3 text-xs text-white/45">
              <span className="flex items-center gap-1"><BadgeCheck className="h-3.5 w-3.5 text-green-400" /> DGDA Verified</span>
              <span className="flex items-center gap-1"><Truck className="h-3.5 w-3.5 text-blue-400" /> 30-min delivery</span>
              <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5 text-yellow-400" /> Open 24/7</span>
            </div>
          </div>
          <Button className="bg-green-500 hover:bg-green-400 text-black font-bold rounded-full px-6 shrink-0">
            Order Now
          </Button>
        </div>
      </GlassCard>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {([["medicines", "Browse"], ["upload", "Upload Rx"], ["nearby", "Near Me"]] as const).map(([tab, label]) => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={cn("flex-1 py-2.5 rounded-lg text-sm font-medium transition-all",
              activeTab === tab ? "bg-primary text-white" : "text-white/50 hover:text-white")}>
            {label}
          </button>
        ))}
      </div>

      {activeTab === "medicines" && (
        <div className="flex flex-col gap-5">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35 pointer-events-none" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="Search medicines, brands..."
              className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
          </div>

          {/* Categories */}
          {!search && (
            <div>
              <h2 className="text-sm font-semibold text-white/70 mb-3 uppercase tracking-wide">Categories</h2>
              <div className="grid grid-cols-4 gap-2">
                {MED_CATS.map((c) => {
                  const Icon = c.icon;
                  return (
                    <button key={c.label} className="flex flex-col items-center gap-2 p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/8 transition-colors">
                      <div className={cn("h-9 w-9 rounded-xl flex items-center justify-center", c.color)}>
                        <Icon className="h-4.5 w-4.5 h-[18px] w-[18px]" />
                      </div>
                      <span className="text-[10px] text-white/65 text-center leading-tight">{c.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Medicine list */}
          <div>
            <h2 className="text-sm font-semibold text-white/70 mb-3 uppercase tracking-wide">
              {search ? `Results for "${search}"` : "Popular Medicines"}
            </h2>
            <div className="flex flex-col gap-2">
              {filtered.map((med) => (
                <GlassCard key={med.name} className="p-3.5 flex items-center gap-3 glass-card-hover cursor-pointer">
                  <div className="h-10 w-10 rounded-xl bg-green-500/10 flex items-center justify-center shrink-0">
                    <Pill className="h-5 w-5 text-green-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="text-sm font-semibold text-white">{med.name}</p>
                      {med.rx && (
                        <span className="text-[9px] bg-red-500/20 text-red-300 border border-red-500/30 rounded px-1.5 py-0.5 font-bold">RX</span>
                      )}
                    </div>
                    <p className="text-xs text-white/40">{med.brand} · {med.pack}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-sm font-bold text-primary">{med.price}</p>
                    <Button size="sm" className="h-7 text-xs bg-primary/20 hover:bg-primary/30 text-primary border border-primary/30 rounded-lg mt-1 px-2">Add</Button>
                  </div>
                </GlassCard>
              ))}
              {filtered.length === 0 && (
                <GlassCard className="p-8 flex flex-col items-center gap-2 text-center">
                  <AlertCircle className="h-8 w-8 text-white/20" />
                  <p className="text-sm text-white/40">No medicines found for "{search}"</p>
                </GlassCard>
              )}
            </div>
          </div>
        </div>
      )}

      {activeTab === "upload" && (
        <GlassCard className="p-8 flex flex-col items-center gap-5 border border-dashed border-green-500/30 bg-green-500/5">
          <div className="h-16 w-16 rounded-2xl bg-green-500/15 flex items-center justify-center">
            <Upload className="h-8 w-8 text-green-400" />
          </div>
          <div className="text-center">
            <p className="font-semibold text-white mb-1">Upload Prescription</p>
            <p className="text-sm text-white/45">Take a photo or upload your doctor's prescription. Our pharmacist will verify and prepare your order.</p>
          </div>
          <Button className="bg-green-500 hover:bg-green-400 text-black font-bold rounded-full px-8">
            Upload Now
          </Button>
          <div className="flex items-center gap-2 text-xs text-white/35">
            <ShieldCheck className="h-3.5 w-3.5 text-green-400" />
            Your data is secure and private
          </div>
        </GlassCard>
      )}

      {activeTab === "nearby" && (
        <div className="flex flex-col gap-3">
          <p className="text-sm text-white/50">Pharmacies within 5km of your location</p>
          {[
            { name: "Popular Pharmacy",   dist: "0.3 km", open: true,  rating: 4.8 },
            { name: "Mediplus Pharmacy",  dist: "0.9 km", open: true,  rating: 4.6 },
            { name: "Life Care Pharmacy", dist: "1.4 km", open: false, rating: 4.5 },
            { name: "City Drug House",    dist: "2.1 km", open: true,  rating: 4.7 },
          ].map((p) => (
            <GlassCard key={p.name} className="p-4 flex items-center gap-3 glass-card-hover cursor-pointer">
              <div className="h-10 w-10 rounded-xl bg-green-500/10 flex items-center justify-center shrink-0">
                <Pill className="h-5 w-5 text-green-400" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-white">{p.name}</p>
                <p className="text-xs text-white/40">{p.dist} away · ★ {p.rating}</p>
              </div>
              <span className={cn("text-xs font-semibold px-2 py-1 rounded-full", p.open ? "bg-green-500/15 text-green-400" : "bg-white/5 text-white/30")}>
                {p.open ? "Open" : "Closed"}
              </span>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
}
