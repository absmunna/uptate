import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import { useListProducts, getListProductsQueryKey, useListVendors, getListVendorsQueryKey } from "@workspace/api-client-react";
import { ProductCard } from "@/components/product/ProductCard";
import { VendorCard } from "@/components/vendor/VendorCard";
import {
  Briefcase, Wrench, Scissors, UtensilsCrossed, Camera,
  Stethoscope, BookOpen, Truck, Code2, Paintbrush,
  Star, ChevronRight, Search, MapPin,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { useState } from "react";
import { cn } from "@/lib/utils";

const SERVICE_CATS = [
  { icon: Wrench,         label: "Repairs",       color: "text-blue-400 bg-blue-500/10" },
  { icon: Scissors,       label: "Beauty & Salon", color: "text-pink-400 bg-pink-500/10" },
  { icon: UtensilsCrossed,label: "Catering",       color: "text-orange-400 bg-orange-500/10" },
  { icon: Camera,         label: "Photography",    color: "text-purple-400 bg-purple-500/10" },
  { icon: Stethoscope,    label: "Healthcare",     color: "text-red-400 bg-red-500/10" },
  { icon: BookOpen,       label: "Tutoring",       color: "text-green-400 bg-green-500/10" },
  { icon: Truck,          label: "Delivery",       color: "text-cyan-400 bg-cyan-500/10" },
  { icon: Code2,          label: "Tech & IT",      color: "text-indigo-400 bg-indigo-500/10" },
  { icon: Paintbrush,     label: "Design",         color: "text-yellow-400 bg-yellow-500/10" },
];

export default function ServicesPage() {
  const [search, setSearch] = useState("");

  const { data: serviceProducts } = useListProducts(
    { type: "service", limit: 8 },
    { query: { queryKey: getListProductsQueryKey({ type: "service", limit: 8 }) } }
  );

  const { data: vendors } = useListVendors(
    {} as any,
    { query: { queryKey: getListVendorsQueryKey() } }
  );
  const serviceVendors = vendors?.filter((v) => v.type === "service").slice(0, 6);

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <GlassCard className="p-6 md:p-8 bg-gradient-to-br from-orange-500/20 via-primary/10 to-transparent border border-orange-500/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4" />
        <div className="relative">
          <div className="flex items-center gap-2 mb-3">
            <Briefcase className="h-5 w-5 text-orange-400" />
            <span className="text-xs font-semibold text-orange-300 uppercase tracking-wider">Services Marketplace</span>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-white leading-tight mb-2">
            Find Local Services
          </h1>
          <p className="text-white/55 text-sm mb-5 max-w-lg">
            Book verified service providers for repairs, beauty, healthcare, tech support and more — right from your neighborhood.
          </p>

          {/* Search */}
          <div className="relative max-w-lg">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40 pointer-events-none" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search services near you..."
              className="pl-11 pr-4 py-3 bg-white/10 border-white/20 text-white placeholder:text-white/35 rounded-xl h-12"
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1 text-xs text-white/40">
              <MapPin className="h-3 w-3 text-primary" />
              Dhaka
            </div>
          </div>
        </div>
      </GlassCard>

      {/* Service categories */}
      <div>
        <h2 className="text-lg font-semibold text-white mb-3">Browse by Category</h2>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-2">
          {SERVICE_CATS.map((cat) => {
            const Icon = cat.icon;
            return (
              <Link key={cat.label} href={`/marketplace?type=service&q=${cat.label}`}>
                <GlassCard className="p-3 flex flex-col items-center gap-2 text-center cursor-pointer glass-card-hover">
                  <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center", cat.color)}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <span className="text-[11px] text-white/70 font-medium leading-tight">{cat.label}</span>
                </GlassCard>
              </Link>
            );
          })}
        </div>
      </div>

      {/* How it works */}
      <div>
        <h2 className="text-lg font-semibold text-white mb-3">How It Works</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            { step: "01", title: "Browse & Book",   desc: "Find a service provider and book directly from their profile." },
            { step: "02", title: "Get Confirmed",   desc: "Receive booking confirmation with time slot and provider details." },
            { step: "03", title: "Pay & Review",    desc: "Pay securely after service, then leave an honest review." },
          ].map((s) => (
            <GlassCard key={s.step} className="p-4 flex items-start gap-3">
              <span className="text-2xl font-black text-primary/30">{s.step}</span>
              <div>
                <p className="text-sm font-semibold text-white">{s.title}</p>
                <p className="text-xs text-white/45 mt-0.5">{s.desc}</p>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>

      {/* Service vendors */}
      {serviceVendors && serviceVendors.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold text-white">Top Service Providers</h2>
            <Link href="/vendors" className="text-xs text-primary hover:underline flex items-center gap-1">
              View all <ChevronRight className="h-3 w-3" />
            </Link>
          </div>
          <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
            {serviceVendors.map((v) => <VendorCard key={v.id} vendor={v} />)}
          </div>
        </div>
      )}

      {/* Service listings */}
      {serviceProducts && serviceProducts.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold text-white">Featured Services</h2>
            <Link href="/marketplace?type=service" className="text-xs text-primary hover:underline flex items-center gap-1">
              View all <ChevronRight className="h-3 w-3" />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {serviceProducts.slice(0, 4).map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </div>
      )}

      {/* Become a provider CTA */}
      <GlassCard className="p-5 flex flex-col sm:flex-row items-center gap-4 border border-orange-500/20 bg-orange-500/5">
        <div className="h-12 w-12 rounded-2xl bg-orange-500/20 flex items-center justify-center shrink-0">
          <Star className="h-6 w-6 text-orange-400" />
        </div>
        <div className="flex-1 text-center sm:text-left">
          <p className="font-semibold text-white">Offer Your Services on PaikarMart</p>
          <p className="text-sm text-white/45 mt-0.5">Join 500+ service providers already earning on the platform.</p>
        </div>
        <Link href="/seller">
          <Button className="bg-orange-500 hover:bg-orange-600 text-white rounded-full whitespace-nowrap">
            Start Selling
          </Button>
        </Link>
      </GlassCard>
    </div>
  );
}
