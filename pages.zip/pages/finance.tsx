import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import {
  DollarSign, TrendingUp, Shield, ChevronRight, BadgeCheck,
  CreditCard, PiggyBank, BarChart3, Landmark, ArrowUpRight,
  ArrowDownLeft, Calculator, Lock, Zap, Globe,
} from "lucide-react";
import { cn } from "@/lib/utils";

const SERVICES = [
  { icon: Landmark,     label: "Microloans",    desc: "0% interest for first loan",  color: "text-blue-400 bg-blue-500/10" },
  { icon: PiggyBank,    label: "Savings",       desc: "Up to 9% APY",                color: "text-green-400 bg-green-500/10" },
  { icon: CreditCard,   label: "PK Card",       desc: "Cashback on every purchase",   color: "text-purple-400 bg-purple-500/10" },
  { icon: Globe,        label: "Remittance",    desc: "Send money abroad instantly",  color: "text-orange-400 bg-orange-500/10" },
  { icon: Shield,       label: "Insurance",     desc: "Life, Health, Business plans", color: "text-cyan-400 bg-cyan-500/10" },
  { icon: BarChart3,    label: "Investment",    desc: "Stocks, bonds, DPS plans",     color: "text-yellow-400 bg-yellow-500/10" },
];

const TRANSACTIONS = [
  { type: "in",  label: "Payment received",  amount: "+৳12,500", time: "2 min ago",   from: "Abdul Karim" },
  { type: "out", label: "Sent to bKash",     amount: "-৳3,000",  time: "1 hour ago",  from: "01XXXXXXXXX" },
  { type: "in",  label: "Cashback earned",   amount: "+৳250",    time: "3 hours ago", from: "PK Rewards" },
  { type: "out", label: "Utility bill paid", amount: "-৳1,800",  time: "Yesterday",   from: "DESCO" },
];

const LOAN_PRODUCTS = [
  { name: "Business Starter Loan", amount: "৳50,000–৳5,00,000", rate: "8.5%",  term: "12–36 months", approved: "72 hrs" },
  { name: "Farmer Credit",          amount: "৳10,000–৳1,00,000", rate: "5.0%",  term: "6–18 months",  approved: "24 hrs" },
  { name: "SME Growth Loan",        amount: "৳5,00,000–৳50L",    rate: "10.5%", term: "24–60 months", approved: "5 days" },
  { name: "Personal Microloan",     amount: "৳5,000–৳50,000",    rate: "12.0%", term: "3–12 months",  approved: "Instant" },
];

export default function FinancePage() {
  const [activeTab, setActiveTab] = useState<"wallet" | "loans" | "invest">("wallet");
  const [loanAmount, setLoanAmount] = useState("50000");

  const monthlyPayment = Math.round((parseInt(loanAmount || "0") * (8.5 / 100 / 12)) / (1 - Math.pow(1 + 8.5 / 100 / 12, -24)));

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Balance card */}
      <div className="relative rounded-3xl overflow-hidden p-6 bg-gradient-to-br from-primary via-blue-600 to-indigo-700 border border-blue-400/20">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,rgba(255,255,255,0.1),transparent_60%)]" />
        <div className="relative">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-white/70" />
              <span className="text-xs font-bold text-white/70 uppercase tracking-wider">PaikarFinance</span>
            </div>
            <Lock className="h-4 w-4 text-white/50" />
          </div>
          <p className="text-xs text-white/60 mb-1">Total Balance</p>
          <p className="text-4xl font-black text-white tracking-tight">৳ 42,850</p>
          <p className="text-xs text-white/50 mt-1">Last updated: just now</p>
          <div className="grid grid-cols-3 gap-2 mt-5">
            {[
              { label: "PK Coins",  value: "1,240", icon: Zap },
              { label: "Cashback",  value: "৳840",  icon: ArrowDownLeft },
              { label: "Credit",    value: "৳5,000",icon: CreditCard },
            ].map(s => { const Icon = s.icon; return (
              <div key={s.label} className="bg-white/10 rounded-xl p-2.5 text-center backdrop-blur-sm">
                <p className="text-sm font-bold text-white">{s.value}</p>
                <p className="text-[9px] text-white/60 mt-0.5">{s.label}</p>
              </div>
            ); })}
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { icon: ArrowUpRight,  label: "Send Money",  color: "text-green-400 bg-green-500/10" },
          { icon: ArrowDownLeft, label: "Receive",      color: "text-blue-400 bg-blue-500/10" },
          { icon: Calculator,    label: "EMI Calc",     color: "text-purple-400 bg-purple-500/10" },
        ].map(a => { const Icon = a.icon; return (
          <button key={a.label} className="flex flex-col items-center gap-2 p-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors">
            <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center", a.color)}>
              <Icon className="h-5 w-5" />
            </div>
            <p className="text-xs text-white/65 font-medium">{a.label}</p>
          </button>
        ); })}
      </div>

      {/* Services */}
      <div>
        <h2 className="text-base font-semibold text-white mb-3">Financial Services</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {SERVICES.map(s => { const Icon = s.icon; return (
            <GlassCard key={s.label} className="p-4 glass-card-hover cursor-pointer">
              <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center mb-2", s.color)}>
                <Icon className="h-5 w-5" />
              </div>
              <p className="text-sm font-bold text-white">{s.label}</p>
              <p className="text-xs text-white/40 mt-0.5">{s.desc}</p>
            </GlassCard>
          ); })}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {([["wallet","Transactions"],["loans","Loans"],["invest","Invest"]] as const).map(([t,l]) => (
          <button key={t} onClick={() => setActiveTab(t)} className={cn("flex-1 py-2.5 rounded-lg text-sm font-medium transition-all", activeTab===t?"bg-primary text-white":"text-white/50 hover:text-white")}>{l}</button>
        ))}
      </div>

      {activeTab === "wallet" && (
        <div className="flex flex-col gap-2">
          {TRANSACTIONS.map((tx, i) => (
            <GlassCard key={i} className="p-3.5 flex items-center gap-3">
              <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center shrink-0", tx.type === "in" ? "bg-green-500/10" : "bg-red-500/10")}>
                {tx.type === "in" ? <ArrowDownLeft className="h-5 w-5 text-green-400" /> : <ArrowUpRight className="h-5 w-5 text-red-400" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-white">{tx.label}</p>
                <p className="text-xs text-white/35 mt-0.5">{tx.from} · {tx.time}</p>
              </div>
              <p className={cn("text-sm font-bold shrink-0", tx.type === "in" ? "text-green-400" : "text-red-400")}>{tx.amount}</p>
            </GlassCard>
          ))}
        </div>
      )}

      {activeTab === "loans" && (
        <div className="flex flex-col gap-5">
          {/* EMI calculator */}
          <GlassCard className="p-4 border border-primary/20">
            <p className="text-sm font-semibold text-white mb-3 flex items-center gap-2"><Calculator className="h-4 w-4 text-primary" /> Quick EMI Calculator</p>
            <div className="flex items-center gap-3 mb-3">
              <span className="text-sm text-white/50">৳</span>
              <Input type="number" value={loanAmount} onChange={e => setLoanAmount(e.target.value)} className="bg-white/5 border-white/10 text-white rounded-xl" />
            </div>
            {loanAmount && parseInt(loanAmount) > 0 && (
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: "Monthly (24m, 8.5%)", value: `৳${monthlyPayment.toLocaleString()}` },
                  { label: "Total repayment",      value: `৳${(monthlyPayment * 24).toLocaleString()}` },
                  { label: "Total interest",       value: `৳${(monthlyPayment * 24 - parseInt(loanAmount)).toLocaleString()}` },
                ].map(r => (
                  <div key={r.label} className="bg-primary/10 border border-primary/20 rounded-xl p-2.5 text-center">
                    <p className="text-sm font-bold text-primary">{r.value}</p>
                    <p className="text-[9px] text-white/40 mt-0.5 leading-tight">{r.label}</p>
                  </div>
                ))}
              </div>
            )}
          </GlassCard>
          {/* Loan products */}
          <div className="flex flex-col gap-3">
            {LOAN_PRODUCTS.map(l => (
              <GlassCard key={l.name} className="p-4 glass-card-hover cursor-pointer">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-bold text-white">{l.name}</p>
                    <p className="text-xs text-white/45 mt-0.5">Amount: {l.amount}</p>
                    <div className="flex gap-3 mt-2 text-xs text-white/40">
                      <span>Rate: <span className="text-primary font-semibold">{l.rate}</span></span>
                      <span>Term: {l.term}</span>
                    </div>
                    <p className="text-xs text-green-400 mt-1 flex items-center gap-1"><Zap className="h-3 w-3" /> Approved in {l.approved}</p>
                  </div>
                  <Button size="sm" className="bg-primary/20 hover:bg-primary/30 text-primary border border-primary/30 rounded-full text-xs px-4 shrink-0">Apply</Button>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      )}

      {activeTab === "invest" && (
        <div className="flex flex-col gap-3">
          {[
            { name: "Fixed Deposit (12m)",   return_: "8.5% p.a.",  min: "৳10,000",  risk: "Zero",   color: "text-green-400 bg-green-500/10" },
            { name: "DPS Plan (36m)",        return_: "9.0% p.a.",  min: "৳500/mo",  risk: "Zero",   color: "text-green-400 bg-green-500/10" },
            { name: "Sanchayapatra (5yr)",   return_: "11.28%",     min: "৳10,000",  risk: "Govt",   color: "text-blue-400 bg-blue-500/10" },
            { name: "Stock Portfolio (DSE)", return_: "12–24%",     min: "৳5,000",   risk: "Medium", color: "text-yellow-400 bg-yellow-500/10" },
            { name: "Mutual Funds",          return_: "10–18%",     min: "৳1,000",   risk: "Low–Med",color: "text-purple-400 bg-purple-500/10" },
          ].map(inv => (
            <GlassCard key={inv.name} className="p-4 flex items-center gap-3 glass-card-hover cursor-pointer">
              <div className={cn("h-10 w-10 rounded-xl flex items-center justify-center shrink-0", inv.color)}>
                <TrendingUp className="h-5 w-5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-white">{inv.name}</p>
                <div className="flex gap-3 mt-1 text-xs text-white/40 flex-wrap">
                  <span>Return: <span className="text-green-400 font-semibold">{inv.return_}</span></span>
                  <span>Min: {inv.min}</span>
                  <span>Risk: {inv.risk}</span>
                </div>
              </div>
              <Button size="sm" className="bg-primary/20 hover:bg-primary/30 text-primary border border-primary/30 rounded-full text-xs px-3 shrink-0">Invest</Button>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
}
