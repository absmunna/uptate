import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import { useListProducts, getListProductsQueryKey } from "@workspace/api-client-react";
import { ProductCard } from "@/components/product/ProductCard";
import {
  Globe, Ship, FileText, Package, TrendingUp, Building2,
  ChevronRight, Shield, Clock, CheckCircle, Search,
  BadgeCheck, Plane, DollarSign,
} from "lucide-react";
import { cn } from "@/lib/utils";

const COUNTRIES = [
  { flag: "🇺🇸", name: "United States", trades: "2,400+", active: true },
  { flag: "🇬🇧", name: "United Kingdom", trades: "1,800+", active: true },
  { flag: "🇦🇺", name: "Australia",      trades: "900+",  active: true },
  { flag: "🇦🇪", name: "UAE",            trades: "1,200+",active: true },
  { flag: "🇸🇬", name: "Singapore",      trades: "800+",  active: true },
  { flag: "🇨🇦", name: "Canada",         trades: "600+",  active: false },
];

const PROCESS_STEPS = [
  { icon: Search,       step: "01", title: "Find Buyers",     desc: "Connect with verified international buyers across 50+ countries." },
  { icon: FileText,     step: "02", title: "Negotiate & PI",  desc: "Auto-generate Proforma Invoice and negotiate terms securely." },
  { icon: Ship,         step: "03", title: "Ship & Clear",    desc: "Logistics, customs documentation, and freight handled for you." },
  { icon: DollarSign,   step: "04", title: "Get Paid",        desc: "Receive payment via LC, TT, or PaikarPay escrow." },
];

const DOCUMENTS = [
  "Commercial Invoice", "Packing List", "Bill of Lading", "Certificate of Origin",
  "Phytosanitary Certificate", "Letter of Credit", "Export License",
];

export default function ExportPage() {
  const [activeTab, setActiveTab] = useState<"overview" | "products" | "documents">("overview");
  const [searchBuyer, setSearchBuyer] = useState("");

  const { data: products } = useListProducts(
    { sort: "trending", limit: 8 },
    { query: { queryKey: getListProductsQueryKey({ sort: "trending", limit: 8 }) } }
  );

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <GlassCard className="p-6 md:p-8 bg-gradient-to-br from-cyan-600/20 via-blue-500/10 to-transparent border border-cyan-500/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4" />
        <div className="relative flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-3">
              <Globe className="h-5 w-5 text-cyan-400" />
              <span className="text-xs font-bold text-cyan-300 uppercase tracking-widest">Export Portal</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-white leading-tight mb-2">
              Sell Bangladesh to the World
            </h1>
            <p className="text-white/55 text-sm leading-relaxed mb-5 max-w-lg">
              Connect with verified buyers in 50+ countries. Full export documentation, freight management, and secure payments — all in one portal.
            </p>
            <div className="flex items-center gap-3">
              <Button className="bg-cyan-500 hover:bg-cyan-400 text-black font-bold rounded-full px-6">
                Register as Exporter
              </Button>
              <Button variant="outline" className="border-white/20 bg-white/5 text-white hover:bg-white/10 rounded-full px-6">
                Find Buyers
              </Button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 shrink-0">
            {[
              { label: "Verified Buyers",  value: "8,400+" },
              { label: "Countries",        value: "50+" },
              { label: "Export Value",     value: "$2.1M" },
              { label: "Success Rate",     value: "94%" },
            ].map((s) => (
              <div key={s.label} className="bg-white/5 border border-cyan-500/20 rounded-xl p-3 text-center">
                <p className="text-lg font-bold text-cyan-300">{s.value}</p>
                <p className="text-[10px] text-white/40 mt-0.5">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </GlassCard>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {([["overview", "Overview"], ["products", "Products"], ["documents", "Documents"]] as const).map(([tab, label]) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={cn(
              "flex-1 py-2.5 rounded-lg text-sm font-medium transition-all",
              activeTab === tab ? "bg-primary text-white" : "text-white/50 hover:text-white"
            )}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Overview tab */}
      {activeTab === "overview" && (
        <div className="flex flex-col gap-5">
          {/* Process */}
          <div>
            <h2 className="text-lg font-semibold text-white mb-3">How Export Works</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {PROCESS_STEPS.map((s) => {
                const Icon = s.icon;
                return (
                  <GlassCard key={s.step} className="p-4 flex flex-col gap-3">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl font-black text-primary/25">{s.step}</span>
                      <div className="h-8 w-8 rounded-xl bg-primary/10 flex items-center justify-center">
                        <Icon className="h-4 w-4 text-primary" />
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">{s.title}</p>
                      <p className="text-xs text-white/40 mt-0.5">{s.desc}</p>
                    </div>
                  </GlassCard>
                );
              })}
            </div>
          </div>

          {/* Active markets */}
          <div>
            <h2 className="text-lg font-semibold text-white mb-3">Active Export Markets</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {COUNTRIES.map((c) => (
                <GlassCard key={c.name} className="p-4 flex items-center gap-3 glass-card-hover cursor-pointer">
                  <span className="text-2xl shrink-0">{c.flag}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-white truncate">{c.name}</p>
                    <p className="text-xs text-white/40">{c.trades} trades</p>
                  </div>
                  {c.active ? (
                    <BadgeCheck className="h-4 w-4 text-green-400 shrink-0" />
                  ) : (
                    <Clock className="h-4 w-4 text-white/25 shrink-0" />
                  )}
                </GlassCard>
              ))}
            </div>
          </div>

          {/* Buyer search */}
          <div>
            <h2 className="text-lg font-semibold text-white mb-3">Find International Buyers</h2>
            <GlassCard className="p-4 flex flex-col gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35 pointer-events-none" />
                <Input
                  value={searchBuyer}
                  onChange={(e) => setSearchBuyer(e.target.value)}
                  placeholder="Search buyers by country, product, or HS code..."
                  className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl"
                />
              </div>
              <div className="flex flex-col gap-2">
                {[
                  { company: "Global Imports LLC",  country: "🇺🇸 USA",    product: "Garments, Textiles", verified: true },
                  { company: "AUS Trade Partners",   country: "🇦🇺 Australia",product: "Food & Agro",       verified: true },
                  { company: "Gulf Commerce Group",  country: "🇦🇪 UAE",    product: "Handicrafts",       verified: false },
                ].map((b) => (
                  <div key={b.company} className="flex items-center gap-3 p-3 bg-white/5 rounded-xl">
                    <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                      <Building2 className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <p className="text-sm font-semibold text-white truncate">{b.company}</p>
                        {b.verified && <BadgeCheck className="h-3.5 w-3.5 text-green-400 shrink-0" />}
                      </div>
                      <p className="text-xs text-white/40">{b.country} · {b.product}</p>
                    </div>
                    <Button size="sm" variant="outline" className="bg-white/5 border-white/15 text-white hover:bg-white/10 rounded-full text-xs shrink-0">
                      Connect
                    </Button>
                  </div>
                ))}
              </div>
            </GlassCard>
          </div>
        </div>
      )}

      {/* Products tab */}
      {activeTab === "products" && (
        <div className="flex flex-col gap-4">
          <p className="text-sm text-white/50">Products eligible for international export based on demand data.</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {products?.slice(0, 8).map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </div>
      )}

      {/* Documents tab */}
      {activeTab === "documents" && (
        <div className="flex flex-col gap-3">
          <p className="text-sm text-white/50 mb-1">Auto-generate all required export documents.</p>
          {DOCUMENTS.map((doc) => (
            <GlassCard key={doc} className="p-4 flex items-center gap-3 glass-card-hover cursor-pointer">
              <div className="h-9 w-9 rounded-xl bg-cyan-500/10 flex items-center justify-center shrink-0">
                <FileText className="h-4 w-4 text-cyan-400" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-white">{doc}</p>
                <p className="text-xs text-white/35">Click to generate</p>
              </div>
              <Button size="sm" className="bg-primary/20 hover:bg-primary/30 text-primary rounded-full text-xs border border-primary/30">
                Generate
              </Button>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
}
