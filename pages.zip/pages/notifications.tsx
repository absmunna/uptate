import { useListNotifications, getListNotificationsQueryKey } from "@workspace/api-client-react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Bell, ShoppingBag, Star, MessageSquare, AlertCircle, FileText, Check, Settings } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";
import { useState } from "react";

const TYPE_META: Record<string, { icon: React.ElementType; color: string; bg: string }> = {
  order:        { icon: ShoppingBag, color: "text-blue-400",   bg: "bg-blue-500/10" },
  review:       { icon: Star,        color: "text-yellow-400", bg: "bg-yellow-500/10" },
  message:      { icon: MessageSquare, color: "text-green-400", bg: "bg-green-500/10" },
  demand_match: { icon: FileText,    color: "text-purple-400", bg: "bg-purple-500/10" },
  admin:        { icon: AlertCircle, color: "text-red-400",    bg: "bg-red-500/10" },
  default:      { icon: Bell,        color: "text-primary",    bg: "bg-primary/10" },
};

export default function Notifications() {
  const { data: notifications } = useListNotifications({ query: { queryKey: getListNotificationsQueryKey() } });
  const [filter, setFilter] = useState<"all" | "unread">("all");

  if (!notifications) {
    return (
      <div className="p-4 max-w-2xl mx-auto">
        <div className="flex flex-col gap-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="glass-card rounded-2xl p-4 flex gap-4">
              <div className="h-10 w-10 rounded-full skeleton-shimmer shrink-0" />
              <div className="flex-1 flex flex-col gap-2">
                <div className="h-3 w-2/3 rounded skeleton-shimmer" />
                <div className="h-3 w-1/2 rounded skeleton-shimmer" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  const shown = filter === "unread"
    ? notifications.filter((n) => !n.read)
    : notifications;

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="flex flex-col gap-4 p-4 max-w-2xl mx-auto w-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            Notifications
            {unreadCount > 0 && (
              <span className="text-xs font-semibold bg-primary text-white px-2 py-0.5 rounded-full">
                {unreadCount}
              </span>
            )}
          </h1>
          <p className="text-sm text-white/40 mt-0.5">Stay on top of what matters</p>
        </div>
        <button className="h-9 w-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white/50 hover:text-white transition-colors">
          <Settings className="h-4 w-4" />
        </button>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {(["all", "unread"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            className={cn(
              "flex-1 py-2 rounded-lg text-sm font-medium capitalize transition-all",
              filter === tab ? "bg-primary text-white" : "text-white/50 hover:text-white"
            )}
          >
            {tab === "all" ? `All (${notifications.length})` : `Unread (${unreadCount})`}
          </button>
        ))}
      </div>

      {/* Empty */}
      {shown.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 gap-3 text-center">
          <div className="h-16 w-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center">
            <Check className="h-8 w-8 text-green-400" />
          </div>
          <p className="text-white font-medium">
            {filter === "unread" ? "All caught up!" : "No notifications yet"}
          </p>
          <p className="text-sm text-white/40">
            {filter === "unread" ? "You've read all notifications." : "We'll notify you when something happens."}
          </p>
        </div>
      )}

      {/* Notification list */}
      <div className="flex flex-col gap-2">
        {shown.map((n) => {
          const meta = TYPE_META[n.type] ?? TYPE_META.default!;
          const Icon = meta.icon;
          return (
            <div
              key={n.id}
              className={cn(
                "glass-card rounded-2xl p-4 flex gap-3 cursor-pointer hover:bg-white/5 transition-colors",
                !n.read && "border-primary/20 bg-primary/3"
              )}
            >
              {/* Icon or avatar */}
              {n.actorAvatarUrl ? (
                <Avatar className="h-10 w-10 border border-white/10 shrink-0">
                  <AvatarImage src={n.actorAvatarUrl} />
                  <AvatarFallback>U</AvatarFallback>
                </Avatar>
              ) : (
                <div className={cn("h-10 w-10 rounded-full flex items-center justify-center shrink-0 border border-white/10", meta.bg)}>
                  <Icon className={cn("h-5 w-5", meta.color)} />
                </div>
              )}

              {/* Body */}
              <div className="flex-1 min-w-0 flex flex-col gap-0.5">
                <div className="flex items-start justify-between gap-2">
                  <p className={cn("text-sm font-medium leading-snug", n.read ? "text-white/80" : "text-white")}>
                    {n.title}
                  </p>
                  <span className="text-[10px] text-white/35 shrink-0 whitespace-nowrap">
                    {formatDistanceToNow(new Date(n.createdAt), { addSuffix: true })}
                  </span>
                </div>
                <p className="text-xs text-white/55 line-clamp-2">{n.body}</p>
              </div>

              {/* Unread dot */}
              {!n.read && (
                <div className="shrink-0 mt-1">
                  <div className="h-2 w-2 rounded-full bg-primary" />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
