import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import {
  Phone, Wifi, Zap, ChevronRight, Clock, Star,
  Signal, Globe, Shield, Check, AlertCircle, ArrowRight,
} from "lucide-react";
import { cn } from "@/lib/utils";

const OPERATORS = [
  { name: "Grameenphone", short: "GP",    color: "text-blue-400 bg-blue-500/10",   users: "80M+" },
  { name: "Banglalink",   short: "BL",    color: "text-red-400 bg-red-500/10",     users: "38M+" },
  { name: "Robi",         short: "Robi",  color: "text-orange-400 bg-orange-500/10",users: "55M+" },
  { name: "Teletalk",     short: "TT",    color: "text-green-400 bg-green-500/10", users: "7M+" },
];

const DATA_PACKS = [
  { id: "d1", name: "3GB 3 Days",    price: "৳39",  validity: "3 days",   operator: "GP",   type: "social" },
  { id: "d2", name: "10GB 30 Days",  price: "৳129", validity: "30 days",  operator: "GP",   type: "internet" },
  { id: "d3", name: "5GB 7 Days",    price: "৳69",  validity: "7 days",   operator: "BL",   type: "internet" },
  { id: "d4", name: "Unlimited Night",price: "৳29", validity: "7 nights", operator: "Robi", type: "night" },
  { id: "d5", name: "Facebook Pack", price: "৳19",  validity: "7 days",   operator: "TT",   type: "social" },
  { id: "d6", name: "20GB Monthly",  price: "৳249", validity: "30 days",  operator: "GP",   type: "internet" },
];

const RECENT_RECHARGES = [
  { number: "017XX XXXXX", op: "GP",  amount: "৳100", time: "2 days ago" },
  { number: "019XX XXXXX", op: "BL",  amount: "৳50",  time: "1 week ago" },
];

const PACK_COLOR: Record<string, string> = {
  social:   "bg-blue-500/15 text-blue-300 border-blue-500/25",
  internet: "bg-green-500/15 text-green-300 border-green-500/25",
  night:    "bg-indigo-500/15 text-indigo-300 border-indigo-500/25",
};

export default function TelecomPage() {
  const [activeTab, setActiveTab] = useState<"recharge" | "data" | "bill">("recharge");
  const [number, setNumber] = useState("");
  const [amount, setAmount] = useState("100");
  const [selectedOp, setSelectedOp] = useState("GP");

  const quickAmounts = ["৳10", "৳20", "৳50", "৳100", "৳200", "৳500"];

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <GlassCard className="p-5 bg-gradient-to-br from-teal-600/20 via-cyan-500/10 to-transparent border border-teal-500/25 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-40 h-40 bg-teal-400/10 rounded-full blur-3xl" />
        <div className="relative">
          <div className="flex items-center gap-2 mb-1.5">
            <Signal className="h-4 w-4 text-teal-400" />
            <span className="text-xs font-bold text-teal-300 uppercase tracking-widest">PaikarTelecom</span>
          </div>
          <h1 className="text-2xl font-bold text-white mb-1">Mobile Recharge & Data</h1>
          <p className="text-sm text-white/50 mb-4">GP, BL, Robi, Teletalk — instant recharge & data packs.</p>
          <div className="grid grid-cols-4 gap-2">
            {OPERATORS.map(op => (
              <button key={op.short} onClick={() => setSelectedOp(op.short)}
                className={cn("p-2.5 rounded-xl border transition-all flex flex-col items-center gap-1",
                  selectedOp === op.short ? "border-primary/40 bg-primary/10" : "bg-white/5 border-white/10 hover:bg-white/8")}>
                <div className={cn("h-8 w-8 rounded-lg flex items-center justify-center text-xs font-black", op.color)}>{op.short}</div>
                <p className="text-[9px] text-white/40">{op.users}</p>
              </button>
            ))}
          </div>
        </div>
      </GlassCard>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {([["recharge","Recharge"],["data","Data Packs"],["bill","Bill Pay"]] as const).map(([t,l]) => (
          <button key={t} onClick={() => setActiveTab(t)} className={cn("flex-1 py-2.5 rounded-lg text-sm font-medium transition-all", activeTab===t?"bg-primary text-white":"text-white/50 hover:text-white")}>{l}</button>
        ))}
      </div>

      {activeTab === "recharge" && (
        <div className="flex flex-col gap-4">
          <GlassCard className="p-5 flex flex-col gap-3">
            <p className="text-sm font-semibold text-white">Mobile Recharge</p>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35 pointer-events-none" />
              <Input value={number} onChange={e => setNumber(e.target.value)} placeholder="Enter mobile number" className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs text-white/40">Amount (৳)</label>
              <Input type="number" value={amount} onChange={e => setAmount(e.target.value)} className="bg-white/5 border-white/10 text-white rounded-xl" />
            </div>
            <div className="flex gap-2 flex-wrap">
              {quickAmounts.map(a => (
                <button key={a} onClick={() => setAmount(a.replace("৳",""))}
                  className={cn("px-3 py-1.5 rounded-full border text-xs transition-all", amount === a.replace("৳","") ? "bg-primary/15 border-primary/40 text-primary" : "bg-white/5 border-white/10 text-white/55 hover:text-white")}>
                  {a}
                </button>
              ))}
            </div>
            <Button className="bg-teal-500 hover:bg-teal-400 text-white h-11 rounded-xl font-bold">
              <Zap className="h-4 w-4 mr-2" /> Recharge Now
            </Button>
          </GlassCard>

          {/* Recent recharges */}
          {RECENT_RECHARGES.length > 0 && (
            <div>
              <p className="text-sm font-semibold text-white mb-2.5">Recent Recharges</p>
              <div className="flex flex-col gap-2">
                {RECENT_RECHARGES.map((r, i) => (
                  <GlassCard key={i} className="p-3.5 flex items-center gap-3 glass-card-hover cursor-pointer">
                    <div className="h-9 w-9 rounded-xl bg-teal-500/10 flex items-center justify-center shrink-0">
                      <Phone className="h-4.5 w-[18px] h-[18px] text-teal-400" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-white font-medium">{r.number}</p>
                      <p className="text-xs text-white/35">{r.op} · {r.time}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-primary">{r.amount}</span>
                      <Button size="sm" className="h-7 rounded-full bg-white/8 text-white/60 hover:bg-white/15 text-xs px-3">Repeat</Button>
                    </div>
                  </GlassCard>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === "data" && (
        <div className="flex flex-col gap-4">
          <div className="flex gap-2 overflow-x-auto no-scrollbar">
            {["All","GP","BL","Robi","TT"].map(op => (
              <button key={op} onClick={() => op !== "All" && setSelectedOp(op)}
                className={cn("shrink-0 px-3 py-1.5 rounded-full border text-xs font-medium transition-all",
                  (op === "All" || selectedOp === op) ? "bg-primary/15 border-primary/40 text-primary" : "bg-white/5 border-white/10 text-white/55")}>
                {op}
              </button>
            ))}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {DATA_PACKS.filter(p => p.operator === selectedOp || selectedOp === "All").map(pack => (
              <GlassCard key={pack.id} className="p-4 flex items-center gap-3 glass-card-hover cursor-pointer">
                <div className="h-10 w-10 rounded-xl bg-teal-500/10 flex items-center justify-center shrink-0">
                  <Wifi className="h-5 w-5 text-teal-400" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-bold text-white">{pack.name}</p>
                    <span className={cn("text-[9px] font-bold px-1.5 py-0.5 rounded-full border", PACK_COLOR[pack.type] ?? "bg-white/10 text-white/50 border-white/20")}>{pack.type}</span>
                  </div>
                  <div className="flex gap-3 text-xs text-white/40 mt-0.5">
                    <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {pack.validity}</span>
                    <span>{pack.operator}</span>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1.5 shrink-0">
                  <span className="text-base font-bold text-primary">{pack.price}</span>
                  <Button size="sm" className="h-7 rounded-full bg-teal-500/20 hover:bg-teal-500/30 text-teal-300 border border-teal-500/30 text-xs px-3">Buy</Button>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      )}

      {activeTab === "bill" && (
        <div className="flex flex-col gap-3">
          {[
            { name: "Electricity",  desc: "DESCO, DPDC, REB, BPDB",    icon: Zap,          color: "text-yellow-400 bg-yellow-500/10" },
            { name: "Internet/ISP", desc: "Fiber, broadband providers",  icon: Wifi,         color: "text-blue-400 bg-blue-500/10" },
            { name: "WASA Water",   desc: "Dhaka WASA bill payment",     icon: Globe,        color: "text-cyan-400 bg-cyan-500/10" },
            { name: "Gas Bill",     desc: "TITAS, Bakhrabad gas bills",  icon: Signal,       color: "text-orange-400 bg-orange-500/10" },
            { name: "Insurance",    desc: "Premium payment for policies", icon: Shield,      color: "text-green-400 bg-green-500/10" },
          ].map(b => { const Icon = b.icon; return (
            <GlassCard key={b.name} className="p-4 flex items-center gap-3 glass-card-hover cursor-pointer">
              <div className={cn("h-11 w-11 rounded-xl flex items-center justify-center shrink-0", b.color)}>
                <Icon className="h-5 w-5" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-bold text-white">{b.name}</p>
                <p className="text-xs text-white/40 mt-0.5">{b.desc}</p>
              </div>
              <ArrowRight className="h-4 w-4 text-white/25 shrink-0" />
            </GlassCard>
          ); })}
        </div>
      )}
    </div>
  );
}
