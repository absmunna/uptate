import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import { useListVendors, getListVendorsQueryKey } from "@workspace/api-client-react";
import {
  Search, MapPin, Star, Wifi, Car, Coffee, Waves,
  ChevronRight, Calendar, Users, Heart, BadgeCheck,
  Building, Plane, Train, UtensilsCrossed, Sunset,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";

const DESTINATIONS = [
  { name: "Cox's Bazar",  img: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=300", hotels: 48, tag: "Beach" },
  { name: "Sylhet",       img: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=300", hotels: 32, tag: "Tea Garden" },
  { name: "Bandarban",    img: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=300", hotels: 24, tag: "Hills" },
  { name: "Dhaka",        img: "https://images.unsplash.com/photo-1587474260584-136574528ed5?w=300", hotels: 120, tag: "City" },
  { name: "Sundarbans",   img: "https://images.unsplash.com/photo-1574258495973-f010dfbb5371?w=300", hotels: 18, tag: "Mangrove" },
];

const AMENITIES = [
  { icon: Wifi,            label: "Free WiFi" },
  { icon: Car,             label: "Parking" },
  { icon: Coffee,          label: "Breakfast" },
  { icon: Waves,           label: "Pool" },
  { icon: UtensilsCrossed, label: "Restaurant" },
];

const FEATURED_HOTELS = [
  { id: "h1", name: "The Pearl Beach Resort",  location: "Cox's Bazar",  rating: 4.9, reviews: 2340, priceFrom: "৳4,500", img: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=400", tags: ["Beachfront", "Spa", "Pool"] },
  { id: "h2", name: "Sylhet Grand Hotel",      location: "Sylhet City",  rating: 4.7, reviews: 1120, priceFrom: "৳2,800", img: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400", tags: ["City View", "Gym", "WiFi"] },
  { id: "h3", name: "Bandarban Eco Resort",    location: "Bandarban",    rating: 4.8, reviews: 890,  priceFrom: "৳3,200", img: "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=400", tags: ["Hill View", "Trekking", "Organic"] },
  { id: "h4", name: "Dhaka Regency Hotel",     location: "Gulshan, Dhaka",rating: 4.6, reviews: 3450, priceFrom: "৳6,000", img: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400", tags: ["Business", "Rooftop", "Valet"] },
];

export default function HotelPage() {
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [guests, setGuests] = useState("2");
  const [dest, setDest] = useState("");
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [activeTab, setActiveTab] = useState<"hotels" | "packages" | "transport">("hotels");

  const { data: vendors } = useListVendors(
    { type: "hotel" },
    { query: { queryKey: getListVendorsQueryKey({ type: "hotel" }) } }
  );

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <div className="relative rounded-3xl overflow-hidden border border-blue-500/20 h-48 md:h-56">
        <img src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1200" alt="Travel" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
        <div className="absolute bottom-4 left-5 right-5">
          <div className="flex items-center gap-2 mb-1">
            <Sunset className="h-4 w-4 text-yellow-400" />
            <span className="text-xs font-bold text-yellow-300 uppercase tracking-widest">PaikarTravel</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Explore Bangladesh</h1>
          <p className="text-sm text-white/65">Hotels, resorts, and travel packages — all in one place.</p>
        </div>
      </div>

      {/* Search box */}
      <GlassCard className="p-4 flex flex-col gap-3">
        <div className="relative">
          <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35 pointer-events-none" />
          <Input value={dest} onChange={(e) => setDest(e.target.value)}
            placeholder="Where do you want to go?"
            className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div className="flex flex-col gap-1">
            <label className="text-[10px] text-white/40 uppercase tracking-wider">Check In</label>
            <Input type="date" value={checkIn} onChange={(e) => setCheckIn(e.target.value)}
              className="bg-white/5 border-white/10 text-white rounded-xl text-sm h-9" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] text-white/40 uppercase tracking-wider">Check Out</label>
            <Input type="date" value={checkOut} onChange={(e) => setCheckOut(e.target.value)}
              className="bg-white/5 border-white/10 text-white rounded-xl text-sm h-9" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] text-white/40 uppercase tracking-wider">Guests</label>
            <Input type="number" min="1" value={guests} onChange={(e) => setGuests(e.target.value)}
              className="bg-white/5 border-white/10 text-white rounded-xl text-sm h-9" />
          </div>
        </div>
        <Button className="bg-primary hover:bg-primary/90 text-white h-11 rounded-xl font-semibold">
          <Search className="h-4 w-4 mr-2" /> Search Hotels
        </Button>
      </GlassCard>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {([["hotels", "Hotels"], ["packages", "Packages"], ["transport", "Transport"]] as const).map(([tab, label]) => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={cn("flex-1 py-2.5 rounded-lg text-sm font-medium transition-all",
              activeTab === tab ? "bg-primary text-white" : "text-white/50 hover:text-white")}>
            {label}
          </button>
        ))}
      </div>

      {activeTab === "hotels" && (
        <div className="flex flex-col gap-5">
          {/* Popular destinations */}
          <div>
            <h2 className="text-base font-semibold text-white mb-3">Popular Destinations</h2>
            <div className="flex gap-3 overflow-x-auto no-scrollbar pb-1">
              {DESTINATIONS.map((d) => (
                <button key={d.name} className="shrink-0 relative rounded-2xl overflow-hidden w-28 h-28 group">
                  <img src={d.img} alt={d.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                  <div className="absolute bottom-1.5 left-2 right-2">
                    <p className="text-[11px] font-bold text-white leading-tight">{d.name}</p>
                    <p className="text-[9px] text-white/60">{d.hotels} hotels</p>
                  </div>
                  <span className="absolute top-1.5 left-1.5 text-[9px] bg-primary/90 text-white px-1.5 py-0.5 rounded-md font-bold">{d.tag}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Featured hotels */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-base font-semibold text-white">Featured Hotels</h2>
              <span className="text-xs text-primary cursor-pointer hover:underline flex items-center gap-0.5">
                View all <ChevronRight className="h-3 w-3" />
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {FEATURED_HOTELS.map((h) => (
                <GlassCard key={h.id} className="overflow-hidden glass-card-hover cursor-pointer p-0">
                  <div className="relative h-44">
                    <img src={h.img} alt={h.name} className="w-full h-full object-cover" />
                    <button
                      onClick={(e) => { e.stopPropagation(); setFavorites((prev) => { const n = new Set(prev); n.has(h.id) ? n.delete(h.id) : n.add(h.id); return n; }); }}
                      className="absolute top-2 right-2 h-8 w-8 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center"
                    >
                      <Heart className={cn("h-4 w-4", favorites.has(h.id) ? "fill-red-400 text-red-400" : "text-white/70")} />
                    </button>
                    <div className="absolute top-2 left-2 flex gap-1 flex-wrap">
                      {h.tags.map((t) => (
                        <span key={t} className="text-[9px] bg-black/50 backdrop-blur-sm text-white px-2 py-0.5 rounded-full border border-white/20">{t}</span>
                      ))}
                    </div>
                  </div>
                  <div className="p-3.5">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <p className="text-sm font-bold text-white leading-tight">{h.name}</p>
                      <div className="flex items-center gap-1 shrink-0">
                        <Star className="h-3.5 w-3.5 text-yellow-400 fill-yellow-400" />
                        <span className="text-sm font-semibold text-white">{h.rating}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-white/45 mb-2">
                      <MapPin className="h-3 w-3 shrink-0" />
                      {h.location} · {h.reviews} reviews
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xs text-white/40">From </span>
                        <span className="text-base font-bold text-primary">{h.priceFrom}</span>
                        <span className="text-xs text-white/40">/night</span>
                      </div>
                      <Button size="sm" className="bg-primary hover:bg-primary/90 text-white rounded-full text-xs px-4">Book</Button>
                    </div>
                  </div>
                </GlassCard>
              ))}
            </div>
          </div>

          {/* Amenity filter */}
          <div>
            <h2 className="text-sm font-semibold text-white/70 mb-3 uppercase tracking-wide">Filter by Amenity</h2>
            <div className="flex gap-2 flex-wrap">
              {AMENITIES.map((a) => {
                const Icon = a.icon;
                return (
                  <button key={a.label} className="flex items-center gap-1.5 text-xs bg-white/5 border border-white/10 hover:bg-white/10 text-white/65 hover:text-white px-3 py-2 rounded-full transition-all">
                    <Icon className="h-3.5 w-3.5" /> {a.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* From API */}
          {vendors && vendors.filter((v) => v.type === "hotel").length > 0 && (
            <div>
              <h2 className="text-base font-semibold text-white mb-3">Listed on PaikarMart</h2>
              <div className="flex flex-col gap-2">
                {vendors.filter((v) => v.type === "hotel").map((v) => (
                  <GlassCard key={v.id} className="p-3.5 flex items-center gap-3 glass-card-hover cursor-pointer">
                    <div className="h-11 w-11 rounded-xl bg-blue-500/10 overflow-hidden shrink-0">
                      {v.avatarUrl && <img src={v.avatarUrl} alt={v.name} className="w-full h-full object-cover" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <p className="text-sm font-semibold text-white truncate">{v.name}</p>
                        {v.verified && <BadgeCheck className="h-3.5 w-3.5 text-blue-400 shrink-0" />}
                      </div>
                      <p className="text-xs text-white/40 truncate">{v.tagline ?? "Hotel & Resort"}</p>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <Star className="h-3.5 w-3.5 text-yellow-400 fill-yellow-400" />
                      <span className="text-sm font-semibold text-white">{v.rating?.toFixed(1)}</span>
                    </div>
                  </GlassCard>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === "packages" && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[
            { name: "Cox's Bazar 3N/4D", price: "৳12,500", desc: "Hotel + Transfers + Breakfast", img: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400" },
            { name: "Sylhet Tea Tour 2N/3D", price: "৳8,200", desc: "Eco resort + Garden tour", img: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=400" },
            { name: "Sundarban Safari 2N", price: "৳15,000", desc: "Boat tour + Eco cabin", img: "https://images.unsplash.com/photo-1574258495973-f010dfbb5371?w=400" },
            { name: "Bandarban Hills 3N", price: "৳9,500", desc: "Trekking + Waterfall + Meals", img: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400" },
          ].map((pkg) => (
            <GlassCard key={pkg.name} className="overflow-hidden glass-card-hover cursor-pointer p-0">
              <img src={pkg.img} alt={pkg.name} className="w-full h-32 object-cover" />
              <div className="p-3.5">
                <p className="text-sm font-bold text-white">{pkg.name}</p>
                <p className="text-xs text-white/45 mt-0.5">{pkg.desc}</p>
                <div className="flex items-center justify-between mt-3">
                  <span className="text-base font-bold text-primary">{pkg.price}</span>
                  <Button size="sm" className="bg-primary/20 hover:bg-primary/30 text-primary border border-primary/30 rounded-full text-xs">Book</Button>
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
      )}

      {activeTab === "transport" && (
        <div className="flex flex-col gap-3">
          {[
            { icon: Plane, label: "Flights",         sub: "Domestic & international flights",  color: "text-blue-400 bg-blue-500/10" },
            { icon: Train, label: "Train Tickets",   sub: "Bangladesh Railway booking",        color: "text-green-400 bg-green-500/10" },
            { icon: Car,   label: "Car Rental",      sub: "AC/Non-AC cars with driver",        color: "text-orange-400 bg-orange-500/10" },
            { icon: Waves, label: "Boat/Launch",     sub: "Sundarban, river routes",           color: "text-cyan-400 bg-cyan-500/10" },
          ].map((t) => {
            const Icon = t.icon;
            return (
              <GlassCard key={t.label} className="p-4 flex items-center gap-4 glass-card-hover cursor-pointer">
                <div className={cn("h-11 w-11 rounded-xl flex items-center justify-center shrink-0", t.color)}>
                  <Icon className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-white">{t.label}</p>
                  <p className="text-xs text-white/40 mt-0.5">{t.sub}</p>
                </div>
                <ChevronRight className="h-4 w-4 text-white/25" />
              </GlassCard>
            );
          })}
        </div>
      )}
    </div>
  );
}
