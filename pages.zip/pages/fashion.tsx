import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PortalIconBar } from "@/components/feed/PortalIconBar";
import {
  Search, Heart, Star, ShoppingCart, ChevronRight,
  Shirt, Tag, Sparkles, BadgeCheck, Zap, Package,
} from "lucide-react";
import { cn } from "@/lib/utils";

const CATEGORIES = [
  { label: "Men", sub: "Panjabi, Shirts, Pants" },
  { label: "Women", sub: "Saree, Salwar, Tops" },
  { label: "Kids", sub: "Boys & Girls" },
  { label: "Traditional", sub: "Jamdani, Muslin" },
  { label: "Sports", sub: "Jersey, Shorts, Shoes" },
  { label: "Accessories", sub: "Bags, Belts, Watches" },
];

const PRODUCTS = [
  { id: "f1", name: "Khadi Panjabi Premium", brand: "Aarong",      price: "৳3,800", old: "৳5,500", img: "https://images.unsplash.com/photo-1603252109303-2751441dd157?w=300", rating: 4.9, reviews: 520, discount: "31%" },
  { id: "f2", name: "Jamdani Saree",          brand: "Kay Kraft",   price: "৳8,500", old: "৳12,000",img: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=300", rating: 4.8, reviews: 340, discount: "29%" },
  { id: "f3", name: "Casual Linen Shirt",     brand: "Yellow",      price: "৳1,200", old: "৳1,800", img: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=300", rating: 4.7, reviews: 890, discount: "33%" },
  { id: "f4", name: "Designer Kurti Set",     brand: "Meena Bazar", price: "৳2,200", old: "৳3,000", img: "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=300", rating: 4.6, reviews: 720, discount: "27%" },
];

const COLLECTIONS = [
  { name: "Eid Collection 2026", desc: "Premium festive wear for Eid-ul-Adha", items: 280, img: "https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?w=400" },
  { name: "Summer Essentials",   desc: "Light cotton, linens & breathable fabrics", items: 150, img: "https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=400" },
];

export default function FashionPage() {
  const [search, setSearch] = useState("");
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [activeGender, setActiveGender] = useState<"all" | "men" | "women" | "kids">("all");

  const filtered = PRODUCTS.filter(p => !search || p.name.toLowerCase().includes(search.toLowerCase()) || p.brand.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="flex flex-col gap-5 p-4 md:p-5">
      <PortalIconBar />

      {/* Hero */}
      <div className="relative rounded-3xl overflow-hidden border border-pink-500/20 h-44">
        <img src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1200" alt="Fashion" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
        <div className="absolute bottom-4 left-5 right-5">
          <div className="flex items-center gap-2 mb-1">
            <Shirt className="h-4 w-4 text-pink-400" />
            <span className="text-xs font-bold text-pink-300 uppercase tracking-widest">PaikarFashion</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Style. Tradition. Now.</h1>
          <p className="text-sm text-white/55">Local brands, international styles, authentic Bangladeshi fashion</p>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/35 pointer-events-none" />
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search clothes, brands, styles..." className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
      </div>

      {/* Gender filter */}
      <div className="flex gap-2 p-1 bg-white/5 rounded-xl border border-white/10">
        {(["all","men","women","kids"] as const).map(g => (
          <button key={g} onClick={() => setActiveGender(g)} className={cn("flex-1 py-2 rounded-lg text-sm font-medium capitalize transition-all", activeGender===g?"bg-primary text-white":"text-white/50 hover:text-white")}>{g === "all" ? "All" : g === "men" ? "Men" : g === "women" ? "Women" : "Kids"}</button>
        ))}
      </div>

      {/* Collections */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-base font-semibold text-white">Collections</h2>
          <span className="text-xs text-primary hover:underline cursor-pointer flex items-center gap-0.5">See all <ChevronRight className="h-3 w-3" /></span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {COLLECTIONS.map(col => (
            <div key={col.name} className="relative rounded-2xl overflow-hidden h-36 cursor-pointer">
              <img src={col.img} alt={col.name} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
              <div className="absolute bottom-3 left-4 right-4">
                <p className="text-sm font-bold text-white">{col.name}</p>
                <p className="text-xs text-white/55 mt-0.5">{col.desc}</p>
                <p className="text-xs text-white/40 mt-0.5">{col.items} items</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Category tiles */}
      <div>
        <h2 className="text-base font-semibold text-white mb-3">Shop by Category</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {CATEGORIES.map(c => (
            <button key={c.label} className="p-3.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/8 transition-colors text-left">
              <p className="text-sm font-bold text-white">{c.label}</p>
              <p className="text-xs text-white/40 mt-0.5">{c.sub}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Products */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-base font-semibold text-white">Best Sellers</h2>
          <span className="text-xs text-primary hover:underline cursor-pointer flex items-center gap-0.5">See all <ChevronRight className="h-3 w-3" /></span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {filtered.map(p => (
            <GlassCard key={p.id} className="overflow-hidden glass-card-hover cursor-pointer p-0">
              <div className="relative h-40">
                <img src={p.img} alt={p.name} className="w-full h-full object-cover" />
                <span className="absolute top-2 left-2 text-[9px] font-bold bg-red-500 text-white px-1.5 py-0.5 rounded-full">{p.discount} OFF</span>
                <button onClick={e => { e.stopPropagation(); setFavorites(prev => { const n = new Set(prev); n.has(p.id) ? n.delete(p.id) : n.add(p.id); return n; }); }}
                  className="absolute top-2 right-2 h-7 w-7 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center">
                  <Heart className={cn("h-3.5 w-3.5", favorites.has(p.id) ? "fill-red-400 text-red-400" : "text-white/70")} />
                </button>
              </div>
              <div className="p-3">
                <p className="text-[10px] text-pink-300 font-bold">{p.brand}</p>
                <p className="text-xs font-bold text-white leading-tight mt-0.5">{p.name}</p>
                <div className="flex items-center gap-1 mt-1 text-[10px] text-white/40">
                  <Star className="h-3 w-3 text-yellow-400 fill-yellow-400" /> {p.rating} ({p.reviews})
                </div>
                <div className="flex items-center gap-1 mt-1.5">
                  <span className="text-sm font-bold text-primary">{p.price}</span>
                  <span className="text-[10px] text-white/30 line-through">{p.old}</span>
                </div>
                <Button size="sm" className="w-full mt-2 bg-pink-500/20 hover:bg-pink-500/30 text-pink-300 border border-pink-500/30 rounded-full text-[10px] h-7">
                  <ShoppingCart className="h-3 w-3 mr-1" /> Buy
                </Button>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>

      {/* Badges */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { icon: BadgeCheck, label: "Authentic Products", color: "text-green-400 bg-green-500/10" },
          { icon: Package,    label: "Fast Delivery",       color: "text-blue-400 bg-blue-500/10" },
          { icon: Sparkles,   label: "100% Halal Fashion",  color: "text-purple-400 bg-purple-500/10" },
        ].map(b => { const Icon = b.icon; return (
          <GlassCard key={b.label} className="p-3 flex flex-col items-center gap-1.5 text-center">
            <div className={cn("h-8 w-8 rounded-xl flex items-center justify-center", b.color)}>
              <Icon className="h-4 w-4" />
            </div>
            <p className="text-[10px] text-white/55 font-medium leading-tight">{b.label}</p>
          </GlassCard>
        ); })}
      </div>
    </div>
  );
}
