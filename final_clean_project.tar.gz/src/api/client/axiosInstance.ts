import axios from 'axios';
import { onRequest, onResponse, onError } from './interceptors';

export const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api/v1',
  headers: {
    'Content-Type': 'application/json',
  },
});

apiClient.interceptors.request.use(onRequest);
apiClient.interceptors.response.use(onResponse, onError);
